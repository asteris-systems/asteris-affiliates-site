=== Asteris Affiliates ===
Contributors: asteriscommerce
Tags: affiliate, woocommerce, affiliate-program, commissions, referrals, easy-digital-downloads, surecart
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.3.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Full affiliate program for WooCommerce + EDD + Surecart. Free tier (10 affiliates). Pro from $149/yr. AffiliateWP-grade features at SliceWP pricing. Australian-built.

== Description ==

Asteris Affiliates is a complete self-hosted affiliate program. **Free version** runs up to 10 affiliates on WooCommerce with manual payouts. **Pro** unlocks unlimited affiliates, EDD + Surecart adapters, Stripe Connect auto-payouts, PayPal Payouts API, MLM/two-tier referrals, AI-generated swipe copy, A/B email tests, vanity landing pages, and cloud-assist fraud detection.

= More inclusions. Less cost. Australian-built. =

Replaces $300–$2,400/yr of AffiliateWP + Tapfiliate + Refersion + GoAffPro for $149–$549/yr. No Pro-tier feature walls beyond Free vs Pro. No annual feature-drop SaaS releases. HPOS-native from day one.

= Free tier =

* Up to 10 approved affiliates
* WooCommerce integration
* Click + commission tracking (60-day cookie + UTM + coupon-code attribution)
* Magic-link affiliate portal
* Manual mark-paid payouts (admin clicks)
* 15 customisable email templates (WYSIWYG editor)
* Email throttling, encrypted bank-detail storage
* Onboarding wizard, admin impersonation
* Dashboard widget, Reports + date-range, CSV export, bulk operations
* WP-CLI commands, REST API, activity log

= Pro tier ($149–$549/yr) adds =

* **Unlimited affiliates** + 1/3/10 sites per licence
* **EDD + Surecart adapters** in addition to WooCommerce
* **Stripe Connect auto-payouts** — monthly cron, fully automated
* **PayPal Payouts API** — automated batch sends
* **Recurring commissions** — WooCommerce Subscriptions, Y1 + Y2+ rates
* **MLM / two-tier referrals** — parent affiliates earn a slice of children's commissions
* **AI swipe-copy generator** — one-click variant generation via Asteris AI
* **Vanity landing pages** — /go/{handle} branded URLs per affiliate
* **A/B email tests** — variant routing + open-rate tracking
* **Refund-rate auto-suspend** — anti-fraud
* **Cloud-assist fraud** — opt-in cross-site signal sharing
* **Premium email support**

= Why Asteris Affiliates =

The market is split between:

* **AffiliateWP** ($149–$599/yr renewal, Pro-tier feature walls — no free version)
* **Tapfiliate** ($89–$249/mo SaaS, server-side only)
* **Solid Affiliate** ($129–$249/yr, WC-only)
* **Refersion** ($119+/mo SaaS)
* **SliceWP** (free + $99–$249/yr Pro — closest analog)

Asteris Affiliates ships **more for less** — the only plugin combining a meaningful free tier with EDD + Surecart adapters, MLM, AI swipe-copy, A/B email tests, vanity landing pages, AND PayPal Payouts API at the Pro tier. HPOS-native, Australian-built, no surprise tier-ups.

== Installation ==

1. Upload the plugin or install via Plugins → Add New → Upload
2. Activate
3. Visit ★ Affiliates in your WP admin → Settings to configure default rates
4. Drop the `[aff_signup]` shortcode on a page for public affiliate registration
5. (Optional) Upgrade to Pro from the **✨ Free vs Pro** menu item

== Frequently Asked Questions ==

= Is there really a free version? =
Yes. Up to 10 approved affiliates on WooCommerce with manual payouts. No time limit, no trial. Open source, GPL-2.0+.

= What's gated on free? =
EDD + Surecart, Stripe Connect auto-payouts, PayPal API, MLM, AI swipe-copy, vanity landing pages, A/B email tests, recurring commissions, refund-rate auto-suspend, cloud-assist fraud. See the **✨ Free vs Pro** page inside the plugin for a full comparison.

= Does Pro pricing renew? =
Pro is a subscription. Your launch price locks for the life of the subscription — no price hikes for existing customers.

= Can I migrate from AffiliateWP / SliceWP? =
Import tools are in the v1.2 roadmap. For v1.1, manual migration is the path.

= HPOS support? =
Yes — declared native from day one.

== Changelog ==

= 1.3.1 (9 June 2026) =
* HOTFIX: Plugin would stay on "free tier" / "Upgrade to Pro" even with a valid paid licence key saved by the Asteris Installer. Cause: Installer set the licence-key option but the plugin never called `activate`/`validate` server-side, so Free_Tier::is_pro() read status='unset'. Now auto-validates the saved key on first admin load when the saved state is unset, then clears the is_pro cache so the page reflects the new tier immediately.

= 1.3.0 (9 June 2026) =
* ARCHITECTURE: Autoloader now prefers the canonical AsterisShared\* copy hosted in the Asteris Installer plugin (v1.3.0+) when present. Eliminates the class-version race that caused fatal errors when sister Asteris plugins (WC, WP, Cart) had older vendored copies of the same shared module. Falls back to this plugin's bundled /src/shared/ when the Installer isn't installed (free-tier scenarios or in-progress migrations).
* MIGRATION: This release is the soft-migration step — bundled shared/ stays in this ZIP for one more release as the fallback. A future minor version will declare the Installer as a hard dependency via the WP 6.5+ Requires Plugins header.

= 1.2.3 (8 June 2026) =
* NEW: Full License page inside Affiliates admin (was: deep-link to Installer in 1.2.2). Shows three status cards — Licence status (Active / Expired / Invalid / Not activated), Current tier (Free / Starter / Pro / Agency / Founder), Asteris Installer presence. Licence key entry field with Activate button; masked key + Deactivate + Re-check buttons once active. Subscription expiry date + last-check timestamp surfaced. Asteris Installer cross-link card (present-or-tip) below.
* All licence activation flows route through admin-post.php with nonce verification (standing rule). Free_Tier static cache cleared on activate/deactivate/revalidate so UI reflects new tier on next page load.

= 1.2.2 (8 June 2026) =
* NEW: 🔑 License submenu at the end of the Affiliates sidebar. Deep-links to the Asteris Installer plugin's licence management page when present. When Installer isn't installed, shows a fallback page explaining what it is.
* Each Asteris plugin (WC, WP, Cart, Affiliates) is sold separately with its own licence. The Installer doesn't "unlock all plugins from one key" — it syncs your active licences (one per product) from your purchase email and lets you install each plugin you own with one click.

= 1.2.1 (8 June 2026) =
* HOTFIX: Critical error on plugins_loaded when another Asteris plugin (WC / WP / Cart) was active with an older vendored AsterisShared\License\Client. Free_Tier::is_pro() now defensively checks method_exists() before calling for_product(). Bug was dormant in early v1.1.x but always present — surfaced when Overview/Settings pages added new is_pro() call sites.

= 1.2.0 (8 June 2026) =
* NEW: Overview admin page — surfaces signup-page URL (auto-detected via [aff_signup] scan), affiliate portal URL, vanity /go/{handle} pattern, REST stats endpoint. Closes the new-customer "where do I find my URLs?" onboarding gap.
* NEW: One-click "Create signup page" button on Overview when no [aff_signup] shortcode is detected anywhere — drops a published page at /become-an-affiliate/ with the shortcode pre-filled.
* NEW: Detected integrations panel on Overview AND a one-line status banner at the top of Settings — shows WooCommerce / EDD / Surecart adapter state (ACTIVE / DORMANT) with versions. Confirms what's actually wired up at runtime.
* Menu: Overview submenu added FIRST in the plugin menu so fresh-install customers land on setup info before the Affiliates list.

= 1.1.3 (8 June 2026) =
* NEW: Settings tabs for Pro Features (MLM toggle), PayPal (client_id + secret + mode), Cloud-Assist Fraud (opt-in)
* NEW: MLM parent_affiliate_id picker on the Affiliate Detail page + tier2_rate_bp field
* Saves all new fields via existing single-form admin-post flow

= 1.1.2 (8 June 2026) =
* NEW: Page_Free_Tier_Status — dedicated Free vs Pro comparison page
* NEW: Page_Swipe_Copy — admin UI to manage swipe-copy library + AI variant generation
* NEW: Page_Landing_Pages — admin UI to create + edit vanity /go/{handle} landing pages
* NEW: Page_AB_Tests — admin UI to create + manage A/B email variants
* All Pro-only admin pages render an upgrade pitch on free tier

= 1.1.1 (8 June 2026) =
* NEW: Free tier — up to 10 approved affiliates, WC-only, manual payouts. WordPress.org distribution
* NEW: Free_Tier service gating MLM, AI swipe-copy, A/B emails, landing pages, cloud-assist fraud, recurring commissions, Stripe auto-payouts, PayPal API, EDD + Surecart adapters, refund-rate auto-suspend
* Admin banner showing N/10 affiliate cap with upgrade CTA
* Upgrade pitch on Settings + all Pro-gated features

= 1.1.0 (8 June 2026) =
* NEW: MLM / two-tier referrals (parent_affiliate_id schema + Tier2_Engine)
* NEW: AI swipe-copy generator (16-snippet seed library + Asteris AI integration)
* NEW: Vanity landing pages at /go/{handle} with hero image + CTA + view counter
* NEW: Cloud-assist fraud (opt-in cross-site signal sharing, SHA256-hashed)
* NEW: PayPal Payouts API integration (auto-batch sends)
* NEW: Easy Digital Downloads + Surecart adapters (commission engine is now platform-agnostic)
* NEW: A/B email tests with variant routing + open-rate tracking via 1×1 pixel
* NEW: Bulk operations across Affiliates + Commissions + Payouts list tables
* NEW: CSV export with filter awareness (streaming, safe for 100k+ rows)
* NEW: Sortable column headers on all list tables
* NEW: Date-range picker on Reports + Commissions
* NEW: WP admin dashboard widget (pending approvals + this-month earnings + top affiliate)
* NEW: Affiliate onboarding wizard (4-step portal flow)
* NEW: Admin impersonation ("View as this affiliate" with yellow banner + audit log)
* NEW: Per-recipient per-template per-day email throttling
* NEW: Per-product commission rate overrides (WC product edit tab)
* NEW: i18n textdomain loader + __() wrapping
* NEW: Mobile-responsive portal CSS (≤768px viewports)
* NEW: WP-CLI commands (list, approve, reject, recompute-aggregates, run-approvals, run-payouts, throttle-cleanup, stats)
* NEW: Denormalised aggregates on aff_affiliates row (lifetime_earnings_cents, lifetime_referrals, pending/approved/paid balances) with commission_changed hook
* NEW: Stats REST API cursor pagination + 5-minute transient cache + new /commissions endpoint
* NEW: AsterisShared\License\Client port (HMAC activate/validate/deactivate)
* SCHEMA: 8 new columns on aff_affiliates; 4 new columns on aff_commissions; 6 new tables (throttle, product_rates, swipe_copy, landing_pages, ab_emails, fraud_signals)
* HOOKS: New action hooks `asteris_aff_commission_created`, `asteris_aff_commission_changed`, `asteris_aff_payout_created`, `asteris_aff_cloud_fraud_sync`, `asteris_aff_recompute_daily`
* HOOKS: New filter hooks `asteris_aff_resolved_rate_bp`, `asteris_aff_email_daily_cap`, `asteris_ai_generate_text`

= 1.0.0 (8 June 2026) =
* First stable release
* 6-table DB schema, magic-link affiliate portal
* WooCommerce order + refund + subscription hooks
* Commission engine with Y1/Y2+ rate selection, refund window, attribution priority (coupon vs link)
* Stripe Connect Express onboarding (account creation → onboarding link → status retrieval → dashboard login link)
* Stripe Webhook listener (transfer.failed, transfer.reversed, account.updated)
* Monthly payout batch cron with method-readiness checks (Stripe / PayPal / Bank / Manual)
* WC coupon → affiliate code assignment
* Refund-rate scanner with auto-suspend
* Bot filter (40+ UA substrings)
* WYSIWYG email editor for 15 transactional templates
* Reports (30-day overview, top 10, refund-rate heatmap)
* 8-page admin UI

= 0.1.0-alpha.1 (7 June 2026) =
* Sprint 1: foundations — plugin bootstrap, DB schema (6 tables), settings, admin shell

== Upgrade Notice ==

= 1.1.2 =
Adds admin UIs for Swipe Copy, Landing Pages, A/B Tests + Free vs Pro comparison page. Safe in-place upgrade.

= 1.1.0 =
Major release — 22 new features, 6 new DB tables. Self-healing migration runs on activation.
