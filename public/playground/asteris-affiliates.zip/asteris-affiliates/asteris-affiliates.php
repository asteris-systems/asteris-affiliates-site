<?php
/**
 * Plugin Name:       Asteris Affiliates
 * Plugin URI:        https://asterisaffiliates.com
 * Description:       Run a full affiliate program on your WooCommerce store. Multi-tier commissions, recurring renewals (WC Subscriptions), Stripe Connect payouts, anti-fraud detection, WYSIWYG email templates — AffiliateWP-grade features at SliceWP pricing, with no Pro-tier upsells. HPOS-native from day one.
 * Version:           1.1.3
 * Author:            Asteris Commerce
 * Author URI:        https://asteriscommerce.com
 * License:           GPL-2.0-or-later
 * Text Domain:       asteris-affiliates
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Requires Plugins:  woocommerce
 * WC requires at least: 8.0
 * WC tested up to:   9.4
 * Update URI:        https://pay.asteriscommerce.com/asteris-affiliates
 */

defined( 'ABSPATH' ) || exit;

// ── Version + paths ─────────────────────────────────────────────────────────

define( 'ASTERIS_AFFILIATES_VERSION', '1.1.3' );
define( 'ASTERIS_AFFILIATES_DIR',     __DIR__ );
define( 'ASTERIS_AFFILIATES_FILE',    __FILE__ );
define( 'ASTERIS_AFFILIATES_URL',     plugin_dir_url( __FILE__ ) );

// ── Licence server URL + signing secret ─────────────────────────────────────
// Same pattern as every other paid Asteris plugin — secret baked at build
// time so customers get zero-config activation. See feedback_secret_baking_locked.md.

if ( ! defined( 'ASTERIS_LICENCE_SERVER_URL' ) ) {
	define( 'ASTERIS_LICENCE_SERVER_URL', 'https://pay.asteriscommerce.com' );
}
defined( 'ASTERIS_LS_SIGNING_SECRET' )
	|| define( 'ASTERIS_LS_SIGNING_SECRET', 'df8fb23b9877c4e9edbb5951dcebd35220f46ab3e6116ab18e6287ce553c59a7' );

// ── HPOS compatibility declaration ──────────────────────────────────────────
// Tell WC we're HPOS-native so our plugin doesn't trigger the "incompatible
// plugin" warning when HPOS is enabled. Must run before woocommerce_init.

add_action( 'before_woocommerce_init', static function (): void {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables',
			__FILE__,
			true
		);
	}
} );

// ── PSR-4 autoloader ────────────────────────────────────────────────────────
// Zero deps, no Composer. Maps AsterisAffiliates\* → src/*.php

spl_autoload_register( static function ( string $class ): void {
	// Two namespaces, both rooted at /src/:
	//   AsterisAffiliates\Foo    → /src/Foo.php           (plugin code)
	//   AsterisShared\License\X  → /src/shared/License/X.php  (vendored)
	$map = [
		'AsterisAffiliates\\' => __DIR__ . '/src/',
		'AsterisShared\\'     => __DIR__ . '/src/shared/',
	];
	foreach ( $map as $prefix => $base_dir ) {
		$len = strlen( $prefix );
		if ( strncmp( $class, $prefix, $len ) !== 0 ) { continue; }
		$relative = substr( $class, $len );
		$file     = $base_dir . str_replace( '\\', '/', $relative ) . '.php';
		if ( file_exists( $file ) ) {
			require_once $file;
		}
		return;
	}
} );

// ── Activation + deactivation hooks ─────────────────────────────────────────

register_activation_hook(   __FILE__, [ \AsterisAffiliates\Core\Activation::class, 'activate'   ] );
register_deactivation_hook( __FILE__, [ \AsterisAffiliates\Core\Activation::class, 'deactivate' ] );

// ── Boot ────────────────────────────────────────────────────────────────────
// plugins_loaded fires AFTER WooCommerce loads, so we can rely on WC classes
// being available inside Plugin::__construct.

add_action( 'plugins_loaded', static function (): void {
	// Load translations for i18n (Sprint 9B)
	load_plugin_textdomain( 'asteris-affiliates', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	// v1.1: WC is the primary order source but NOT a hard requirement — EDD
	// and Surecart adapters work without WC. We still surface a notice in
	// admin if NONE of WC/EDD/Surecart are present (otherwise the plugin
	// has no order source to attribute against).
	$has_wc       = class_exists( 'WooCommerce' );
	$has_edd      = function_exists( 'edd_get_payment' );
	$has_surecart = class_exists( '\\SureCart\\Models\\Order' );
	if ( ! $has_wc && ! $has_edd && ! $has_surecart ) {
		add_action( 'admin_notices', static function (): void {
			echo '<div class="notice notice-warning"><p><strong>Asteris Affiliates</strong> needs at least one supported e-commerce platform — WooCommerce, Easy Digital Downloads, or Surecart — to attribute orders. Tracking + the portal still work, but no commissions will be created until a supported store is active.</p></div>';
		} );
	}
	\AsterisAffiliates\Core\Plugin::instance();
}, 20 );
