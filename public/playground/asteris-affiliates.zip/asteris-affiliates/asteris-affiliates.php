<?php
/**
 * Plugin Name:       Asteris Affiliates
 * Plugin URI:        https://asterisaffiliates.com
 * Description:       Run a full affiliate program on your WooCommerce store. Multi-tier commissions, recurring renewals (WC Subscriptions), Stripe Connect payouts, anti-fraud detection, WYSIWYG email templates — AffiliateWP-grade features at SliceWP pricing, with no Pro-tier upsells. HPOS-native from day one.
 * Version:           1.3.14
 * Author:            Asteris Commerce
 * Author URI:        https://asteriscommerce.com
 * License:           GPL-2.0-or-later
 * Text Domain:       asteris-affiliates
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Requires Plugins:  woocommerce
 * WC requires at least: 8.0
 * WC tested up to:   9.4
 * Update URI:        https://pay.asteriscommerce.com/asteris-affiliates
 */

defined( 'ABSPATH' ) || exit;

// ── Version + paths ─────────────────────────────────────────────────────────

define( 'ASTERIS_AFFILIATES_VERSION', '1.3.14' );
define( 'ASTERIS_AFFILIATES_DIR',     __DIR__ );
define( 'ASTERIS_AFFILIATES_FILE',    __FILE__ );
define( 'ASTERIS_AFFILIATES_URL',     plugin_dir_url( __FILE__ ) );

// ── WP 6.7 textdomain preload (NOOP pattern) ───────────────────────────────
// Pre-populate $GLOBALS['l10n']['asteris-affiliates'] with an empty
// NOOP_Translations IMMEDIATELY at file-load. This marks the domain as
// "loaded" so any __() / esc_html__() call during plugins_loaded boot
// finds $l10n populated and never triggers WP 6.7's "called too early"
// notice. Real .mo translations (if customer ships any) load at init:1
// and replace the NOOP transparently. Same pattern as the WC/WP/Cart plugins.
if ( ! isset( $GLOBALS['l10n']['asteris-affiliates'] ) ) {
	$GLOBALS['l10n']['asteris-affiliates'] = new NOOP_Translations();
}
add_action( 'init', static function (): void {
	load_plugin_textdomain( 'asteris-affiliates', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}, 1 );

// ── Licence server URL + signing secret ─────────────────────────────────────
// Same pattern as every other paid Asteris plugin — secret baked at build
// time so customers get zero-config activation. See feedback_secret_baking_locked.md.

if ( ! defined( 'ASTERIS_LICENCE_SERVER_URL' ) ) {
	define( 'ASTERIS_LICENCE_SERVER_URL', 'https://pay.asteriscommerce.com' );
}
defined( 'ASTERIS_LS_SIGNING_SECRET' )
	|| define( 'ASTERIS_LS_SIGNING_SECRET', 'df8fb23b9877c4e9edbb5951dcebd35220f46ab3e6116ab18e6287ce553c59a7' );

// ── HPOS compatibility declaration ──────────────────────────────────────────
// Tell WC we're HPOS-native so our plugin doesn't trigger the "incompatible
// plugin" warning when HPOS is enabled. Must run before woocommerce_init.

add_action( 'before_woocommerce_init', static function (): void {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables',
			__FILE__,
			true
		);
	}
} );

// ── PSR-4 autoloader ────────────────────────────────────────────────────────
// Zero deps, no Composer.
//
// AsterisAffiliates\Foo    → /src/Foo.php                 (plugin's own code)
// AsterisShared\License\X  → resolved from the canonical Installer-hosted
//                            copy when present; falls back to this plugin's
//                            bundled /src/shared/ otherwise.
//
// v1.3 architecture: the Installer registered an autoloader for AsterisShared\*
// at plugin-load (with prepend=true) so its single canonical Client wins the
// race against every paid plugin. The check below is the fallback path for
// when this plugin runs without the Installer present (free-tier scenarios
// or in-progress migrations). See project_dual_plugin_architecture.md.
spl_autoload_register( static function ( string $class ): void {
	// Plugin's own classes — always served from /src/.
	if ( strncmp( $class, 'AsterisAffiliates\\', 18 ) === 0 ) {
		$relative = substr( $class, 18 );
		$file     = __DIR__ . '/src/' . str_replace( '\\', '/', $relative ) . '.php';
		if ( file_exists( $file ) ) { require_once $file; }
		return;
	}

	// AsterisShared\* — prefer Installer's canonical copy when present,
	// fall back to our own bundled copy. The Installer's prepended autoloader
	// usually serves this first; this branch is the safety net.
	if ( strncmp( $class, 'AsterisShared\\', 14 ) === 0 ) {
		$relative = substr( $class, 14 );
		$path     = str_replace( '\\', '/', $relative ) . '.php';

		if ( defined( 'ASTERIS_INSTALLER_HAS_SHARED' ) && defined( 'ASTERIS_INSTALLER_DIR' ) ) {
			$installer_file = ASTERIS_INSTALLER_DIR . '/src/shared/' . $path;
			if ( file_exists( $installer_file ) ) {
				require_once $installer_file;
				return;
			}
		}

		$own = __DIR__ . '/src/shared/' . $path;
		if ( file_exists( $own ) ) { require_once $own; }
		return;
	}
} );

// ── PHP opcache reset (v1.3.14) ─────────────────────────────────────────────
// Plugin_Upgrader replaces files on disk but persistent opcode caches (Wordify
// uses one) keep serving the OLD compiled bytecode until manually invalidated.
// This is why activate kept returning HTTP 400 even after 1.3.7 added site_url
// — the file had the fix, but PHP was running cached 1.3.5-era bytecode.
//
// Calling opcache_invalidate() on every plugin file forces a fresh compile of
// the just-replaced files on the very next PHP request after install.
// Idempotent + cheap when opcache is off.
if ( function_exists( 'opcache_invalidate' ) ) {
	@opcache_invalidate( __DIR__ . '/src/shared/License/Client.php', true );
	@opcache_invalidate( __DIR__ . '/src/Core/Plugin.php', true );
	@opcache_invalidate( __FILE__, true );
}

// ── Activation + deactivation hooks ─────────────────────────────────────────

register_activation_hook(   __FILE__, [ \AsterisAffiliates\Core\Activation::class, 'activate'   ] );
register_deactivation_hook( __FILE__, [ \AsterisAffiliates\Core\Activation::class, 'deactivate' ] );

// v1.3.14 — Auto-activate the licence the moment the plugin is activated
// (Plugin Upgrader fires this AFTER unzipping the new files). This replaces
// the "manual click Activate" step entirely. If the Installer pre-seeded
// wp_options[asteris_aff_license_key], we hit pay.asteriscommerce.com here
// and store state — UI loads on Active/Pro tier on the very first admin
// page after install, zero clicks needed.
register_activation_hook( __FILE__, static function (): void {
	if ( function_exists( 'opcache_reset' ) ) { @opcache_reset(); }
	$key = (string) get_option( 'asteris_aff_license_key', '' );
	if ( $key === '' ) { return; }
	if ( ! class_exists( '\\AsterisShared\\License\\Client' ) ) { return; }
	if ( ! method_exists( '\\AsterisShared\\License\\Client', 'for_product' ) ) { return; }
	$client = \AsterisShared\License\Client::for_product( 'asteris_affiliates', 'asteris_aff_license_key' );
	if ( $client->status() === 'active' ) { return; }
	$client->activate( $key );
} );

// ── Boot ────────────────────────────────────────────────────────────────────
// plugins_loaded fires AFTER WooCommerce loads, so we can rely on WC classes
// being available inside Plugin::__construct.

add_action( 'plugins_loaded', static function (): void {
	// Load translations for i18n (Sprint 9B)
	load_plugin_textdomain( 'asteris-affiliates', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	// v1.1: WC is the primary order source but NOT a hard requirement — EDD
	// and Surecart adapters work without WC. We still surface a notice in
	// admin if NONE of WC/EDD/Surecart are present (otherwise the plugin
	// has no order source to attribute against).
	$has_wc       = class_exists( 'WooCommerce' );
	$has_edd      = function_exists( 'edd_get_payment' );
	$has_surecart = class_exists( '\\SureCart\\Models\\Order' );
	if ( ! $has_wc && ! $has_edd && ! $has_surecart ) {
		add_action( 'admin_notices', static function (): void {
			echo '<div class="notice notice-warning"><p><strong>Asteris Affiliates</strong> needs at least one supported e-commerce platform — WooCommerce, Easy Digital Downloads, or Surecart — to attribute orders. Tracking + the portal still work, but no commissions will be created until a supported store is active.</p></div>';
		} );
	}
	\AsterisAffiliates\Core\Plugin::instance();
}, 20 );
