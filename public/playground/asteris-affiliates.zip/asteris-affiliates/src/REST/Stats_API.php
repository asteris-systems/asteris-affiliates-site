<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\REST;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Public_\Magic_Link_Auth;

defined( 'ABSPATH' ) || exit;

/**
 * Affiliate-facing stats REST endpoint.
 *
 *   GET /wp-json/asteris-affiliates/v1/stats
 *
 * v1.1 optimisations (Sprint 9C):
 *   - Reads denormalised totals from aff_affiliates row (no SUM queries)
 *   - 5-minute transient cache keyed by affiliate ID (cheap repeat-fetches)
 *   - Optional ?cursor=<id> + ?limit=<n> on related list endpoints
 *
 * Shape unchanged from v1.0 — additive cache header tells callers stale vs fresh.
 *
 * Auth: portal-auth cookie set by Magic_Link_Auth.
 */
final class Stats_API {

	private const NAMESPACE = 'asteris-affiliates/v1';
	private const CACHE_TTL = 5 * MINUTE_IN_SECONDS;

	public static function register(): void {
		register_rest_route( self::NAMESPACE, '/stats', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'handle_stats' ],
			'permission_callback' => [ self::class, 'check_auth' ],
		] );
		register_rest_route( self::NAMESPACE, '/commissions', [
			'methods'             => 'GET',
			'callback'            => [ self::class, 'handle_commissions' ],
			'permission_callback' => [ self::class, 'check_auth' ],
			'args' => [
				'cursor' => [ 'type' => 'integer', 'default' => 0 ],
				'limit'  => [ 'type' => 'integer', 'default' => 50, 'minimum' => 1, 'maximum' => 200 ],
			],
		] );
	}

	public static function check_auth(): bool|\WP_Error {
		$aff = Magic_Link_Auth::current_affiliate();
		if ( ! $aff ) {
			return new \WP_Error( 'not_authenticated', 'Sign in to your affiliate portal first.', [ 'status' => 401 ] );
		}
		return true;
	}

	public static function handle_stats( \WP_REST_Request $request ): \WP_REST_Response {
		$aff = Magic_Link_Auth::current_affiliate();
		if ( ! $aff ) {
			return new \WP_REST_Response( [ 'error' => 'not_authenticated' ], 401 );
		}
		$id = (int) $aff->id;

		$cache_key = 'asteris_aff_stats_' . $id;
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			$cached['cache'] = 'hit';
			return new \WP_REST_Response( $cached, 200 );
		}

		// Read aggregates from the row (denormalised — no SUM queries)
		$fresh = Affiliate_Repository::find( $id );
		$earnings = [
			'pending_cents'  => (int) ( $fresh->pending_balance_cents  ?? 0 ),
			'approved_cents' => (int) ( $fresh->approved_balance_cents ?? 0 ),
			'paid_cents'     => (int) ( $fresh->paid_balance_cents     ?? 0 ),
			'currency'       => 'USD',
		];

		global $wpdb;
		$p = $wpdb->prefix;

		// Click counts (no good denorm — keep COUNTs but cache result)
		$clicks_total      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d", $id ) );
		$clicks_30d        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d AND landed_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $id ) );
		$conversions_total = (int) ( $fresh->lifetime_referrals ?? 0 ); // approximation (lifetime_referrals counts referrals not conversions; replace if needed)
		$conversions_30d   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_commissions WHERE affiliate_id = %d AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $id ) );
		$conv_rate_30d_pct = $clicks_30d > 0 ? round( ( $conversions_30d / $clicks_30d ) * 100, 1 ) : 0.0;

		$payload = [
			'affiliate' => [
				'id'           => $id,
				'display_name' => $fresh->display_name,
				'public_id'    => $fresh->public_id,
				'tracking_url' => add_query_arg( 'ref', $fresh->public_id, home_url( '/' ) ),
			],
			'earnings' => $earnings,
			'traffic' => [
				'clicks_total'             => $clicks_total,
				'clicks_30d'               => $clicks_30d,
				'conversions_total'        => $conversions_total,
				'conversions_30d'          => $conversions_30d,
				'conversion_rate_30d_pct'  => $conv_rate_30d_pct,
			],
			'cache'        => 'miss',
			'generated_at' => current_time( 'mysql', true ),
		];

		set_transient( $cache_key, $payload, self::CACHE_TTL );
		return new \WP_REST_Response( $payload, 200 );
	}

	/**
	 * Cursor-paginated commission list. Cheaper than OFFSET on large affiliates.
	 *
	 *   GET /commissions?cursor=12345&limit=50
	 *
	 * Returns rows with id < cursor (or all if cursor = 0). next_cursor in
	 * response = last row's id, or null if exhausted.
	 */
	public static function handle_commissions( \WP_REST_Request $request ): \WP_REST_Response {
		$aff = Magic_Link_Auth::current_affiliate();
		if ( ! $aff ) {
			return new \WP_REST_Response( [ 'error' => 'not_authenticated' ], 401 );
		}
		$id     = (int) $aff->id;
		$cursor = (int) $request->get_param( 'cursor' );
		$limit  = max( 1, min( 200, (int) $request->get_param( 'limit' ) ) );

		global $wpdb;
		$p = $wpdb->prefix;
		$where = 'affiliate_id = %d';
		$params = [ $id ];
		if ( $cursor > 0 ) { $where .= ' AND id < %d'; $params[] = $cursor; }
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, order_id, amount_cents, currency, rate_bp, status, created_at
			 FROM {$p}aff_commissions WHERE {$where} ORDER BY id DESC LIMIT %d",
			array_merge( $params, [ $limit ] )
		), ARRAY_A );

		$next = count( $rows ) === $limit ? (int) end( $rows )['id'] : null;

		return new \WP_REST_Response( [
			'commissions' => $rows,
			'next_cursor' => $next,
		], 200 );
	}
}
