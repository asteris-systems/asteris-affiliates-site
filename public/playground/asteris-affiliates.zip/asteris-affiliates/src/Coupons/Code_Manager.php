<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Coupons;

defined( 'ABSPATH' ) || exit;

/**
 * Maps WC coupons to affiliates.
 *
 * Used by Attribution_Resolver — when an order uses one of these coupons,
 * the linked affiliate gets credit even if the visitor never clicked an
 * affiliate link (no cookie).
 *
 * Why this matters: coupon-only attribution is how partners on platforms
 * that DO NOT carry referral links (podcasts, YouTube, print, in-person)
 * earn commission. Customer hears the code, pastes it at checkout, the
 * affiliate gets credit.
 *
 * Read path: Attribution_Resolver does a direct SQL query against the
 * `aff_coupons` table — no need to go through this class.
 *
 * Write path: admin uses this class to assign/revoke. Each mapping
 * references the WC coupon by ID (so coupon edits in WC reflect here).
 */
final class Code_Manager {

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'aff_coupons';
	}

	/**
	 * @return object[]
	 */
	public static function list_for_affiliate( int $affiliate_id ): array {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE affiliate_id = %d ORDER BY id DESC',
			$affiliate_id
		) );
	}

	public static function list_all(): array {
		global $wpdb;
		$prefix = $wpdb->prefix;
		// Join with affiliates for the admin list view's display_name
		return (array) $wpdb->get_results(
			"SELECT c.*, a.display_name AS affiliate_name, a.email AS affiliate_email
			 FROM {$prefix}aff_coupons c
			 LEFT JOIN {$prefix}aff_affiliates a ON a.id = c.affiliate_id
			 ORDER BY c.id DESC"
		);
	}

	public static function find_by_code( string $code ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE coupon_code = %s LIMIT 1',
			$code
		) );
		return $row ?: null;
	}

	/**
	 * Assign an existing WC coupon to an affiliate. Returns row ID or
	 * WP_Error on validation failure (coupon doesn't exist, code already
	 * mapped to another affiliate, etc).
	 */
	public static function assign( int $affiliate_id, string $coupon_code ) {
		$coupon_code = strtoupper( trim( $coupon_code ) );
		if ( $coupon_code === '' ) {
			return new \WP_Error( 'empty', 'Coupon code is empty.' );
		}

		// Confirm the WC coupon exists
		if ( ! function_exists( 'wc_get_coupon_id_by_code' ) ) {
			return new \WP_Error( 'no_wc', 'WooCommerce isn\'t loaded.' );
		}
		$wc_coupon_id = wc_get_coupon_id_by_code( $coupon_code );
		if ( ! $wc_coupon_id ) {
			return new \WP_Error( 'no_coupon', sprintf( 'No WC coupon with code "%s". Create it in WooCommerce → Coupons first, then assign.', $coupon_code ) );
		}

		if ( self::find_by_code( $coupon_code ) ) {
			return new \WP_Error( 'dup', sprintf( 'Coupon "%s" is already mapped to another affiliate.', $coupon_code ) );
		}

		global $wpdb;
		$ok = $wpdb->insert( self::table(), [
			'affiliate_id' => $affiliate_id,
			'wc_coupon_id' => (int) $wc_coupon_id,
			'coupon_code'  => $coupon_code,
			'assigned_at'  => current_time( 'mysql', true ),
			'active'       => 1,
		] );
		if ( ! $ok ) {
			return new \WP_Error( 'db', 'Database insert failed.' );
		}

		$id = (int) $wpdb->insert_id;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'coupon.assigned',
			'affiliate_id' => $affiliate_id,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'coupon_code' => $coupon_code, 'wc_coupon_id' => $wc_coupon_id ] ),
		] );
		return $id;
	}

	public static function revoke( int $mapping_id ): bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $mapping_id ) );
		if ( ! $row ) { return false; }
		$wpdb->delete( self::table(), [ 'id' => $mapping_id ] );
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'coupon.revoked',
			'affiliate_id' => (int) $row->affiliate_id,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'coupon_code' => $row->coupon_code ] ),
		] );
		return true;
	}
}
