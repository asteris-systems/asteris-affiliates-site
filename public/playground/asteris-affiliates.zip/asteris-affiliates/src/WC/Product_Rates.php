<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\WC;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Per-product commission rate overrides.
 *
 * Stores per-product rates in wp_aff_product_rates. Hooks the commission
 * engine via two filters:
 *
 *   - `asteris_aff_commissionable_subtotal` — exclude product subtotal from
 *      the commissionable amount if the product is marked ineligible
 *   - `asteris_aff_resolved_rate_bp` — return the per-product rate (if set)
 *      otherwise the affiliate's default
 *
 * Also adds a "Affiliate rate" panel on the WC product edit screen.
 */
final class Product_Rates {

	public static function register(): void {
		add_filter( 'asteris_aff_commissionable_subtotal', [ self::class, 'filter_subtotal' ], 10, 3 );
		add_filter( 'asteris_aff_resolved_rate_bp',        [ self::class, 'filter_rate' ],     10, 4 );

		// WC product edit panel
		add_filter( 'woocommerce_product_data_tabs',       [ self::class, 'add_product_tab' ] );
		add_action( 'woocommerce_product_data_panels',     [ self::class, 'render_product_panel' ] );
		add_action( 'woocommerce_process_product_meta',    [ self::class, 'save_product_meta' ] );
	}

	public static function get_for_product( int $product_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_product_rates WHERE product_id = %d LIMIT 1",
			$product_id
		), ARRAY_A );
		return $row ?: null;
	}

	public static function upsert( int $product_id, ?int $rate_y1_bp, ?int $rate_y2plus_bp, bool $eligible ): void {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->query( $wpdb->prepare(
			"INSERT INTO {$wpdb->prefix}aff_product_rates (product_id, rate_y1_bp, rate_y2plus_bp, eligible, updated_at)
			 VALUES (%d, %s, %s, %d, %s)
			 ON DUPLICATE KEY UPDATE rate_y1_bp = VALUES(rate_y1_bp), rate_y2plus_bp = VALUES(rate_y2plus_bp), eligible = VALUES(eligible), updated_at = VALUES(updated_at)",
			$product_id,
			$rate_y1_bp === null ? null : (int) $rate_y1_bp,
			$rate_y2plus_bp === null ? null : (int) $rate_y2plus_bp,
			$eligible ? 1 : 0,
			$now
		) );
	}

	/**
	 * Filter the commissionable subtotal — strip out ineligible line items.
	 *
	 * Engine passes the whole-order subtotal; we walk line items + subtract any
	 * that are marked eligible=0.
	 */
	public static function filter_subtotal( float $subtotal, \WC_Order $order, object $aff ): float {
		$remove = 0.0;
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) { continue; }
			$pid    = (int) $item->get_product_id();
			$config = self::get_for_product( $pid );
			if ( $config && (int) $config['eligible'] === 0 ) {
				$remove += (float) $item->get_subtotal();
			}
		}
		return max( 0.0, $subtotal - $remove );
	}

	/**
	 * If ALL line items in the order have a per-product rate, use the
	 * weighted-average. If only some do, ignore (use the affiliate's default).
	 *
	 * Simpler v1.1 implementation: if ANY product has a per-product rate,
	 * use the MAX of (per-product rate, affiliate's resolved rate). This is
	 * the cleanest behaviour without splitting the commission row per line.
	 *
	 * Future v1.2: per-line-item commission rows.
	 */
	public static function filter_rate( int $rate_bp, \WC_Order $order, object $aff, int $year ): int {
		$best = $rate_bp;
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) { continue; }
			$pid    = (int) $item->get_product_id();
			$config = self::get_for_product( $pid );
			if ( ! $config ) { continue; }
			$candidate = $year === 1
				? (int) ( $config['rate_y1_bp'] ?? 0 )
				: (int) ( $config['rate_y2plus_bp'] ?? 0 );
			if ( $candidate > 0 && $candidate > $best ) {
				$best = $candidate;
			}
		}
		return $best;
	}

	// ── WC product edit screen panel ────────────────────────────────────────

	public static function add_product_tab( array $tabs ): array {
		$tabs['asteris_aff'] = [
			'label'  => __( 'Affiliate rate', 'asteris-affiliates' ),
			'target' => 'asteris_aff_product_data',
			'class'  => [],
			'priority' => 80,
		];
		return $tabs;
	}

	public static function render_product_panel(): void {
		global $post;
		$config = $post ? self::get_for_product( (int) $post->ID ) : null;
		$y1 = $config && $config['rate_y1_bp'] !== null ? number_format( $config['rate_y1_bp'] / 100, 2 ) : '';
		$y2 = $config && $config['rate_y2plus_bp'] !== null ? number_format( $config['rate_y2plus_bp'] / 100, 2 ) : '';
		$elig = $config ? (bool) $config['eligible'] : true;
		?>
		<div id="asteris_aff_product_data" class="panel woocommerce_options_panel">
			<p class="form-field">
				<label for="asteris_aff_eligible"><?php esc_html_e( 'Affiliate-eligible', 'asteris-affiliates' ); ?></label>
				<input type="checkbox" id="asteris_aff_eligible" name="asteris_aff_eligible" value="1" <?php checked( $elig ); ?>>
				<span class="description"><?php esc_html_e( 'Uncheck to exclude this product from affiliate commissions entirely.', 'asteris-affiliates' ); ?></span>
			</p>
			<p class="form-field">
				<label for="asteris_aff_y1"><?php esc_html_e( 'Y1 rate override (%)', 'asteris-affiliates' ); ?></label>
				<input type="number" step="0.01" min="0" max="100" id="asteris_aff_y1" name="asteris_aff_y1" value="<?php echo esc_attr( $y1 ); ?>" placeholder="<?php esc_attr_e( 'leave blank to use default', 'asteris-affiliates' ); ?>">
			</p>
			<p class="form-field">
				<label for="asteris_aff_y2"><?php esc_html_e( 'Y2+ rate override (%)', 'asteris-affiliates' ); ?></label>
				<input type="number" step="0.01" min="0" max="100" id="asteris_aff_y2" name="asteris_aff_y2" value="<?php echo esc_attr( $y2 ); ?>" placeholder="<?php esc_attr_e( 'leave blank to use default', 'asteris-affiliates' ); ?>">
			</p>
		</div>
		<?php
	}

	public static function save_product_meta( int $post_id ): void {
		$elig = ! empty( $_POST['asteris_aff_eligible'] );
		$y1 = isset( $_POST['asteris_aff_y1'] ) && $_POST['asteris_aff_y1'] !== '' ? (int) round( ((float) $_POST['asteris_aff_y1']) * 100 ) : null;
		$y2 = isset( $_POST['asteris_aff_y2'] ) && $_POST['asteris_aff_y2'] !== '' ? (int) round( ((float) $_POST['asteris_aff_y2']) * 100 ) : null;
		self::upsert( $post_id, $y1, $y2, $elig );
	}
}
