<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\WC;

use AsterisAffiliates\Commissions\Engine;

defined( 'ABSPATH' ) || exit;

/**
 * Listens for WC refunds → claws back commission proportionally.
 *
 * Two hooks for full coverage:
 *   - `woocommerce_order_refunded`           — fires for each refund event
 *   - `woocommerce_order_status_refunded`    — fires when order status flips
 *                                              to 'refunded' (full refund path)
 *
 * Engine::apply_refund is idempotent for the FULL-refund path — once a
 * commission is marked refunded, subsequent calls no-op. For partial
 * refunds, repeated calls correctly recompute from the order's current
 * `total_refunded` value.
 */
final class Refund_Hook {

	public static function register(): void {
		add_action( 'woocommerce_order_refunded',        [ self::class, 'on_refunded' ], 30, 2 );
		add_action( 'woocommerce_order_status_refunded', [ self::class, 'on_full_status' ], 30 );
	}

	public static function on_refunded( int $order_id, int $refund_id ): void {
		$reason = null;
		$refund = wc_get_order( $refund_id );
		if ( $refund instanceof \WC_Order_Refund ) {
			$reason = (string) $refund->get_reason();
		}
		Engine::apply_refund( $order_id, $reason );
	}

	public static function on_full_status( int $order_id ): void {
		Engine::apply_refund( $order_id, 'status_refunded' );
	}
}
