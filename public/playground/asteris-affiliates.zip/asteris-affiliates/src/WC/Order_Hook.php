<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\WC;

use AsterisAffiliates\Commissions\Engine;

defined( 'ABSPATH' ) || exit;

/**
 * Listens for WC order completion → creates commission row.
 *
 * Fires on TWO transitions for safety:
 *   - `woocommerce_order_status_completed`   (the obvious one)
 *   - `woocommerce_order_status_processing`  (digital goods + many SaaS
 *      flows ship at processing → completed transition may never fire)
 *
 * Engine::create_for_order is idempotent — if both fire for the same order,
 * the second is a no-op.
 *
 * Priority 30 — runs AFTER most other plugins (so any coupon-side hooks
 * that mutate the order have already finished writing).
 */
final class Order_Hook {

	public static function register(): void {
		add_action( 'woocommerce_order_status_completed',  [ self::class, 'on_complete' ], 30 );
		add_action( 'woocommerce_order_status_processing', [ self::class, 'on_complete' ], 30 );
	}

	public static function on_complete( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof \WC_Order ) { return; }

		// Skip if this is a WC Subscriptions renewal — that path goes through
		// Subscription_Hook which creates a Y2+ commission instead.
		if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order_id ) ) {
			return;
		}

		Engine::create_for_order( $order );
	}
}
