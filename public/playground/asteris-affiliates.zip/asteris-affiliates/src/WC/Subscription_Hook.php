<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\WC;

use AsterisAffiliates\Commissions\Engine;

defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce Subscriptions integration — fires when a subscription renewal
 * payment completes, creating a fresh commission row at the Y2+ rate.
 *
 * Why this matters: without it, the affiliate only ever earns on the first
 * subscription purchase. The whole "Y1 25% / Y2+ 15%" recurring model
 * collapses to a one-shot payment. ~30% of WC stores running affiliate
 * programs sell subscriptions, so this is table-stakes.
 *
 * Self-registers only when WC Subscriptions is active — gracefully no-ops
 * on stores that don't use it.
 */
final class Subscription_Hook {

	public static function register(): void {
		// Hook regardless of whether WC Subscriptions is currently active —
		// if customer installs it LATER, our hook is already in place.
		add_action( 'woocommerce_subscription_renewal_payment_complete', [ self::class, 'on_renewal_payment' ], 30, 2 );
	}

	/**
	 * @param \WC_Subscription $subscription
	 * @param \WC_Order        $last_order   The renewal order (NOT the original)
	 */
	public static function on_renewal_payment( $subscription, $last_order ): void {
		// Pro-only — recurring commissions are a Pro upgrade
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'recurring_commissions' ) ) { return; }
		if ( ! function_exists( 'wcs_is_subscription' ) ) { return; }
		if ( ! $last_order instanceof \WC_Order ) { return; }

		// Resolve the PARENT order (the original purchase that started the
		// subscription). That's where the affiliate attribution was set.
		$parent_order_id = 0;
		if ( method_exists( $subscription, 'get_parent_id' ) ) {
			$parent_order_id = (int) $subscription->get_parent_id();
		}
		if ( $parent_order_id === 0 ) { return; }

		Engine::create_for_renewal( $last_order, $parent_order_id );
	}
}
