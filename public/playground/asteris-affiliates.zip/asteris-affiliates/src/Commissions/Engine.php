<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Commissions;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Settings;
use AsterisAffiliates\Tracking\Attribution_Resolver;

defined( 'ABSPATH' ) || exit;

/**
 * Commission lifecycle orchestrator.
 *
 * Public surface:
 *   - create_for_order( $order, $attribution_type_override = null )
 *       Called from WC\Order_Hook on order completion. Resolves attribution,
 *       determines Y1/Y2 rate, computes amount, INSERTs commission row.
 *
 *   - create_for_renewal( $renewal_order, $parent_order )
 *       Called from WC\Subscription_Hook when a WC Subscription renews.
 *       Looks up the parent order's affiliate, creates a fresh commission
 *       row at Y2+ rate.
 *
 *   - apply_refund( $order_id, $refunded_total_cents )
 *       Called from WC\Refund_Hook. Partial refunds scale the commission
 *       down proportionally; full refunds mark as 'refunded'.
 *
 * Rate resolution priority (highest wins):
 *   1. Affiliate's `custom_rate_override_bp`        (if set, flat rate for all)
 *   2. Affiliate's `commission_rate_y1_bp`           (if first purchase from this customer)
 *   3. Affiliate's `commission_rate_y2plus_bp`       (returning customer)
 *
 * Rate is in basis points: 2500 = 25.00%. Commission amount in cents.
 */
final class Engine {

	/**
	 * Main entry point. Called on `woocommerce_order_status_completed` (and
	 * similar) by WC\Order_Hook. Idempotent — refuses to double-create if
	 * a commission row already exists for this order.
	 *
	 * @return int|null Commission row ID, or null if no commission created.
	 */
	public static function create_for_order( \WC_Order $order ): ?int {
		// Idempotency: don't double-create if a commission already exists.
		if ( self::commission_exists_for_order( $order->get_id() ) ) {
			return null;
		}

		$attribution = Attribution_Resolver::resolve_for_order( $order );
		if ( $attribution === null ) {
			return null;  // no affiliate → no commission, nothing to do
		}

		$aff = Affiliate_Repository::find( $attribution['affiliate_id'] );
		if ( ! $aff || $aff->status !== 'approved' ) {
			self::log_event( 'commission.skipped.bad_affiliate', $attribution['affiliate_id'], [
				'order_id'      => $order->get_id(),
				'aff_status'    => $aff->status ?? 'not_found',
			] );
			return null;
		}

		// Rate selection
		$rate_year     = self::is_first_purchase( (string) $order->get_billing_email(), $order->get_id() ) ? 1 : 2;
		[ $rate_bp ]   = self::resolve_rate( $aff, $rate_year );
		// Per-product rate override (Sprint 9B — WC\Product_Rates).
		$rate_bp = (int) apply_filters( 'asteris_aff_resolved_rate_bp', $rate_bp, $order, $aff, $rate_year );

		// Amount calc — commission is on order SUBTOTAL (excludes shipping + tax).
		// Industry standard. Customer can override later via filter.
		$subtotal_dollars = (float) $order->get_subtotal();
		$subtotal_dollars = (float) apply_filters( 'asteris_aff_commissionable_subtotal', $subtotal_dollars, $order, $aff );
		$subtotal_cents   = (int) round( $subtotal_dollars * 100 );
		$amount_cents     = (int) round( $subtotal_cents * ( $rate_bp / 10000 ) );

		if ( $amount_cents <= 0 ) {
			self::log_event( 'commission.skipped.zero_amount', $aff->id, [
				'order_id' => $order->get_id(),
				'subtotal' => $subtotal_cents,
				'rate_bp'  => $rate_bp,
			] );
			return null;
		}

		// Refund window — commissions stay 'pending' until this many days after
		// order completion. Settings::refund_window_days (default 30, 0–90).
		$refund_days = max( 0, min( 90, (int) Settings::get( 'refund_window_days', 30 ) ) );
		$refund_ends = gmdate( 'Y-m-d H:i:s', time() + ( $refund_days * DAY_IN_SECONDS ) );

		$now = current_time( 'mysql', true );

		global $wpdb;
		$ok = $wpdb->insert( $wpdb->prefix . 'aff_commissions', [
			'affiliate_id'       => (int) $aff->id,
			'order_id'           => $order->get_id(),
			'order_item_id'      => null,                         // per-order, not per-line-item
			'referral_id'        => $attribution['referral_id'],
			'attribution_type'   => $attribution['attribution_type'],
			'coupon_code'        => $attribution['coupon_code'],
			'customer_email'     => strtolower( (string) $order->get_billing_email() ),
			'amount_cents'       => $amount_cents,
			'currency'           => self::resolve_currency( $order ),
			'rate_bp'            => $rate_bp,
			'rate_year'          => $rate_year,
			'status'             => $refund_days === 0 ? 'approved' : 'pending',
			'refund_window_ends' => $refund_ends,
			'approved_at'        => $refund_days === 0 ? $now : null,
			'created_at'         => $now,
		] );
		if ( ! $ok ) { return null; }
		$commission_id = (int) $wpdb->insert_id;

		// Mark the referral as converted so the affiliate's stats show
		// the conversion timestamp.
		if ( $attribution['referral_id'] ) {
			$wpdb->update(
				$wpdb->prefix . 'aff_referrals',
				[ 'converted_at' => $now, 'converted_order_id' => $order->get_id() ],
				[ 'id' => $attribution['referral_id'] ]
			);
		}

		self::log_event( 'commission.created', $aff->id, [
			'commission_id'    => $commission_id,
			'order_id'         => $order->get_id(),
			'amount_cents'     => $amount_cents,
			'rate_bp'          => $rate_bp,
			'rate_year'        => $rate_year,
			'attribution_type' => $attribution['attribution_type'],
		] );

		// Fire MLM tier2 + aggregates refresh (Sprint 9C + 10+)
		do_action( 'asteris_aff_commission_created', $commission_id, (int) $aff->id, $amount_cents, $order );
		do_action( 'asteris_aff_commission_changed', (int) $aff->id );

		return $commission_id;
	}

	/**
	 * WC Subscriptions renewal — fires from WC\Subscription_Hook on
	 * `woocommerce_subscription_renewal_payment_complete`. We look at the
	 * parent (original) order to find the original affiliate and create a
	 * fresh commission row for the renewal at the Y2+ rate.
	 *
	 * Returns commission ID or null.
	 */
	public static function create_for_renewal( \WC_Order $renewal_order, int $parent_order_id ): ?int {
		if ( self::commission_exists_for_order( $renewal_order->get_id() ) ) {
			return null;
		}

		// Find the affiliate from the parent (original) order's commission row.
		global $wpdb;
		$parent_aff_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT affiliate_id FROM {$wpdb->prefix}aff_commissions
			 WHERE order_id = %d LIMIT 1",
			$parent_order_id
		) );
		if ( ! $parent_aff_id ) {
			return null;  // original order wasn't affiliate-attributed
		}

		$aff = Affiliate_Repository::find( $parent_aff_id );
		if ( ! $aff || $aff->status !== 'approved' ) { return null; }

		// Renewals are always Y2+ rate (subscriber by definition is returning).
		[ $rate_bp ] = self::resolve_rate( $aff, 2 );

		$subtotal_cents = (int) round( ( (float) $renewal_order->get_subtotal() ) * 100 );
		$amount_cents   = (int) round( $subtotal_cents * ( $rate_bp / 10000 ) );
		if ( $amount_cents <= 0 ) { return null; }

		$refund_days = max( 0, min( 90, (int) Settings::get( 'refund_window_days', 30 ) ) );
		$refund_ends = gmdate( 'Y-m-d H:i:s', time() + ( $refund_days * DAY_IN_SECONDS ) );
		$now = current_time( 'mysql', true );

		$wpdb->insert( $wpdb->prefix . 'aff_commissions', [
			'affiliate_id'       => (int) $aff->id,
			'order_id'           => $renewal_order->get_id(),
			'referral_id'        => null,                       // renewals don't have a fresh click
			'attribution_type'   => 'renewal',
			'customer_email'     => strtolower( (string) $renewal_order->get_billing_email() ),
			'amount_cents'       => $amount_cents,
			'currency'           => self::resolve_currency( $renewal_order ),
			'rate_bp'            => $rate_bp,
			'rate_year'          => 2,
			'status'             => $refund_days === 0 ? 'approved' : 'pending',
			'refund_window_ends' => $refund_ends,
			'approved_at'        => $refund_days === 0 ? $now : null,
			'created_at'         => $now,
		] );
		$id = (int) $wpdb->insert_id;
		self::log_event( 'commission.renewal_created', $aff->id, [
			'commission_id'   => $id,
			'renewal_order'   => $renewal_order->get_id(),
			'parent_order'    => $parent_order_id,
			'amount_cents'    => $amount_cents,
			'rate_bp'         => $rate_bp,
		] );
		do_action( 'asteris_aff_commission_changed', (int) $aff->id );
		return $id;
	}

	/**
	 * Apply refund clawback. Called from WC\Refund_Hook.
	 *
	 * Strategy:
	 *   - FULL refund (order_subtotal_refunded >= order_subtotal):
	 *       mark commission as 'refunded', record reason
	 *   - PARTIAL refund:
	 *       scale commission down proportionally
	 *       (new_amount = original * (1 - refund_fraction))
	 *       still 'approved'/'pending' — only flips to 'refunded' if amount=0
	 */
	public static function apply_refund( int $order_id, ?string $reason = null ): void {
		global $wpdb;
		$commission = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_commissions WHERE order_id = %d LIMIT 1",
			$order_id
		) );
		if ( ! $commission ) { return; }

		// If already refunded, no-op
		if ( (string) $commission->status === 'refunded' ) { return; }

		$order = wc_get_order( $order_id );
		if ( ! $order ) { return; }

		$order_subtotal = (float) $order->get_subtotal();
		$total_refunded = (float) $order->get_total_refunded();    // dollars

		// Order_total_refunded includes tax + shipping refunds — we want
		// the proportion of SUBTOTAL refunded. Approximation:
		// fraction = min(1, total_refunded / order_total)
		$order_total    = (float) $order->get_total();
		$refund_fraction = $order_total > 0 ? min( 1.0, $total_refunded / $order_total ) : 1.0;

		$now = current_time( 'mysql', true );

		if ( $refund_fraction >= 0.999 ) {
			$wpdb->update(
				$wpdb->prefix . 'aff_commissions',
				[
					'status'         => 'refunded',
					'refunded_at'    => $now,
					'refund_reason'  => $reason ? substr( $reason, 0, 64 ) : 'full_refund',
					'amount_cents'   => 0,
				],
				[ 'id' => $commission->id ]
			);
			self::log_event( 'commission.refunded_full', (int) $commission->affiliate_id, [
				'commission_id' => (int) $commission->id,
				'order_id'      => $order_id,
				'original'      => (int) $commission->amount_cents,
			] );
		} else {
			$new_amount = (int) round( (int) $commission->amount_cents * ( 1 - $refund_fraction ) );
			$wpdb->update(
				$wpdb->prefix . 'aff_commissions',
				[
					'amount_cents'  => $new_amount,
					'refund_reason' => $reason ? substr( $reason, 0, 64 ) : 'partial_refund',
				],
				[ 'id' => $commission->id ]
			);
			self::log_event( 'commission.refunded_partial', (int) $commission->affiliate_id, [
				'commission_id' => (int) $commission->id,
				'order_id'      => $order_id,
				'original'      => (int) $commission->amount_cents,
				'new_amount'    => $new_amount,
				'fraction'      => $refund_fraction,
			] );
		}
		do_action( 'asteris_aff_commission_changed', (int) $commission->affiliate_id );
	}

	// ── Helpers ─────────────────────────────────────────────────────────────

	private static function commission_exists_for_order( int $order_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT 1 FROM {$wpdb->prefix}aff_commissions WHERE order_id = %d LIMIT 1",
			$order_id
		) );
	}

	/**
	 * Y1/Y2 detection: has this customer email had any prior PAID WC order
	 * (excluding the current one)? If yes → Y2+; if no → Y1.
	 */
	private static function is_first_purchase( string $email, int $current_order_id ): bool {
		if ( $email === '' ) { return true; }  // can't tell, give them Y1 rate
		if ( ! function_exists( 'wc_get_orders' ) ) { return true; }

		$prior = wc_get_orders( [
			'billing_email' => $email,
			'status'        => [ 'wc-completed', 'wc-processing' ],
			'limit'         => 2,                                  // we only need 1, get 2 for safety
			'return'        => 'ids',
			'exclude'       => [ $current_order_id ],
		] );
		return empty( $prior );
	}

	/**
	 * Returns [rate_bp, source_label] for an affiliate based on year.
	 * Custom override beats Y1 + Y2 rates.
	 */
	private static function resolve_rate( object $aff, int $year ): array {
		if ( ! empty( $aff->custom_rate_override_bp ) ) {
			return [ (int) $aff->custom_rate_override_bp, 'custom' ];
		}
		if ( $year === 1 ) {
			return [ (int) $aff->commission_rate_y1_bp, 'y1' ];
		}
		return [ (int) $aff->commission_rate_y2plus_bp, 'y2plus' ];
	}

	/**
	 * Currency for THIS commission row.
	 * Priority: admin-picked setting → order's currency → USD.
	 * Per Nick's rule: NO autodetection. Admin's pick from Settings dropdown wins.
	 */
	private static function resolve_currency( \WC_Order $order ): string {
		$picked = strtoupper( (string) Settings::get( 'commission_currency', 'USD' ) );
		if ( \AsterisAffiliates\Core\Currencies::is_valid( $picked ) ) {
			return $picked;
		}
		$wc_currency = strtoupper( (string) $order->get_currency() );
		return \AsterisAffiliates\Core\Currencies::is_valid( $wc_currency ) ? $wc_currency : 'USD';
	}

	private static function log_event( string $event_type, ?int $affiliate_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event_type,
			'affiliate_id' => $affiliate_id,
			'actor'        => 'system',
			'payload'      => wp_json_encode( $payload ),
		] );
	}
}
