<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Commissions;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Two-tier MLM commissions.
 *
 * When commission C is created for affiliate A, and A has a `parent_affiliate_id` P:
 *   → also create a tier-2 commission for P at P's `tier2_rate_bp` rate
 *
 * The tier-2 amount is calculated against THE SAME ORDER SUBTOTAL as the
 * primary commission — NOT against the primary commission amount. This keeps
 * the math clear: parent earns a small slice of the gross, not a slice of
 * the affiliate's slice.
 *
 * Schema fields used:
 *   - affiliates.parent_affiliate_id (existing, from v1.0)
 *   - affiliates.tier2_rate_bp       (new in v1.1 — default 500 bp = 5%)
 *   - commissions.tier_level         (new — 1=primary, 2=tier2)
 *   - commissions.parent_commission_id (new — links tier2 → primary)
 *
 * Hook: 'asteris_aff_commission_created' fires from Engine after the primary
 * commission row insert.
 *
 * Safety:
 *   - No infinite loops (only TWO tiers — parent of parent is ignored)
 *   - Parent must be approved (suspended/rejected parents earn nothing)
 *   - Settings::get('mlm_enabled') gates the whole module
 */
final class Tier2_Engine {

	public static function register(): void {
		add_action( 'asteris_aff_commission_created', [ self::class, 'maybe_create_tier2' ], 10, 4 );
	}

	public static function maybe_create_tier2( int $commission_id, int $affiliate_id, int $amount_cents, \WC_Order $order ): void {
		// Pro-only feature
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'mlm' ) ) { return; }
		if ( ! (int) Settings::get( 'mlm_enabled', 0 ) ) { return; }

		$child = Affiliate_Repository::find( $affiliate_id );
		if ( ! $child || empty( $child->parent_affiliate_id ) ) { return; }

		$parent_id = (int) $child->parent_affiliate_id;
		$parent    = Affiliate_Repository::find( $parent_id );
		if ( ! $parent || $parent->status !== 'approved' ) { return; }

		// Use parent's tier2 rate (defaults to 5% from schema)
		$tier2_rate_bp = (int) ( $parent->tier2_rate_bp ?? 500 );
		if ( $tier2_rate_bp <= 0 ) { return; }

		$subtotal_cents  = (int) round( ( (float) $order->get_subtotal() ) * 100 );
		$tier2_amount    = (int) round( $subtotal_cents * ( $tier2_rate_bp / 10000 ) );
		if ( $tier2_amount <= 0 ) { return; }

		$refund_days = max( 0, min( 90, (int) Settings::get( 'refund_window_days', 30 ) ) );
		$refund_ends = gmdate( 'Y-m-d H:i:s', time() + ( $refund_days * DAY_IN_SECONDS ) );
		$now = current_time( 'mysql', true );

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_commissions', [
			'affiliate_id'         => $parent_id,
			'order_id'             => $order->get_id(),
			'order_item_id'        => null,
			'attribution_type'     => 'tier2',
			'customer_email'       => strtolower( (string) $order->get_billing_email() ),
			'amount_cents'         => $tier2_amount,
			'currency'             => self::resolve_currency( $order ),
			'rate_bp'              => $tier2_rate_bp,
			'rate_year'            => 1,
			'tier_level'           => 2,
			'parent_commission_id' => $commission_id,
			'source'               => 'wc',
			'status'               => $refund_days === 0 ? 'approved' : 'pending',
			'refund_window_ends'   => $refund_ends,
			'approved_at'          => $refund_days === 0 ? $now : null,
			'created_at'           => $now,
		] );
		$tier2_id = (int) $wpdb->insert_id;

		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'commission.tier2_created',
			'affiliate_id' => $parent_id,
			'actor'        => 'system',
			'payload'      => wp_json_encode( [
				'tier2_commission_id'  => $tier2_id,
				'parent_commission_id' => $commission_id,
				'child_affiliate_id'   => $affiliate_id,
				'amount_cents'         => $tier2_amount,
				'rate_bp'              => $tier2_rate_bp,
			] ),
		] );

		do_action( 'asteris_aff_commission_changed', $parent_id );
	}

	private static function resolve_currency( \WC_Order $order ): string {
		$picked = strtoupper( (string) Settings::get( 'commission_currency', 'USD' ) );
		if ( \AsterisAffiliates\Core\Currencies::is_valid( $picked ) ) { return $picked; }
		$wc = strtoupper( (string) $order->get_currency() );
		return \AsterisAffiliates\Core\Currencies::is_valid( $wc ) ? $wc : 'USD';
	}
}
