<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Commissions;

defined( 'ABSPATH' ) || exit;

/**
 * Flips commissions from `pending` → `approved` once their
 * `refund_window_ends` timestamp has passed.
 *
 * Runs daily via Daily_Cron. Idempotent — safe to run multiple times
 * per day (UPDATE only catches rows still in pending state).
 *
 * Refunded / rejected commissions are untouched. Manually-approved-early
 * commissions stay approved.
 */
final class Approval_Scanner {

	/** @return int rows flipped */
	public static function run(): int {
		global $wpdb;
		$now = current_time( 'mysql', true );

		$affected = $wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_commissions
			 SET status = 'approved', approved_at = %s
			 WHERE status = 'pending'
			 AND refund_window_ends <= %s",
			$now,
			$now
		) );

		return (int) $affected;
	}
}
