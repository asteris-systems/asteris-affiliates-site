<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Public_;

use AsterisAffiliates\Affiliates\Affiliate_Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Passwordless sign-in for the affiliate portal.
 *
 *   - Affiliate requests sign-in by submitting their email
 *   - We HMAC-sign a token (email + expiry) and email it as a link
 *   - Click → verify token → set auth cookie (separate from WP login)
 *   - Cookie persists 30 days
 *
 * Anti-enumeration: ALWAYS show "we sent a link" even if email isn't on
 * file. Prevents attackers from probing the affiliate list.
 *
 * Auth cookie: `aff_portal_auth` = base64( affiliate_id . '|' . expiry . '|' . hmac )
 * Separate from WP login so affiliates don't get WP admin access.
 */
final class Magic_Link_Auth {

	public const TOKEN_TTL  = 900;             // 15 min link validity
	public const COOKIE_TTL = 30 * DAY_IN_SECONDS;
	public const COOKIE     = 'aff_portal_auth';

	// ── Token (link) ────────────────────────────────────────────────────────

	public static function make_token( string $email ): string {
		$expiry  = time() + self::TOKEN_TTL;
		$payload = strtolower( $email ) . '|' . $expiry;
		$sig     = hash_hmac( 'sha256', $payload, self::secret() );
		return rtrim( strtr( base64_encode( $payload . '|' . $sig ), '+/', '-_' ), '=' );
	}

	public static function verify_token( string $token ): ?string {
		$decoded = base64_decode( strtr( $token, '-_', '+/' ), true );
		if ( $decoded === false ) { return null; }
		$parts = explode( '|', $decoded );
		if ( count( $parts ) !== 3 ) { return null; }
		[ $email, $expiry, $sig ] = $parts;
		if ( (int) $expiry < time() ) { return null; }
		$expected = hash_hmac( 'sha256', $email . '|' . $expiry, self::secret() );
		if ( ! hash_equals( $expected, $sig ) ) { return null; }

		// Single-use enforcement (P0 fix v1.0.0-alpha.4): once a token verifies
		// successfully, mark it burned. Subsequent attempts to replay it return
		// null. Burn key = hash of the token itself; TTL = remaining lifetime.
		$burn_key = 'aff_token_burned_' . substr( hash( 'sha256', $token ), 0, 32 );
		if ( get_transient( $burn_key ) ) {
			return null;  // already used — replay attempt
		}
		set_transient( $burn_key, 1, max( 60, (int) $expiry - time() + 60 ) );

		return $email;
	}

	public static function magic_link_url( string $email ): string {
		return add_query_arg( [
			'aff_action' => 'verify',
			'token'      => self::make_token( $email ),
		], home_url( '/affiliate-portal/' ) );
	}

	// ── Session cookie ──────────────────────────────────────────────────────

	public static function set_auth_cookie( int $affiliate_id ): void {
		if ( headers_sent() ) { return; }
		$expiry = time() + self::COOKIE_TTL;
		$payload = $affiliate_id . '|' . $expiry;
		$sig = hash_hmac( 'sha256', $payload, self::secret() );
		$val = base64_encode( $payload . '|' . $sig );
		setcookie( self::COOKIE, $val, [
			'expires'  => $expiry,
			'path'     => '/',
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		] );
		$_COOKIE[ self::COOKIE ] = $val;
		Affiliate_Repository::update( $affiliate_id, [ 'last_login_at' => current_time( 'mysql', true ) ] );
	}

	public static function clear_auth_cookie(): void {
		if ( headers_sent() ) { return; }
		setcookie( self::COOKIE, '', [
			'expires'  => time() - 3600,
			'path'     => '/',
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		] );
		unset( $_COOKIE[ self::COOKIE ] );
	}

	/**
	 * Returns the authenticated affiliate (DB row) or null.
	 * Side-effect-free; safe to call on every page load.
	 */
	public static function current_affiliate(): ?object {
		$val = $_COOKIE[ self::COOKIE ] ?? '';
		if ( ! is_string( $val ) || $val === '' ) { return null; }
		$decoded = base64_decode( $val, true );
		if ( $decoded === false ) { return null; }
		$parts = explode( '|', $decoded );
		if ( count( $parts ) !== 3 ) { return null; }
		[ $affiliate_id, $expiry, $sig ] = $parts;
		if ( (int) $expiry < time() ) { return null; }
		$expected = hash_hmac( 'sha256', $affiliate_id . '|' . $expiry, self::secret() );
		if ( ! hash_equals( $expected, $sig ) ) { return null; }
		$aff = Affiliate_Repository::find( (int) $affiliate_id );
		if ( ! $aff || $aff->status !== 'approved' ) { return null; }
		return $aff;
	}

	// ── Sending the magic link ──────────────────────────────────────────────

	/**
	 * Sends the sign-in email. Always returns true (anti-enumeration —
	 * caller can't tell whether the email matched a real affiliate).
	 */
	public static function send_link( string $email ): bool {
		$email = strtolower( trim( $email ) );
		if ( ! is_email( $email ) ) { return true; }

		$aff = Affiliate_Repository::find_by_email( $email );
		if ( ! $aff || $aff->status !== 'approved' ) {
			return true; // anti-enumeration
		}

		$url     = self::magic_link_url( $email );
		$subject = 'Your sign-in link · ' . wp_specialchars_decode( (string) get_bloginfo( 'name' ) ) . ' affiliate portal';
		$body    = sprintf(
			"Hi %s,\n\nClick to sign in to the affiliate portal:\n\n%s\n\nThis link expires in 15 minutes and can only be used once.\n\nIf you didn't request this, ignore this email.\n",
			$aff->display_name,
			$url
		);
		return (bool) wp_mail( $email, $subject, $body );
	}

	// ── Internals ───────────────────────────────────────────────────────────

	private static function secret(): string {
		// Per-site secret; auto-generated on first use. Separate from any
		// shared Asteris-licence-server secret (different concern).
		$opt = (string) get_option( 'asteris_aff_auth_secret', '' );
		if ( $opt === '' ) {
			$opt = bin2hex( random_bytes( 32 ) );
			update_option( 'asteris_aff_auth_secret', $opt, false );
		}
		return $opt;
	}
}
