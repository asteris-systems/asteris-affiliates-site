<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Public_;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Tracking\Click_Tracker;

defined( 'ABSPATH' ) || exit;

/**
 * Vanity landing pages at /go/{handle}.
 *
 * Each affiliate can create one or more branded landing pages with custom
 * headline / subhead / CTA / hero image. The page sets the affiliate's
 * tracking cookie (via Click_Tracker) and presents a one-click CTA to the
 * destination URL.
 *
 * Benefits over plain ?ref= links:
 *   - Cleaner URL to share (instagram bio, podcast notes etc)
 *   - Custom messaging per channel
 *   - View counting (independent of click-through)
 *
 * Schema: wp_aff_landing_pages.
 */
final class Landing_Page_Router {

	public const PREFIX = '/go/';

	public static function register(): void {
		add_action( 'init', [ self::class, 'add_rewrite' ] );
		add_action( 'template_redirect', [ self::class, 'maybe_handle' ], 5 );
	}

	public static function add_rewrite(): void {
		add_rewrite_rule( '^go/([^/]+)/?$', 'index.php?aff_landing=$matches[1]', 'top' );
		add_rewrite_tag( '%aff_landing%', '([^&]+)' );
	}

	public static function maybe_handle(): void {
		$uri  = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		if ( ! str_starts_with( $path, self::PREFIX ) ) { return; }
		// Pro-only — free tier returns 404 for /go/* routes
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'landing_pages' ) ) {
			status_header( 404 );
			return;
		}
		$handle = trim( substr( $path, strlen( self::PREFIX ) ), '/' );
		$handle = sanitize_key( $handle );
		if ( $handle === '' ) { return; }

		$page = self::find_by_handle( $handle );
		if ( ! $page ) {
			status_header( 404 );
			nocache_headers();
			get_header();
			echo '<div style="text-align:center;padding:80px 20px;"><h1>Page not found</h1><p>This landing page is no longer active.</p></div>';
			get_footer();
			exit;
		}

		$aff = Affiliate_Repository::find( (int) $page->affiliate_id );
		if ( ! $aff || $aff->status !== 'approved' ) {
			status_header( 410 );
			nocache_headers();
			get_header();
			echo '<div style="text-align:center;padding:80px 20px;"><h1>Page unavailable</h1></div>';
			get_footer();
			exit;
		}

		// Set the affiliate tracking cookie as if they'd clicked ?ref=public_id
		Click_Tracker::record_landing( $aff, [ 'source' => 'landing_page', 'handle' => $handle ] );

		// Bump view counter
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_landing_pages SET views = views + 1 WHERE id = %d",
			(int) $page->id
		) );

		self::render( $page, $aff );
		exit;
	}

	public static function find_by_handle( string $handle ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_landing_pages WHERE handle = %s AND active = 1 LIMIT 1",
			$handle
		) );
		return $row ?: null;
	}

	private static function render( object $page, object $aff ): void {
		status_header( 200 );
		nocache_headers();
		$cta_url = (string) ( $page->cta_target_url ?: home_url( '/' ) );
		$hero    = (string) ( $page->hero_image_url ?: '' );

		?><!doctype html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width,initial-scale=1">
			<meta name="robots" content="noindex,follow">
			<title><?php echo esc_html( $page->headline ?: get_bloginfo( 'name' ) ); ?></title>
			<style>
				body{margin:0;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#0a0a0a;color:#fff;}
				.hero{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:40px 20px;background:linear-gradient(135deg,#06D6A0,#0a857a);}
				.box{max-width:680px;text-align:center;}
				.box h1{font-size:48px;line-height:1.1;margin:0 0 16px;letter-spacing:-1px;}
				.box p{font-size:19px;line-height:1.5;margin:0 0 32px;opacity:0.95;}
				.cta{display:inline-block;background:#fff;color:#0a857a;padding:18px 36px;border-radius:10px;text-decoration:none;font-weight:800;font-size:18px;}
				img.hero-img{max-width:100%;height:auto;margin:0 auto 30px;display:block;border-radius:12px;}
				.byline{margin-top:30px;opacity:0.7;font-size:13px;}
				@media (max-width:480px){.box h1{font-size:32px;}.box p{font-size:16px;}}
			</style>
		</head>
		<body>
		<div class="hero">
			<div class="box">
				<?php if ( $hero ) : ?><img class="hero-img" src="<?php echo esc_url( $hero ); ?>" alt=""><?php endif; ?>
				<h1><?php echo esc_html( $page->headline ?: get_bloginfo( 'name' ) ); ?></h1>
				<?php if ( $page->subhead ) : ?><p><?php echo wp_kses_post( $page->subhead ); ?></p><?php endif; ?>
				<a class="cta" href="<?php echo esc_url( $cta_url ); ?>"><?php echo esc_html( $page->cta_label ?: __( 'Get started →', 'asteris-affiliates' ) ); ?></a>
				<div class="byline"><?php
					/* translators: %s = affiliate display name */
					echo esc_html( sprintf( __( 'Shared by %s', 'asteris-affiliates' ), $aff->display_name ) );
				?></div>
			</div>
		</div>
		</body>
		</html>
		<?php
	}
}
