<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Public_;

use AsterisAffiliates\Affiliates\Affiliate_Repository;

defined( 'ABSPATH' ) || exit;

/**
 * 4-step onboarding wizard shown to new affiliates on first portal login.
 *
 *   1. Welcome (program rules + commission rates)
 *   2. Verify profile (display name, country)
 *   3. Connect payouts (Stripe Express / PayPal / Bank)
 *   4. Share your first link (tracking URL + swipe copy preview)
 *
 * Trigger: when `onboarding_completed_at` is NULL on the affiliate row.
 * Once any step is "skipped" or all 4 are completed, set the timestamp.
 *
 * Portal_Router::render_logged_in() calls Onboarding_Wizard::maybe_intercept
 * before normal tab rendering.
 */
final class Onboarding_Wizard {

	public static function maybe_intercept( object $aff ): bool {
		if ( ! empty( $aff->onboarding_completed_at ) ) { return false; }
		if ( isset( $_GET['skip_wizard'] ) ) {
			Affiliate_Repository::update( (int) $aff->id, [ 'onboarding_completed_at' => current_time( 'mysql', true ) ] );
			return false;
		}
		$step = isset( $_GET['wizard_step'] ) ? max( 1, min( 4, (int) $_GET['wizard_step'] ) ) : 1;
		self::render( $aff, $step );
		return true;
	}

	private static function render( object $aff, int $step ): void {
		$portal = '/affiliate-portal/';
		?>
		<div style="max-width:680px;margin:40px auto;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:30px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;">
			<!-- Step progress -->
			<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
				<?php foreach ( [ 1, 2, 3, 4 ] as $n ) :
					$active = $n === $step;
					$done   = $n < $step;
					$bg = $done ? '#06D6A0' : ( $active ? '#0a857a' : '#e5e7eb' );
					$fg = ( $done || $active ) ? '#fff' : '#9ca3af';
				?>
					<div style="display:flex;align-items:center;gap:10px;flex:1;">
						<div style="width:32px;height:32px;border-radius:50%;background:<?php echo esc_attr( $bg ); ?>;color:<?php echo esc_attr( $fg ); ?>;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;flex-shrink:0;"><?php echo $done ? '✓' : esc_html( (string) $n ); ?></div>
						<?php if ( $n < 4 ) : ?><div style="flex:1;height:2px;background:<?php echo esc_attr( $n < $step ? '#06D6A0' : '#e5e7eb' ); ?>;"></div><?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<a href="<?php echo esc_url( $portal . '?skip_wizard=1' ); ?>" style="float:right;color:#9ca3af;text-decoration:none;font-size:12px;"><?php esc_html_e( 'Skip wizard →', 'asteris-affiliates' ); ?></a>

			<?php
			switch ( $step ) {
				case 1: self::step_welcome( $aff ); break;
				case 2: self::step_profile( $aff ); break;
				case 3: self::step_payouts( $aff ); break;
				case 4: self::step_share( $aff ); break;
			}
			?>
		</div>
		<?php
	}

	private static function step_welcome( object $aff ): void {
		?>
		<h1 style="margin:0 0 8px;font-size:28px;">👋 <?php
			/* translators: %s = affiliate display name */
			echo esc_html( sprintf( __( 'Welcome aboard, %s!', 'asteris-affiliates' ), $aff->display_name ) );
		?></h1>
		<p style="margin:0 0 22px;color:#666;font-size:15px;"><?php esc_html_e( 'A 4-step quick tour to get your first commission today. Takes ~3 minutes.', 'asteris-affiliates' ); ?></p>
		<ul style="list-style:none;padding:0;margin:0 0 28px;font-size:14px;">
			<li style="padding:8px 0;border-bottom:1px solid #f3f4f6;">✅ <strong><?php esc_html_e( 'Verify your profile', 'asteris-affiliates' ); ?></strong></li>
			<li style="padding:8px 0;border-bottom:1px solid #f3f4f6;">💳 <strong><?php esc_html_e( 'Connect payouts', 'asteris-affiliates' ); ?></strong> — <?php esc_html_e( 'Stripe, PayPal or bank transfer', 'asteris-affiliates' ); ?></li>
			<li style="padding:8px 0;">🔗 <strong><?php esc_html_e( 'Grab your tracking link', 'asteris-affiliates' ); ?></strong></li>
		</ul>
		<a href="<?php echo esc_url( '/affiliate-portal/?wizard_step=2' ); ?>" style="display:inline-block;background:#06D6A0;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;"><?php esc_html_e( 'Get started →', 'asteris-affiliates' ); ?></a>
		<?php
	}

	private static function step_profile( object $aff ): void {
		?>
		<h2 style="margin:0 0 8px;font-size:22px;"><?php esc_html_e( 'Verify your profile', 'asteris-affiliates' ); ?></h2>
		<p style="color:#666;margin:0 0 16px;"><?php esc_html_e( 'Make sure your display name and country are correct. You can update later in Profile.', 'asteris-affiliates' ); ?></p>
		<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:14px 16px;margin-bottom:18px;">
			<div style="display:flex;justify-content:space-between;padding:6px 0;font-size:14px;">
				<strong><?php esc_html_e( 'Display name', 'asteris-affiliates' ); ?></strong>
				<span><?php echo esc_html( $aff->display_name ); ?></span>
			</div>
			<div style="display:flex;justify-content:space-between;padding:6px 0;font-size:14px;">
				<strong><?php esc_html_e( 'Email', 'asteris-affiliates' ); ?></strong>
				<span><?php echo esc_html( $aff->email ); ?></span>
			</div>
			<div style="display:flex;justify-content:space-between;padding:6px 0;font-size:14px;">
				<strong><?php esc_html_e( 'Country', 'asteris-affiliates' ); ?></strong>
				<span><?php echo esc_html( $aff->country_code ); ?></span>
			</div>
		</div>
		<a href="<?php echo esc_url( '/affiliate-portal/?wizard_step=3' ); ?>" style="display:inline-block;background:#06D6A0;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;"><?php esc_html_e( 'Looks good →', 'asteris-affiliates' ); ?></a>
		<a href="<?php echo esc_url( '/affiliate-portal/?tab=profile' ); ?>" style="display:inline-block;margin-left:8px;color:#06D6A0;padding:12px 18px;text-decoration:none;font-weight:600;"><?php esc_html_e( 'Edit profile', 'asteris-affiliates' ); ?></a>
		<?php
	}

	private static function step_payouts( object $aff ): void {
		?>
		<h2 style="margin:0 0 8px;font-size:22px;"><?php esc_html_e( 'Connect payouts', 'asteris-affiliates' ); ?></h2>
		<p style="color:#666;margin:0 0 18px;"><?php esc_html_e( 'Pick how you want to receive your commissions. You can change this later.', 'asteris-affiliates' ); ?></p>
		<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px;">
			<a href="<?php echo esc_url( '/affiliate-portal/?aff_action=stripe_connect' ); ?>" style="display:block;background:#fff;border:2px solid #06D6A0;border-radius:8px;padding:14px;text-decoration:none;color:#0a0a0a;text-align:center;">
				<div style="font-size:24px;">⚡</div>
				<strong><?php esc_html_e( 'Stripe', 'asteris-affiliates' ); ?></strong>
				<div style="font-size:11px;color:#666;margin-top:4px;"><?php esc_html_e( 'Recommended · auto-paid', 'asteris-affiliates' ); ?></div>
			</a>
			<a href="<?php echo esc_url( '/affiliate-portal/?tab=profile' ); ?>" style="display:block;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px;text-decoration:none;color:#0a0a0a;text-align:center;">
				<div style="font-size:24px;">🅿️</div>
				<strong><?php esc_html_e( 'PayPal', 'asteris-affiliates' ); ?></strong>
				<div style="font-size:11px;color:#666;margin-top:4px;"><?php esc_html_e( 'Manual approval', 'asteris-affiliates' ); ?></div>
			</a>
			<a href="<?php echo esc_url( '/affiliate-portal/?tab=profile' ); ?>" style="display:block;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:14px;text-decoration:none;color:#0a0a0a;text-align:center;">
				<div style="font-size:24px;">🏦</div>
				<strong><?php esc_html_e( 'Bank', 'asteris-affiliates' ); ?></strong>
				<div style="font-size:11px;color:#666;margin-top:4px;"><?php esc_html_e( 'Encrypted at rest', 'asteris-affiliates' ); ?></div>
			</a>
		</div>
		<a href="<?php echo esc_url( '/affiliate-portal/?wizard_step=4' ); ?>" style="display:inline-block;background:#06D6A0;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;"><?php esc_html_e( 'Continue →', 'asteris-affiliates' ); ?></a>
		<a href="<?php echo esc_url( '/affiliate-portal/?wizard_step=4' ); ?>" style="display:inline-block;margin-left:8px;color:#9ca3af;padding:12px 18px;text-decoration:none;"><?php esc_html_e( "I'll do this later", 'asteris-affiliates' ); ?></a>
		<?php
	}

	private static function step_share( object $aff ): void {
		$tracking_url = add_query_arg( 'ref', $aff->public_id, home_url( '/' ) );
		?>
		<h2 style="margin:0 0 8px;font-size:22px;">🔗 <?php esc_html_e( 'Your tracking link is live', 'asteris-affiliates' ); ?></h2>
		<p style="color:#666;margin:0 0 18px;"><?php esc_html_e( 'Anyone who clicks this link earns you commission on whatever they buy in the next 60 days.', 'asteris-affiliates' ); ?></p>
		<div style="background:#0a0a0a;color:#06D6A0;padding:14px 16px;border-radius:8px;font-family:ui-monospace,monospace;font-size:14px;margin-bottom:18px;word-break:break-all;">
			<?php echo esc_html( $tracking_url ); ?>
		</div>
		<button onclick="navigator.clipboard.writeText('<?php echo esc_js( $tracking_url ); ?>'); this.textContent='✓ Copied!';" style="background:#06D6A0;color:#fff;padding:10px 18px;border:0;border-radius:6px;font-weight:700;cursor:pointer;font-size:14px;"><?php esc_html_e( '📋 Copy', 'asteris-affiliates' ); ?></button>
		<a href="<?php echo esc_url( '/affiliate-portal/?skip_wizard=1' ); ?>" style="display:inline-block;margin-left:8px;background:#0a0a0a;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:700;font-size:14px;"><?php esc_html_e( '🚀 Open my dashboard', 'asteris-affiliates' ); ?></a>
		<?php
		Affiliate_Repository::update( (int) $aff->id, [ 'onboarding_completed_at' => current_time( 'mysql', true ) ] );
	}
}
