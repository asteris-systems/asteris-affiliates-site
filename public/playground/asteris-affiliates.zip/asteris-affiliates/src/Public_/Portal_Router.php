<?php
/**
 * @package AsterisAffiliates

 */

namespace AsterisAffiliates\Public_;

defined( 'ABSPATH' ) || exit;

/**
 * Front-end affiliate portal at /affiliate-portal/.
 *
 * Implements as a virtual page (no real WP page required) by intercepting
 * the `template_include` filter when REQUEST_URI matches. Cleaner than
 * forcing the user to create a WP Page + add a shortcode + name it correctly.
 *
 * Sub-routes (all under /affiliate-portal/):
 *   - default          → if logged in: dashboard; else: sign-in form
 *   - ?aff_action=signin    → handle email submit
 *   - ?aff_action=verify    → magic-link verify + set cookie
 *   - ?aff_action=logout    → clear cookie + redirect to sign-in
 *   - ?tab=links            → tracking links + swipe copy
 *   - ?tab=payouts          → payout history (Sprint 5 wires real data)
 *   - ?tab=profile          → profile + bank details (Sprint 5)
 */
final class Portal_Router {

	public const PORTAL_PATH = '/affiliate-portal';

	public static function register(): void {
		add_action( 'template_redirect', [ self::class, 'maybe_handle' ] );
		add_action( 'admin_post_nopriv_asteris_aff_signin', [ self::class, 'handle_signin_request' ] );
		add_action( 'admin_post_asteris_aff_signin',        [ self::class, 'handle_signin_request' ] );
		// Portal-side profile save (affiliate signed in, NOT admin)
		add_action( 'admin_post_asteris_aff_profile_save',  [ self::class, 'handle_profile_save' ] );
	}

	public static function handle_profile_save(): void {
		$aff = Magic_Link_Auth::current_affiliate();
		if ( ! $aff ) { wp_die( 'Sign in first.', 401 ); }
		check_admin_referer( 'asteris_aff_profile_save_' . (int) $aff->id, '_aff_profile_nonce' );

		$display_name = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : $aff->display_name;
		$method       = isset( $_POST['payout_method'] ) ? sanitize_key( wp_unslash( $_POST['payout_method'] ) ) : $aff->payout_method;
		if ( ! in_array( $method, [ 'stripe_connect', 'paypal', 'bank_transfer', 'manual' ], true ) ) {
			$method = $aff->payout_method;
		}

		$update = [
			'display_name'  => $display_name,
			'payout_method' => $method,
			'paypal_email'  => isset( $_POST['paypal_email'] ) ? sanitize_email( wp_unslash( $_POST['paypal_email'] ) ) : $aff->paypal_email,
		];
		// stripe_connect_account_id is now managed exclusively by the
		// Stripe Express onboarding flow (Sprint 8) — affiliates click
		// Connect with Stripe, plugin creates the account. We deliberately
		// don't accept it via this form anymore to prevent affiliates from
		// pasting an arbitrary acct_xxx that doesn't belong to them.

		// Bank details — encrypt if customer typed new content; preserve existing if blank
		$bank_plain = isset( $_POST['bank_details_plain'] ) ? (string) wp_unslash( $_POST['bank_details_plain'] ) : '';
		$bank_changed = false;
		if ( $bank_plain !== '' ) {
			$update['bank_details_encrypted'] = \AsterisAffiliates\Core\Util\Crypto::encrypt( trim( $bank_plain ) );
			$bank_changed = true;
		}

		\AsterisAffiliates\Affiliates\Affiliate_Repository::update( (int) $aff->id, $update );

		// Security email — alert affiliate when bank details change. Same
		// pattern Stripe + every major bank uses ("if this wasn't you, contact support").
		if ( $bank_changed ) {
			\AsterisAffiliates\Email\Renderer::send_template( 'bank_changed', $aff->email, [
				'display_name' => $aff->display_name,
			] );
		}

		// Log the change (don't log the bank plaintext!)
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'affiliate.profile_self_updated',
			'affiliate_id' => (int) $aff->id,
			'actor'        => 'affiliate:' . (int) $aff->id,
			'payload'      => wp_json_encode( [ 'payout_method' => $method, 'bank_details_changed' => $bank_plain !== '' ] ),
		] );

		wp_safe_redirect( home_url( self::PORTAL_PATH . '/?tab=profile&aff_flash=profile_saved' ) );
		exit;
	}

	public static function maybe_handle(): void {
		$uri = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		if ( rtrim( $path, '/' ) !== self::PORTAL_PATH ) { return; }

		// Action dispatch
		$action = isset( $_GET['aff_action'] ) ? sanitize_key( wp_unslash( $_GET['aff_action'] ) ) : '';
		if ( $action === 'verify' ) {
			self::handle_verify();
			return;
		}
		if ( $action === 'logout' ) {
			Magic_Link_Auth::clear_auth_cookie();
			wp_safe_redirect( home_url( self::PORTAL_PATH . '/?aff_flash=logged_out' ) );
			exit;
		}
		// Stripe Express flows — all require an authed affiliate
		if ( in_array( $action, [ 'stripe_connect', 'stripe_return', 'stripe_refresh', 'stripe_dashboard' ], true ) ) {
			self::handle_stripe_action( $action );
			return;
		}

		$affiliate = Magic_Link_Auth::current_affiliate();
		self::render_portal_page( $affiliate );
		exit;
	}

	public static function handle_signin_request(): void {
		check_admin_referer( 'asteris_aff_signin', '_aff_signin_nonce' );
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		Magic_Link_Auth::send_link( $email );
		wp_safe_redirect( home_url( self::PORTAL_PATH . '/?aff_flash=link_sent&e=' . urlencode( $email ) ) );
		exit;
	}

	private static function handle_verify(): void {
		$token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		$email = Magic_Link_Auth::verify_token( $token );
		if ( ! $email ) {
			wp_safe_redirect( home_url( self::PORTAL_PATH . '/?aff_flash=bad_token' ) );
			exit;
		}
		$aff = \AsterisAffiliates\Affiliates\Affiliate_Repository::find_by_email( $email );
		if ( ! $aff || $aff->status !== 'approved' ) {
			wp_safe_redirect( home_url( self::PORTAL_PATH . '/?aff_flash=bad_token' ) );
			exit;
		}
		Magic_Link_Auth::set_auth_cookie( (int) $aff->id );
		wp_safe_redirect( home_url( self::PORTAL_PATH . '/' ) );
		exit;
	}

	// ── Page rendering ──────────────────────────────────────────────────────

	private static function render_portal_page( ?object $affiliate ): void {
		// Use the theme's get_header() / get_footer() so portal sits inside
		// the customer's existing branding.
		status_header( 200 );
		nocache_headers();
		get_header();
		echo '<div class="aff-portal-wrap" style="max-width:960px;margin:40px auto;padding:0 20px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;">';
		self::render_flash();
		if ( ! $affiliate ) {
			self::render_signin_form();
		} else {
			self::render_logged_in( $affiliate );
		}
		echo '</div>';
		get_footer();
	}

	private static function render_flash(): void {
		$flash = isset( $_GET['aff_flash'] ) ? sanitize_key( wp_unslash( $_GET['aff_flash'] ) ) : '';
		$email = isset( $_GET['e'] ) ? sanitize_email( wp_unslash( $_GET['e'] ) ) : '';
		$map = [
			'link_sent'   => [ 'ok',   '✓ If <strong>' . esc_html( $email ) . '</strong> matches an approved affiliate, a sign-in link is on its way (check spam too). The link expires in 15 minutes.' ],
			'bad_token'   => [ 'err',  '✗ That link is invalid or expired. Request a fresh one below.' ],
			'logged_out'  => [ 'ok',   '✓ Signed out.' ],
		];
		if ( ! isset( $map[ $flash ] ) ) { return; }
		[ $kind, $html ] = $map[ $flash ];
		$style = $kind === 'ok'
			? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;';
		echo '<div style="padding:14px 18px;border-radius:8px;margin-bottom:18px;font-size:14px;' . esc_attr( $style ) . '"><p style="margin:0;">' . $html . '</p></div>'; // phpcs:ignore
	}

	private static function render_signin_form(): void {
		?>
		<div style="max-width:480px;margin:60px auto;">
			<h1 style="margin:0 0 6px;">Affiliate portal</h1>
			<p style="margin:0 0 28px;color:#666;">Enter your email — we'll send a sign-in link.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:24px;">
				<?php wp_nonce_field( 'asteris_aff_signin', '_aff_signin_nonce' ); ?>
				<input type="hidden" name="action" value="asteris_aff_signin">
				<label style="display:block;margin-bottom:14px;">
					<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Email</span>
					<input type="email" name="email" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
				</label>
				<button type="submit" style="background:#06D6A0;color:#fff;border:0;padding:11px 22px;border-radius:6px;font-size:15px;font-weight:700;cursor:pointer;width:100%;">Send sign-in link →</button>
			</form>
			<p style="margin:20px 0 0;color:#666;font-size:13px;text-align:center;">Not an affiliate yet? <a href="<?php echo esc_url( home_url( '/become-an-affiliate/' ) ); ?>" style="color:#06D6A0;font-weight:600;">Apply here</a>.</p>
		</div>
		<?php
	}

	// ── Stripe Express onboarding flow ──────────────────────────────────────

	private static function handle_stripe_action( string $action ): void {
		$aff = Magic_Link_Auth::current_affiliate();
		if ( ! $aff ) {
			wp_safe_redirect( home_url( self::PORTAL_PATH . '/' ) );
			exit;
		}

		$profile_url = home_url( self::PORTAL_PATH . '/?tab=profile' );
		$return_url  = home_url( self::PORTAL_PATH . '/?aff_action=stripe_return' );
		$refresh_url = home_url( self::PORTAL_PATH . '/?aff_action=stripe_refresh' );

		// 1. Initial Connect click → create account (if not already) + onboarding link
		if ( $action === 'stripe_connect' ) {
			$account_id = (string) $aff->stripe_connect_account_id;
			if ( $account_id === '' ) {
				$created = \AsterisAffiliates\Payouts\Stripe_Express::create_account( $aff );
				if ( is_wp_error( $created ) ) {
					wp_safe_redirect( add_query_arg( [ 'aff_flash' => 'stripe_create_failed', 'msg' => urlencode( $created->get_error_message() ) ], $profile_url ) );
					exit;
				}
				$account_id = $created;
				\AsterisAffiliates\Affiliates\Affiliate_Repository::update( (int) $aff->id, [
					'stripe_connect_account_id' => $account_id,
					'stripe_connect_status'     => 'incomplete',
					'payout_method'             => 'stripe_connect',
				] );
				self::log_event( 'affiliate.stripe_account_created', (int) $aff->id, [ 'account_id' => $account_id ] );
			}
			$link = \AsterisAffiliates\Payouts\Stripe_Express::create_onboarding_link( $account_id, $return_url, $refresh_url );
			if ( is_wp_error( $link ) ) {
				wp_safe_redirect( add_query_arg( [ 'aff_flash' => 'stripe_link_failed', 'msg' => urlencode( $link->get_error_message() ) ], $profile_url ) );
				exit;
			}
			wp_redirect( $link );
			exit;
		}

		// 2. Stripe redirected back after onboarding completion (or abandonment)
		if ( $action === 'stripe_return' ) {
			$account_id = (string) $aff->stripe_connect_account_id;
			if ( $account_id === '' ) {
				wp_safe_redirect( add_query_arg( 'aff_flash', 'stripe_no_account', $profile_url ) );
				exit;
			}
			$status = \AsterisAffiliates\Payouts\Stripe_Express::retrieve_account( $account_id );
			if ( is_wp_error( $status ) ) {
				wp_safe_redirect( add_query_arg( [ 'aff_flash' => 'stripe_status_failed', 'msg' => urlencode( $status->get_error_message() ) ], $profile_url ) );
				exit;
			}
			\AsterisAffiliates\Affiliates\Affiliate_Repository::update( (int) $aff->id, [
				'stripe_connect_status' => (string) $status['status'],
			] );
			self::log_event( 'affiliate.stripe_onboarding_returned', (int) $aff->id, [
				'status'           => $status['status'],
				'requirements_due' => $status['requirements_due'],
			] );
			$flash = match ( $status['status'] ) {
				'verified'   => 'stripe_verified',
				'restricted' => 'stripe_restricted',
				'disabled'   => 'stripe_disabled',
				default      => 'stripe_incomplete',
			};
			wp_safe_redirect( add_query_arg( 'aff_flash', $flash, $profile_url ) );
			exit;
		}

		// 3. Onboarding link expired → generate fresh one
		if ( $action === 'stripe_refresh' ) {
			$account_id = (string) $aff->stripe_connect_account_id;
			if ( $account_id === '' ) {
				wp_safe_redirect( $profile_url );
				exit;
			}
			$link = \AsterisAffiliates\Payouts\Stripe_Express::create_onboarding_link( $account_id, $return_url, $refresh_url );
			if ( is_wp_error( $link ) ) {
				wp_safe_redirect( add_query_arg( [ 'aff_flash' => 'stripe_link_failed', 'msg' => urlencode( $link->get_error_message() ) ], $profile_url ) );
				exit;
			}
			wp_redirect( $link );
			exit;
		}

		// 4. Open affiliate's Stripe Express dashboard (single-use login link)
		if ( $action === 'stripe_dashboard' ) {
			$account_id = (string) $aff->stripe_connect_account_id;
			if ( $account_id === '' ) {
				wp_safe_redirect( $profile_url );
				exit;
			}
			$link = \AsterisAffiliates\Payouts\Stripe_Express::create_login_link( $account_id );
			if ( is_wp_error( $link ) ) {
				wp_safe_redirect( add_query_arg( [ 'aff_flash' => 'stripe_login_failed', 'msg' => urlencode( $link->get_error_message() ) ], $profile_url ) );
				exit;
			}
			wp_redirect( $link );
			exit;
		}

		wp_safe_redirect( $profile_url );
		exit;
	}

	private static function log_event( string $event_type, ?int $aff_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event_type,
			'affiliate_id' => $aff_id,
			'actor'        => $aff_id ? 'affiliate:' . $aff_id : 'system',
			'payload'      => wp_json_encode( $payload ),
		] );
	}

	private static function render_logged_in( object $affiliate ): void {
		// Admin impersonation banner — only renders if marker cookie present.
		\AsterisAffiliates\Admin\Impersonation::render_banner();

		// Onboarding wizard intercept (Sprint 9B). If active, renders + exits.
		if ( Onboarding_Wizard::maybe_intercept( $affiliate ) ) {
			return;
		}

		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
		// Resolve which view file to load
		switch ( $tab ) {
			case 'links':    Portal_Dashboard::render_links( $affiliate ); break;
			case 'payouts':  Portal_Dashboard::render_payouts( $affiliate ); break;
			case 'profile':  Portal_Dashboard::render_profile( $affiliate ); break;
			default:         Portal_Dashboard::render_dashboard( $affiliate );
		}
	}
}
