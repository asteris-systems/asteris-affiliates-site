<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Public_;

defined( 'ABSPATH' ) || exit;

/**
 * Renders the affiliate-facing portal tabs.
 *
 *   Dashboard — earnings + click stats + recent activity
 *   Links     — tracking URLs + coupon (Sprint 4 wires coupons) + swipe copy
 *   Payouts   — payment history (Sprint 5 wires real data)
 *   Profile   — display name + payout method + bank details (Sprint 5 encryption)
 *
 * All tab views share the same chrome (header with nav + logout).
 * Inline styles only — guarantees consistent look regardless of theme.
 */
final class Portal_Dashboard {

	// ── Shared chrome ───────────────────────────────────────────────────────

	private static function chrome_open( object $aff, string $active_tab ): void {
		$tabs = [
			'dashboard' => 'Dashboard',
			'links'     => 'Links',
			'payouts'   => 'Payouts',
			'profile'   => 'Profile',
		];
		$portal = Portal_Router::PORTAL_PATH;
		?>
		<div style="background:linear-gradient(135deg,#06D6A0,#0a857a);color:#fff;padding:24px 28px;border-radius:12px;margin-bottom:18px;">
			<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:14px;">
				<div>
					<div style="font-size:12px;opacity:0.85;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;">Affiliate portal</div>
					<h1 style="margin:4px 0 0;color:#fff;font-size:22px;">Hi, <?php echo esc_html( $aff->display_name ); ?> 👋</h1>
				</div>
				<a href="<?php echo esc_url( home_url( $portal . '/?aff_action=logout' ) ); ?>" style="color:#fff;background:rgba(255,255,255,0.18);padding:6px 14px;border-radius:6px;font-size:13px;text-decoration:none;font-weight:600;">Sign out</a>
			</div>
		</div>
		<nav style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:0;margin-bottom:18px;display:flex;overflow:hidden;">
			<?php foreach ( $tabs as $slug => $label ) :
				$active = $slug === $active_tab;
				$href = $slug === 'dashboard' ? home_url( $portal . '/' ) : home_url( $portal . '/?tab=' . $slug );
			?>
				<a href="<?php echo esc_url( $href ); ?>" style="flex:1;padding:14px 18px;text-align:center;text-decoration:none;color:<?php echo $active ? '#06D6A0' : '#666'; ?>;font-weight:<?php echo $active ? '700' : '500'; ?>;border-bottom:3px solid <?php echo $active ? '#06D6A0' : 'transparent'; ?>;font-size:14px;">
					<?php echo esc_html( $label ); ?>
				</a>
			<?php endforeach; ?>
		</nav>
		<?php
	}

	// ── Dashboard tab ───────────────────────────────────────────────────────

	public static function render_dashboard( object $aff ): void {
		self::chrome_open( $aff, 'dashboard' );

		global $wpdb;
		$p = $wpdb->prefix;
		$stats = [
			'clicks_30d'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d AND landed_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $aff->id ) ),
			'clicks_total'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d", $aff->id ) ),
			'conversions_30d' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_commissions WHERE affiliate_id = %d AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $aff->id ) ),
			'earnings_pending_cents' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status = 'pending'", $aff->id ) ),
			'earnings_approved_cents' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status = 'approved'", $aff->id ) ),
			'earnings_paid_cents'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status = 'paid'", $aff->id ) ),
		];
		?>
		<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:18px;">
			<?php foreach ( [
				[ 'Earnings · paid',     '$' . number_format( $stats['earnings_paid_cents'] / 100, 2 ),     '#06D6A0' ],
				[ 'Earnings · approved', '$' . number_format( $stats['earnings_approved_cents'] / 100, 2 ), '#0a857a' ],
				[ 'Earnings · pending',  '$' . number_format( $stats['earnings_pending_cents'] / 100, 2 ),  '#ea580c' ],
				[ 'Clicks · 30 days',    number_format_i18n( $stats['clicks_30d'] ),                        '#0a857a' ],
				[ 'Clicks · total',      number_format_i18n( $stats['clicks_total'] ),                      '#666' ],
				[ 'Conversions · 30d',   number_format_i18n( $stats['conversions_30d'] ),                   '#06D6A0' ],
			] as $card ) : [ $label, $value, $colour ] = $card; ?>
				<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo esc_attr( $colour ); ?>;border-radius:8px;padding:14px 16px;">
					<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $label ); ?></div>
					<div style="font-size:22px;color:#0a0a0a;font-weight:800;margin-top:4px;"><?php echo esc_html( $value ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>

		<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:22px;">
			<h2 style="margin:0 0 14px;font-size:18px;">Your tracking link</h2>
			<?php $url = add_query_arg( 'ref', $aff->public_id, home_url( '/' ) ); ?>
			<p style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:12px 14px;font-family:ui-monospace,monospace;font-size:13px;word-break:break-all;margin:0;">
				<?php echo esc_html( $url ); ?>
			</p>
			<p style="margin-top:12px;"><a href="<?php echo esc_url( home_url( Portal_Router::PORTAL_PATH . '/?tab=links' ) ); ?>" style="color:#06D6A0;font-weight:600;">More link tools + swipe copy →</a></p>
		</div>
		<?php
	}

	// ── Links tab ───────────────────────────────────────────────────────────

	public static function render_links( object $aff ): void {
		self::chrome_open( $aff, 'links' );
		$home = home_url( '/' );
		$ref  = $aff->public_id;
		$ex   = static fn( string $url ): string => esc_html( add_query_arg( 'ref', $ref, $url ) );
		?>
		<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:22px;margin-bottom:18px;">
			<h2 style="margin:0 0 14px;font-size:18px;">Your tracking links</h2>
			<p style="color:#666;font-size:14px;margin:0 0 16px;">Any URL on this site can become a tracked affiliate link — just add <code>?ref=<?php echo esc_html( $ref ); ?></code>. Cookie lasts 60 days. Cross-product attribution.</p>

			<table style="width:100%;border-collapse:collapse;font-size:13px;">
				<thead><tr style="background:#f9fafb;text-align:left;">
					<th style="padding:8px 10px;border-bottom:1px solid #e5e7eb;">Where to link</th>
					<th style="padding:8px 10px;border-bottom:1px solid #e5e7eb;">Your URL</th>
				</tr></thead>
				<tbody>
					<tr><td style="padding:10px;border-bottom:1px solid #f0f0f0;font-weight:600;">Homepage</td><td style="padding:10px;border-bottom:1px solid #f0f0f0;font-family:ui-monospace,monospace;font-size:12px;color:#555;word-break:break-all;"><?php echo $ex( $home ); ?></td></tr>
					<tr><td style="padding:10px;border-bottom:1px solid #f0f0f0;font-weight:600;">Shop</td><td style="padding:10px;border-bottom:1px solid #f0f0f0;font-family:ui-monospace,monospace;font-size:12px;color:#555;word-break:break-all;"><?php echo $ex( $home . 'shop/' ); ?></td></tr>
					<tr><td style="padding:10px;font-weight:600;">Any product page</td><td style="padding:10px;font-family:ui-monospace,monospace;font-size:12px;color:#555;word-break:break-all;"><?php echo esc_html( $home . 'product/[slug]/?ref=' . $ref ); ?></td></tr>
				</tbody>
			</table>
		</div>

		<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:22px;margin-bottom:18px;">
			<h2 style="margin:0 0 12px;font-size:18px;">Swipe copy</h2>
			<p style="color:#666;font-size:14px;margin:0 0 16px;">Drop these into a newsletter, post, or video description. Tracking link goes at the end.</p>
			<?php foreach ( [
				'Twitter / X (≤280 chars)' => "I've been using {sitename}. Genuinely good. If you're shopping around: " . $ex( $home ),
				'LinkedIn'                => "Quick rec for anyone running an online store: {sitename}. It's been a noticeable upgrade for us. Link: " . $ex( $home ),
				'Newsletter sign-off'     => "PS — if you've been looking at this category, {sitename} is what I use. Affiliate link: " . $ex( $home ),
			] as $label => $copy ) : ?>
				<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:14px;margin-bottom:10px;">
					<div style="font-size:11px;color:#666;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;"><?php echo esc_html( $label ); ?></div>
					<p style="margin:0;font-size:13px;line-height:1.55;"><?php echo wp_kses_post( str_replace( '{sitename}', '<strong>' . esc_html( (string) get_bloginfo( 'name' ) ) . '</strong>', $copy ) ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	// ── Payouts tab — real payout history (Sprint 5B) ───────────────────────

	public static function render_payouts( object $aff ): void {
		self::chrome_open( $aff, 'payouts' );

		global $wpdb;
		$p = $wpdb->prefix;
		$id = (int) $aff->id;

		$balances = [
			'pending'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status = 'pending'",  $id ) ),
			'approved' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status = 'approved'", $id ) ),
			'paid'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status = 'paid'",     $id ) ),
		];
		$payouts = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$p}aff_payouts WHERE affiliate_id = %d ORDER BY id DESC LIMIT 30",
			$id
		) );
		$min_cents = (int) \AsterisAffiliates\Core\Settings::get( 'payout_min_cents', 10000 );
		$day_of_month = (int) \AsterisAffiliates\Core\Settings::get( 'payout_day_of_month', 1 );
		?>
		<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:16px;">
			<?php foreach ( [
				[ 'Pending', '$' . number_format( $balances['pending']  / 100, 2 ), '#ea580c' ],
				[ 'Ready for next payout', '$' . number_format( $balances['approved'] / 100, 2 ), '#06D6A0' ],
				[ 'Paid lifetime', '$' . number_format( $balances['paid']     / 100, 2 ), '#059669' ],
			] as $c ) : [ $l, $v, $clr ] = $c; ?>
				<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo esc_attr( $clr ); ?>;border-radius:8px;padding:14px 16px;">
					<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $l ); ?></div>
					<div style="font-size:22px;color:#0a0a0a;font-weight:800;margin-top:2px;"><?php echo esc_html( $v ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>
		<p style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:10px 14px;color:#6b7280;font-size:13px;">
			Monthly batch on <strong>day <?php echo (int) $day_of_month; ?></strong>. Triggers when your <em>Ready for next payout</em> balance ≥ <strong>$<?php echo esc_html( number_format( $min_cents / 100, 2 ) ); ?></strong>.
		</p>

		<h2 style="margin:18px 0 10px;font-size:16px;">Payout history</h2>
		<?php if ( ! $payouts ) : ?>
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:28px;text-align:center;color:#999;">No payouts yet. Your first one fires on day <?php echo (int) $day_of_month; ?> once your balance hits the threshold.</div>
		<?php else : ?>
			<table style="width:100%;background:#fff;border:1px solid #e5e7eb;border-radius:8px;border-collapse:collapse;font-size:13px;">
				<thead><tr style="background:#f9fafb;text-align:left;"><th style="padding:10px;">Date</th><th style="padding:10px;">Method</th><th style="padding:10px;">Amount</th><th style="padding:10px;">Status</th><th style="padding:10px;">Reference</th></tr></thead>
				<tbody>
				<?php foreach ( $payouts as $r ) :
					$colour = [ 'pending' => '#ea580c', 'paid' => '#059669', 'failed' => '#dc2626', 'processing' => '#0a857a' ][ $r->status ] ?? '#6b7280';
				?>
					<tr style="border-top:1px solid #f0f0f0;">
						<td style="padding:10px;color:#666;font-family:ui-monospace,monospace;font-size:11px;"><?php echo esc_html( $r->paid_at ?: $r->requested_at ); ?></td>
						<td style="padding:10px;"><?php echo esc_html( str_replace( '_', ' ', $r->payout_method ) ); ?></td>
						<td style="padding:10px;"><strong>$<?php echo esc_html( number_format( $r->total_cents / 100, 2 ) ); ?></strong> <span style="color:#999;font-size:11px;"><?php echo esc_html( $r->currency ); ?></span></td>
						<td style="padding:10px;"><span style="background:<?php echo esc_attr( $colour ); ?>;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;text-transform:uppercase;"><?php echo esc_html( $r->status ); ?></span></td>
						<td style="padding:10px;font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( (string) ( $r->stripe_transfer_id ?: $r->bank_reference ?: '—' ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	// ── Profile tab — editable payout method + bank/PayPal/Stripe details ────

	public static function render_profile( object $aff ): void {
		self::chrome_open( $aff, 'profile' );
		$portal = Portal_Router::PORTAL_PATH;
		$flash = isset( $_GET['aff_flash'] ) ? sanitize_key( wp_unslash( $_GET['aff_flash'] ) ) : '';
		?>
		<?php
		$stripe_msgs = [
			'profile_saved'        => [ 'ok',  '✓ Profile saved. Payout details updated.' ],
			'stripe_verified'      => [ 'ok',  '🎉 Stripe Connect verified! You\'re fully ready to receive automatic payouts on every cycle.' ],
			'stripe_restricted'    => [ 'warn','⚠ Stripe needs a few more details before you can receive payouts. Click "Continue Stripe onboarding" below to finish.' ],
			'stripe_incomplete'    => [ 'warn','⏳ Stripe onboarding started but not complete. Click "Continue Stripe onboarding" below to finish.' ],
			'stripe_disabled'      => [ 'err', '✗ Stripe disabled your account. Check requirements via "Open Stripe dashboard" below — usually a missing tax form or identity document.' ],
			'stripe_create_failed' => [ 'err', '✗ Couldn\'t create your Stripe account: ' . esc_html( isset( $_GET['msg'] ) ? (string) wp_unslash( $_GET['msg'] ) : '' ) ],
			'stripe_link_failed'   => [ 'err', '✗ Couldn\'t create the Stripe onboarding link: ' . esc_html( isset( $_GET['msg'] ) ? (string) wp_unslash( $_GET['msg'] ) : '' ) ],
			'stripe_status_failed' => [ 'err', '✗ Couldn\'t check your Stripe status: ' . esc_html( isset( $_GET['msg'] ) ? (string) wp_unslash( $_GET['msg'] ) : '' ) ],
			'stripe_login_failed'  => [ 'err', '✗ Couldn\'t open Stripe dashboard: ' . esc_html( isset( $_GET['msg'] ) ? (string) wp_unslash( $_GET['msg'] ) : '' ) ],
			'stripe_no_account'    => [ 'err', '✗ No Stripe account on file. Click "Connect with Stripe" below to set one up.' ],
		];
		if ( isset( $stripe_msgs[ $flash ] ) ) :
			[ $kind, $html ] = $stripe_msgs[ $flash ];
			$bg = $kind === 'ok' ? '#ecfdf5' : ( $kind === 'warn' ? '#fff8e1' : '#fef2f2' );
			$brd = $kind === 'ok' ? '#06D6A0' : ( $kind === 'warn' ? '#b45309' : '#dc2626' );
			$txt = $kind === 'ok' ? '#065f46' : ( $kind === 'warn' ? '#92400e' : '#991b1b' );
		?>
			<div style="background:<?php echo esc_attr( $bg ); ?>;border-left:4px solid <?php echo esc_attr( $brd ); ?>;padding:12px 18px;border-radius:8px;margin-bottom:14px;color:<?php echo esc_attr( $txt ); ?>;"><?php echo $html; // phpcs:ignore ?></div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'asteris_aff_profile_save_' . (int) $aff->id, '_aff_profile_nonce' ); ?>
			<input type="hidden" name="action" value="asteris_aff_profile_save">

			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:22px;margin-bottom:14px;">
				<h2 style="margin:0 0 12px;font-size:16px;">Identity</h2>
				<table style="width:100%;font-size:14px;">
					<tr><td style="padding:6px 0;color:#666;width:160px;">Display name</td><td style="padding:6px 0;"><input type="text" name="display_name" value="<?php echo esc_attr( $aff->display_name ); ?>" maxlength="120" required style="width:100%;max-width:380px;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;"></td></tr>
					<tr><td style="padding:6px 0;color:#666;">Email</td><td style="padding:6px 0;color:#999;"><?php echo esc_html( $aff->email ); ?> <span style="font-size:11px;">(contact support to change)</span></td></tr>
					<tr><td style="padding:6px 0;color:#666;">Public ID</td><td style="padding:6px 0;font-family:ui-monospace,monospace;color:#555;"><?php echo esc_html( $aff->public_id ); ?> <span style="font-size:11px;color:#999;">(contact support to change)</span></td></tr>
				</table>
			</div>

			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:22px;margin-bottom:14px;">
				<h2 style="margin:0 0 6px;font-size:16px;">Payout method</h2>
				<p style="color:#666;font-size:13px;margin:0 0 14px;">Pick one. Stripe Connect is fastest (2–3 business days). PayPal is the broadest-region backup. Bank transfer is the fallback for everywhere else.</p>

				<?php $pm = (string) $aff->payout_method; ?>
				<div style="display:flex;flex-direction:column;gap:8px;">
					<label style="display:block;background:<?php echo $pm === 'stripe_connect' ? '#ecfdf5' : '#f9fafb'; ?>;border:1px solid <?php echo $pm === 'stripe_connect' ? '#06D6A0' : '#e5e7eb'; ?>;border-radius:8px;padding:12px 16px;cursor:pointer;">
						<input type="radio" name="payout_method" value="stripe_connect" <?php checked( 'stripe_connect', $pm ); ?>>
						<strong>🟦 Stripe Connect</strong> · auto-paid, 2–3 business days
						<div style="margin-top:10px;padding-left:22px;">
							<?php
							$has_account = ! empty( $aff->stripe_connect_account_id );
							$status      = (string) ( $aff->stripe_connect_status ?? '' );
							$portal      = Portal_Router::PORTAL_PATH;
							$connect_url = home_url( $portal . '/?aff_action=stripe_connect' );
							$dashbd_url  = home_url( $portal . '/?aff_action=stripe_dashboard' );

							if ( ! $has_account ) :
							?>
								<p style="margin:0 0 10px;font-size:13px;color:#374151;">One-click setup. Stripe hosts the entire onboarding (takes ~3 minutes — you'll fill in name, address, bank, and tax info on their site).</p>
								<a href="<?php echo esc_url( $connect_url ); ?>" style="display:inline-block;background:#635bff;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:700;font-size:14px;">Connect with Stripe →</a>
							<?php elseif ( $status === 'verified' ) : ?>
								<div style="background:#fff;border:1px solid #a7f3d0;border-radius:6px;padding:10px 14px;font-size:13px;">
									<strong style="color:#059669;">✓ Verified</strong> · payouts go directly to your bank<br>
									<span style="color:#666;font-size:11px;font-family:ui-monospace,monospace;">Account: <?php echo esc_html( $aff->stripe_connect_account_id ); ?></span>
								</div>
								<p style="margin:10px 0 0;">
									<a href="<?php echo esc_url( $dashbd_url ); ?>" target="_blank" rel="noopener" style="display:inline-block;background:#635bff;color:#fff;padding:6px 14px;border-radius:6px;text-decoration:none;font-weight:600;font-size:12px;">Open Stripe dashboard →</a>
								</p>
							<?php elseif ( in_array( $status, [ 'incomplete', 'restricted' ], true ) ) : ?>
								<div style="background:#fff8e1;border:1px solid #f0d878;border-radius:6px;padding:10px 14px;font-size:13px;">
									<strong style="color:#b45309;">⏳ <?php echo esc_html( ucfirst( $status ) ); ?></strong> · Stripe needs more info before you can be paid<br>
									<span style="color:#666;font-size:11px;font-family:ui-monospace,monospace;">Account: <?php echo esc_html( $aff->stripe_connect_account_id ); ?></span>
								</div>
								<p style="margin:10px 0 0;">
									<a href="<?php echo esc_url( $connect_url ); ?>" style="display:inline-block;background:#635bff;color:#fff;padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:700;font-size:13px;">Continue Stripe onboarding →</a>
								</p>
							<?php elseif ( $status === 'disabled' ) : ?>
								<div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:6px;padding:10px 14px;font-size:13px;">
									<strong style="color:#dc2626;">✗ Disabled</strong> · usually a missing tax form or identity doc<br>
									<span style="color:#666;font-size:11px;font-family:ui-monospace,monospace;">Account: <?php echo esc_html( $aff->stripe_connect_account_id ); ?></span>
								</div>
								<p style="margin:10px 0 0;">
									<a href="<?php echo esc_url( $dashbd_url ); ?>" target="_blank" rel="noopener" style="display:inline-block;background:#635bff;color:#fff;padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:700;font-size:13px;">Open Stripe dashboard to fix →</a>
								</p>
							<?php else : ?>
								<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:10px 14px;font-size:13px;color:#666;">
									Account on file · status unknown yet
									<div style="font-size:11px;font-family:ui-monospace,monospace;margin-top:4px;"><?php echo esc_html( $aff->stripe_connect_account_id ); ?></div>
								</div>
							<?php endif; ?>
						</div>
					</label>

					<label style="display:block;background:<?php echo $pm === 'paypal' ? '#ecfdf5' : '#f9fafb'; ?>;border:1px solid <?php echo $pm === 'paypal' ? '#06D6A0' : '#e5e7eb'; ?>;border-radius:8px;padding:12px 16px;cursor:pointer;">
						<input type="radio" name="payout_method" value="paypal" <?php checked( 'paypal', $pm ); ?>>
						<strong>💸 PayPal</strong> · backup, broader country support
						<div style="margin-top:8px;padding-left:22px;">
							<label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">Your PayPal email:</label>
							<input type="email" name="paypal_email" value="<?php echo esc_attr( (string) $aff->paypal_email ); ?>" placeholder="you@example.com" style="width:100%;max-width:360px;padding:5px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:12px;">
						</div>
					</label>

					<label style="display:block;background:<?php echo $pm === 'bank_transfer' ? '#ecfdf5' : '#f9fafb'; ?>;border:1px solid <?php echo $pm === 'bank_transfer' ? '#06D6A0' : '#e5e7eb'; ?>;border-radius:8px;padding:12px 16px;cursor:pointer;">
						<input type="radio" name="payout_method" value="bank_transfer" <?php checked( 'bank_transfer', $pm ); ?>>
						<strong>🏦 Bank transfer</strong> · last-resort for non-Stripe / non-PayPal regions
						<div style="margin-top:8px;padding-left:22px;">
							<label style="font-size:12px;color:#666;display:block;margin-bottom:4px;">Bank details <span style="color:#059669;font-weight:600;">(encrypted at rest)</span>:</label>
							<textarea name="bank_details_plain" rows="4" placeholder="Bank name, IBAN/account #, SWIFT/BIC, account holder. Free-form. Stored encrypted, only decrypted at payout time." style="width:100%;max-width:520px;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-family:ui-monospace,monospace;font-size:12px;"></textarea>
							<?php if ( $aff->bank_details_encrypted ) : ?>
								<p style="margin:6px 0 0;font-size:11px;color:#059669;">✓ Bank details on file. Leave blank above to keep current; type new details to replace.</p>
							<?php endif; ?>
						</div>
					</label>
				</div>
			</div>

			<button type="submit" style="background:#06D6A0;color:#fff;border:0;padding:11px 24px;border-radius:6px;font-size:14px;font-weight:700;cursor:pointer;">Save profile</button>
		</form>
		<?php
	}
}
