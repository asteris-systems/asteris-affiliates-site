<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Privacy-safe visitor fingerprint: SHA256( IP + User-Agent + per-site secret ).
 *
 * Used for:
 *   - Duplicate-click detection (one visitor counting once per affiliate per day)
 *   - Soft-session fallback when cookies are blocked (Session_Manager)
 *   - Fraud detection (IP burst, self-referral)
 *
 * GDPR-friendly: we NEVER store the raw IP. Only the salted hash. The hash
 * can't be reversed to identify the visitor, but two requests from the same
 * IP+UA in the same window collide deterministically.
 *
 * Salt: per-site secret stored in option `asteris_aff_hash_salt`, auto-generated
 * on first use. Different from ASTERIS_LS_SIGNING_SECRET (separate concern).
 */
final class Visitor_Hash {

	private const OPT_SALT = 'asteris_aff_hash_salt';

	public static function compute(): string {
		$ip   = self::client_ip();
		$ua   = self::user_agent();
		$salt = self::salt();
		return hash( 'sha256', $ip . '|' . $ua . '|' . $salt );
	}

	/**
	 * Country code (ISO-2) derived from the IP, if any geolocation provider
	 * is available. Returns null otherwise. WC's built-in geolocation is
	 * the primary source — falls back to CF-IPCountry header.
	 */
	public static function ip_country(): ?string {
		if ( ! empty( $_SERVER['HTTP_CF_IPCOUNTRY'] ) ) {
			$cc = strtoupper( substr( (string) $_SERVER['HTTP_CF_IPCOUNTRY'], 0, 2 ) );
			if ( preg_match( '/^[A-Z]{2}$/', $cc ) ) { return $cc; }
		}
		if ( class_exists( 'WC_Geolocation' ) ) {
			$geo = \WC_Geolocation::geolocate_ip( self::client_ip() );
			if ( ! empty( $geo['country'] ) ) {
				return strtoupper( substr( (string) $geo['country'], 0, 2 ) );
			}
		}
		return null;
	}

	/**
	 * Best-effort client IP — trusts CF + standard proxy headers when present.
	 */
	public static function client_ip(): string {
		foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $k ) {
			$v = $_SERVER[ $k ] ?? '';
			if ( is_string( $v ) && $v !== '' ) {
				$ip = trim( explode( ',', $v )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) { return $ip; }
			}
		}
		return '0.0.0.0';
	}

	public static function user_agent(): string {
		$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
		return substr( (string) $ua, 0, 512 );
	}

	private static function salt(): string {
		$salt = (string) get_option( self::OPT_SALT, '' );
		if ( $salt === '' ) {
			$salt = bin2hex( random_bytes( 32 ) );
			update_option( self::OPT_SALT, $salt, false );
		}
		return $salt;
	}
}
