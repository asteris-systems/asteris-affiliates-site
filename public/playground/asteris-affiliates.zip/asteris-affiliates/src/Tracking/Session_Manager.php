<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Server-side session fallback for visitors who block third-party cookies
 * OR whose browser purges first-party cookies aggressively (Safari ITP,
 * Brave's nightly cookie reset).
 *
 * Strategy: hash IP + UA → use as a "soft" identifier that lasts the
 * session lifetime even when the cookie is dropped. NEVER stored long-term
 * unless an affiliate click is actually attached to it.
 *
 * NOT a replacement for the cookie — it's a degrade-gracefully fallback
 * for cookie-hostile browsers. The cookie is still the primary key.
 */
final class Session_Manager {

	/**
	 * Get a usable session_id for THIS request:
	 *   1. Try cookie (primary)
	 *   2. Fall back to visitor_hash-derived soft session (degraded)
	 *
	 * Returns the session_id and a flag indicating which method was used.
	 *
	 * @return array{session_id:string, source:'cookie'|'fallback'}
	 */
	public static function resolve(): array {
		$cookie = Cookie_Manager::read();
		if ( $cookie !== null ) {
			return [ 'session_id' => $cookie, 'source' => 'cookie' ];
		}
		// Soft fallback: deterministic ID from visitor fingerprint. NOT as
		// reliable as a cookie — IP can change on mobile networks — but
		// better than nothing for cookie-blocked browsers.
		$hash    = Visitor_Hash::compute();
		$soft_id = 'aff-soft-' . substr( $hash, 0, 32 );
		return [ 'session_id' => $soft_id, 'source' => 'fallback' ];
	}
}
