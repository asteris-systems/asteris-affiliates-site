<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Tracking;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Set + read the affiliate-tracking cookie.
 *
 * Cookie: `aff_session` — UUIDv4 generated on first affiliate-link click.
 * TTL: 60 days (configurable via Settings::cookie_days). Refreshed on each
 * affiliate-link click so an active customer's attribution window doesn't
 * expire mid-funnel.
 *
 * SameSite=Lax (cross-domain affiliate referral links work; CSRF-safe).
 * Secure on HTTPS. HttpOnly because no JS needs to read it.
 */
final class Cookie_Manager {

	public const COOKIE_NAME = 'aff_session';

	/**
	 * Read the current session ID from cookie, or null if not set.
	 */
	/** Alias for read() — used by external adapters (EDD, Surecart) which prefer the `current()` verb. */
	public static function current(): ?string {
		return self::read();
	}

	public static function read(): ?string {
		$val = $_COOKIE[ self::COOKIE_NAME ] ?? null;
		if ( ! is_string( $val ) || ! self::is_valid_uuid( $val ) ) {
			return null;
		}
		return $val;
	}

	/**
	 * Generate a fresh UUIDv4 session ID, set cookie, return the ID.
	 * Idempotent: if a valid cookie exists, returns it without overwriting.
	 */
	public static function ensure(): string {
		$existing = self::read();
		if ( $existing !== null ) {
			self::set( $existing );  // refresh TTL on every affiliate-link click
			return $existing;
		}
		$fresh = self::generate_uuid();
		self::set( $fresh );
		return $fresh;
	}

	/**
	 * Force-clear the cookie (for testing + manual customer requests).
	 */
	public static function clear(): void {
		if ( headers_sent() ) { return; }
		setcookie( self::COOKIE_NAME, '', [
			'expires'  => time() - 3600,
			'path'     => '/',
			'domain'   => self::cookie_domain(),
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		] );
		unset( $_COOKIE[ self::COOKIE_NAME ] );
	}

	// ── Internals ───────────────────────────────────────────────────────────

	private static function set( string $session_id ): void {
		if ( headers_sent() ) { return; }
		$days = max( 1, (int) Settings::get( 'cookie_days', 60 ) );
		setcookie( self::COOKIE_NAME, $session_id, [
			'expires'  => time() + ( $days * DAY_IN_SECONDS ),
			'path'     => '/',
			'domain'   => self::cookie_domain(),
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		] );
		// Update $_COOKIE so subsequent same-request reads see the new value.
		$_COOKIE[ self::COOKIE_NAME ] = $session_id;
	}

	/**
	 * Empty domain string lets the browser default to the request host —
	 * works for subdomain attribution (cart.theirsite.com vs theirsite.com)
	 * on most setups. Filterable for multisite / multi-domain shops.
	 */
	private static function cookie_domain(): string {
		$default = '';
		return (string) apply_filters( 'asteris_aff_cookie_domain', $default );
	}

	/** UUIDv4 generator — random_bytes is cryptographically strong. */
	private static function generate_uuid(): string {
		$data    = random_bytes( 16 );
		$data[6] = chr( ord( $data[6] ) & 0x0f | 0x40 ); // version 4
		$data[8] = chr( ord( $data[8] ) & 0x3f | 0x80 ); // variant
		return vsprintf( '%s%s-%s-%s-%s-%s%s%s', str_split( bin2hex( $data ), 4 ) );
	}

	/** Defensive: reject malformed cookie values to prevent SQL injection downstream. */
	private static function is_valid_uuid( string $val ): bool {
		return (bool) preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $val );
	}
}
