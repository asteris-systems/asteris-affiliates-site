<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Tracking;

use AsterisAffiliates\Anti_Fraud\Bot_Filter;

defined( 'ABSPATH' ) || exit;

/**
 * Affiliate-click capture: handles `?ref=public_id` URLs on any page load.
 *
 * Flow on each request:
 *   1. Is there a `?ref=…` param? If no → exit.
 *   2. Is the visitor a bot? If yes → exit silently.
 *   3. Does that public_id match an approved affiliate? If no → exit silently.
 *   4. Do we already have a referral row for THIS session + THIS affiliate
 *      within the last 24h? If yes → exit (don't duplicate-count clicks).
 *   5. Ensure a session cookie exists (Cookie_Manager).
 *   6. INSERT into wp_aff_referrals with full UTM + visitor_hash + landed_url.
 *   7. Log event.
 *
 * Hooks on `init` priority 5 — early enough that the cookie can be set
 * before any output, late enough that WordPress is fully loaded.
 *
 * Performance: the early-exit on missing ?ref param means this is ~0 cost
 * for the 99.9% of page loads that aren't affiliate links.
 */
final class Click_Tracker {

	public const REF_PARAM = 'ref';

	public static function register(): void {
		add_action( 'init', [ self::class, 'maybe_capture' ], 5 );
	}

	public static function maybe_capture(): void {
		// 1. Fast exit — most page loads have no ?ref param
		$public_id = isset( $_GET[ self::REF_PARAM ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::REF_PARAM ] ) ) : '';
		if ( $public_id === '' ) { return; }

		// 2. Bot filter
		if ( Bot_Filter::is_bot() ) { return; }

		// 3. Resolve affiliate
		$affiliate_id = self::find_affiliate_id_by_public_id( $public_id );
		if ( $affiliate_id === null ) { return; }

		// 4. Dedup: same session + same affiliate in last 24h = no new row
		$session_id = Cookie_Manager::ensure();
		if ( self::recently_recorded( $affiliate_id, $session_id ) ) { return; }

		// 5. Build the referral row payload
		$utm = UTM_Capture::from_request();
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . 'aff_referrals',
			[
				'affiliate_id'    => $affiliate_id,
				'session_id'      => $session_id,
				'visitor_hash'    => Visitor_Hash::compute(),
				'landed_url'      => self::current_url(),
				'landed_at'       => current_time( 'mysql', true ),
				'utm_source'      => $utm['utm_source'],
				'utm_medium'      => $utm['utm_medium'],
				'utm_campaign'    => $utm['utm_campaign'],
				'utm_content'     => $utm['utm_content'],
				'referrer_domain' => $utm['referrer_domain'],
				'ip_country'      => Visitor_Hash::ip_country(),
				'device_type'     => $utm['device_type'],
				'converted_at'    => null,
				'converted_order_id' => null,
			],
			[ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d' ]
		);

		// 6. Log event for the activity feed
		self::log_event( 'click.recorded', $affiliate_id, [
			'session_id' => $session_id,
			'public_id'  => $public_id,
			'utm_source' => $utm['utm_source'],
			'landed_url' => self::current_url(),
		] );
	}

	// ── Helpers ──────────────────────────────────────────────────────────────

	/**
	 * Public helper — landing pages (Landing_Page_Router) call this directly
	 * to record a click + drop the cookie without needing the ?ref= param.
	 *
	 * @param object $affiliate  Row from aff_affiliates
	 * @param array  $extra      Metadata to merge into the event payload
	 */
	public static function record_landing( object $affiliate, array $extra = [] ): void {
		if ( Bot_Filter::is_bot() ) { return; }
		$session_id = Cookie_Manager::ensure();
		if ( self::recently_recorded( (int) $affiliate->id, $session_id ) ) { return; }

		$utm = UTM_Capture::from_request();
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_referrals', [
			'affiliate_id'    => (int) $affiliate->id,
			'session_id'      => $session_id,
			'visitor_hash'    => Visitor_Hash::compute(),
			'landed_url'      => self::current_url(),
			'landed_at'       => current_time( 'mysql', true ),
			'utm_source'      => $utm['utm_source'],
			'utm_medium'      => $utm['utm_medium'],
			'utm_campaign'    => $utm['utm_campaign'],
			'utm_content'     => $utm['utm_content'],
			'referrer_domain' => $utm['referrer_domain'],
			'ip_country'      => Visitor_Hash::ip_country(),
			'device_type'     => $utm['device_type'],
		] );
		self::log_event( 'landing_page.view', (int) $affiliate->id, array_merge( $utm, $extra ) );
	}

	private static function find_affiliate_id_by_public_id( string $public_id ): ?int {
		global $wpdb;
		$id = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}aff_affiliates
			 WHERE public_id = %s AND status = 'approved'
			 LIMIT 1",
			$public_id
		) );
		return $id ? (int) $id : null;
	}

	/**
	 * Returns true if a referral row already exists for this affiliate +
	 * session in the last 24h. Stops the same visitor refreshing an
	 * affiliate link 100 times from inflating click stats.
	 */
	private static function recently_recorded( int $affiliate_id, string $session_id ): bool {
		global $wpdb;
		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}aff_referrals
			 WHERE affiliate_id = %d
			 AND session_id = %s
			 AND landed_at > DATE_SUB(NOW(), INTERVAL 1 DAY)",
			$affiliate_id,
			$session_id
		) );
		return $count > 0;
	}

	private static function current_url(): string {
		$scheme = is_ssl() ? 'https' : 'http';
		$host   = $_SERVER['HTTP_HOST'] ?? '';
		$uri    = $_SERVER['REQUEST_URI'] ?? '/';
		$url    = $scheme . '://' . $host . $uri;
		return substr( esc_url_raw( $url ), 0, 1000 );
	}

	private static function log_event( string $event_type, ?int $affiliate_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'aff_events',
			[
				'occurred_at'  => current_time( 'mysql', true ),
				'event_type'   => $event_type,
				'affiliate_id' => $affiliate_id,
				'actor'        => 'visitor',
				'payload'      => wp_json_encode( $payload ),
			],
			[ '%s', '%s', '%d', '%s', '%s' ]
		);
	}
}
