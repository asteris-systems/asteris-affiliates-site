<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Tracking;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Given a WC order, figure out which affiliate (if any) gets credit.
 *
 * Resolution order (driven by Settings::attribution_priority):
 *
 *   coupon_first (default):
 *     1. Did the order use a coupon mapped to an affiliate?  →  that one
 *     2. Else: cookie session → most-recent referral → that affiliate
 *
 *   link_first:
 *     1. Cookie session → most-recent referral → that affiliate
 *     2. Else: coupon
 *
 * Returns a struct with the affiliate_id, the referral_id (if any),
 * and the attribution_type ('coupon' | 'link' | 'manual') so the
 * commission row can record where the credit came from.
 *
 * Self-referral block: if the resolved affiliate's email matches the
 * order's billing email AND the setting is on, the attribution is
 * REJECTED — returns null. Affiliates can't earn commission on their
 * own purchases.
 */
final class Attribution_Resolver {

	/**
	 * @return array{affiliate_id:int,referral_id:?int,attribution_type:string,coupon_code:?string}|null
	 */
	public static function resolve_for_order( \WC_Order $order ): ?array {
		$priority = (string) Settings::get( 'attribution_priority', 'coupon_first' );

		$by_coupon = self::resolve_by_coupon( $order );
		$by_link   = self::resolve_by_link( $order );

		$result = $priority === 'link_first'
			? ( $by_link ?? $by_coupon )
			: ( $by_coupon ?? $by_link );

		if ( $result === null ) { return null; }

		// Self-referral block
		if ( (int) Settings::get( 'self_referral_block', 1 ) ) {
			$customer_email = strtolower( (string) $order->get_billing_email() );
			global $wpdb;
			$aff_email = (string) $wpdb->get_var( $wpdb->prepare(
				"SELECT email FROM {$wpdb->prefix}aff_affiliates WHERE id = %d",
				$result['affiliate_id']
			) );
			if ( $aff_email !== '' && $aff_email === $customer_email ) {
				self::log_event( 'commission.self_referral_blocked', $result['affiliate_id'], [
					'order_id'       => $order->get_id(),
					'customer_email' => $customer_email,
				] );
				return null;
			}
		}

		return $result;
	}

	/**
	 * If any of the order's coupons are mapped to an affiliate, return it.
	 * Multi-coupon orders: first match wins (rare in practice).
	 */
	private static function resolve_by_coupon( \WC_Order $order ): ?array {
		$codes = (array) $order->get_coupon_codes();
		if ( ! $codes ) { return null; }

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $codes ), '%s' ) );
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT affiliate_id, coupon_code FROM {$wpdb->prefix}aff_coupons
			 WHERE coupon_code IN ($placeholders) AND active = 1
			 LIMIT 1",
			$codes
		) );
		if ( ! $row ) { return null; }

		return [
			'affiliate_id'     => (int) $row->affiliate_id,
			'referral_id'      => null,
			'attribution_type' => 'coupon',
			'coupon_code'      => (string) $row->coupon_code,
		];
	}

	/**
	 * Look up the visitor's session_id (from cookie OR soft fallback) and
	 * find the most recent referral within the cookie window.
	 */
	private static function resolve_by_link( \WC_Order $order ): ?array {
		$session = Session_Manager::resolve();
		$session_id = $session['session_id'];

		$cookie_days = max( 1, (int) Settings::get( 'cookie_days', 60 ) );

		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT id, affiliate_id FROM {$wpdb->prefix}aff_referrals
			 WHERE session_id = %s
			 AND landed_at > DATE_SUB(NOW(), INTERVAL %d DAY)
			 ORDER BY id DESC LIMIT 1",
			$session_id,
			$cookie_days
		) );
		if ( ! $row ) { return null; }

		return [
			'affiliate_id'     => (int) $row->affiliate_id,
			'referral_id'      => (int) $row->id,
			'attribution_type' => 'link',
			'coupon_code'      => null,
		];
	}

	private static function log_event( string $event_type, ?int $affiliate_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event_type,
			'affiliate_id' => $affiliate_id,
			'actor'        => 'system',
			'payload'      => wp_json_encode( $payload ),
		] );
	}
}
