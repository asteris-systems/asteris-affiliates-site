<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Capture utm_source / utm_medium / utm_campaign / utm_content from the
 * request and the HTTP_REFERER.
 *
 * Used in two places:
 *   1. Stored on the referral row at click capture (Click_Tracker)
 *   2. Exposed to affiliates in their portal stats ("which channel converts?")
 */
final class UTM_Capture {

	/**
	 * @return array{utm_source:?string,utm_medium:?string,utm_campaign:?string,utm_content:?string,referrer_domain:?string,device_type:?string}
	 */
	public static function from_request(): array {
		return [
			'utm_source'      => self::param( 'utm_source' ),
			'utm_medium'      => self::param( 'utm_medium' ),
			'utm_campaign'    => self::param( 'utm_campaign' ),
			'utm_content'     => self::param( 'utm_content' ),
			'referrer_domain' => self::referrer_domain(),
			'device_type'     => self::device_type(),
		];
	}

	private static function param( string $name ): ?string {
		$v = $_GET[ $name ] ?? '';
		if ( ! is_string( $v ) || $v === '' ) { return null; }
		return substr( sanitize_text_field( wp_unslash( $v ) ), 0, 64 );
	}

	private static function referrer_domain(): ?string {
		$ref = $_SERVER['HTTP_REFERER'] ?? '';
		if ( ! is_string( $ref ) || $ref === '' ) { return null; }
		$host = wp_parse_url( $ref, PHP_URL_HOST );
		if ( ! is_string( $host ) || $host === '' ) { return null; }
		return substr( strtolower( $host ), 0, 254 );
	}

	private static function device_type(): string {
		$ua = Visitor_Hash::user_agent();
		// Quick + cheap classification. Not as accurate as wp_is_mobile + custom
		// regex chains, but good enough for funnel reporting.
		if ( preg_match( '/iPad|Tablet|Kindle/i', $ua ) ) { return 'tablet'; }
		if ( wp_is_mobile() )                              { return 'mobile'; }
		return 'desktop';
	}
}
