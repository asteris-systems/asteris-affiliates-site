<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Sprint 2 helper page — lets you smoke-test the tracking engine BEFORE the
 * real signup flow lands in Sprint 3.
 *
 * Three things:
 *   1. One-click "Create test affiliate" button — inserts a row in
 *      wp_aff_affiliates with status='approved' and a fixed public_id
 *      so you have something to attribute clicks to.
 *   2. Shows the affiliate-link URL you should hit to test
 *      (e.g. https://your-site.local/?ref=test-aff-xyz123)
 *   3. Live table of the last 20 referral rows from wp_aff_referrals
 *      with full visibility (session_id, UTM, IP country, device, etc).
 *
 * Will be retired in Sprint 3 once the real affiliate signup + list pages
 * exist.
 */
final class Page_Test_Tracking {

	private const TEST_PUBLIC_ID = 'test-aff-sprint2';

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_create_test_affiliate', [ self::class, 'handle_create_test' ] );
		add_action( 'admin_post_asteris_aff_delete_test_referrals', [ self::class, 'handle_purge_referrals' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		global $wpdb;
		$test_aff = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_affiliates WHERE public_id = %s",
			self::TEST_PUBLIC_ID
		) );

		$ref_url = $test_aff ? add_query_arg( 'ref', $test_aff->public_id, home_url( '/' ) ) : '';

		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$recent = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}aff_referrals ORDER BY id DESC LIMIT 20"
		);
		?>
		<div class="wrap">
			<h1>Sprint 2 · Test Tracking</h1>
			<p style="color:#666;max-width:760px;">Smoke-test the tracking engine before Sprint 3 ships the real affiliate signup flow. Create a fixed test affiliate, hit the URL below in an incognito window, and watch rows land in the table at the bottom.</p>

			<?php if ( $flash === 'created' ) : ?>
				<div class="notice notice-success is-dismissible"><p>✓ Test affiliate created.</p></div>
			<?php elseif ( $flash === 'exists' ) : ?>
				<div class="notice notice-info is-dismissible"><p>Test affiliate already exists.</p></div>
			<?php elseif ( $flash === 'purged' ) : ?>
				<div class="notice notice-warning is-dismissible"><p>⚠ All referrals purged.</p></div>
			<?php endif; ?>

			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px;margin-top:18px;">
				<h2 style="margin-top:0;">1. Test affiliate</h2>
				<?php if ( $test_aff ) : ?>
					<table class="widefat striped" style="margin-bottom:14px;">
						<tr><th style="width:160px;">ID</th><td><?php echo (int) $test_aff->id; ?></td></tr>
						<tr><th>Display name</th><td><?php echo esc_html( $test_aff->display_name ); ?></td></tr>
						<tr><th>Email</th><td><?php echo esc_html( $test_aff->email ); ?></td></tr>
						<tr><th>public_id</th><td><code><?php echo esc_html( $test_aff->public_id ); ?></code></td></tr>
						<tr><th>Status</th><td><?php echo esc_html( $test_aff->status ); ?></td></tr>
					</table>
				<?php else : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'asteris_aff_create_test_affiliate' ); ?>
						<input type="hidden" name="action" value="asteris_aff_create_test_affiliate">
						<p>No test affiliate exists yet. Click below to create one:</p>
						<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;">Create test affiliate</button>
					</form>
				<?php endif; ?>
			</div>

			<?php if ( $test_aff ) : ?>
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px;margin-top:18px;">
					<h2 style="margin-top:0;">2. Hit this URL to fire a tracked click</h2>
					<p style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:12px 14px;font-family:ui-monospace,monospace;font-size:13px;word-break:break-all;">
						<a href="<?php echo esc_url( $ref_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $ref_url ); ?></a>
					</p>
					<p style="color:#666;font-size:13px;margin:8px 0 0;">Open in an incognito window for the cleanest test (no existing cookie). Then come back here and reload — a row should appear below.</p>
					<p style="color:#666;font-size:13px;">For UTM testing add params: <code>?ref=<?php echo esc_html( $test_aff->public_id ); ?>&amp;utm_source=newsletter&amp;utm_campaign=launch</code></p>
				</div>
			<?php endif; ?>

			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px;margin-top:18px;">
				<h2 style="margin-top:0;">3. Recent referrals (last 20)</h2>
				<?php if ( ! $recent ) : ?>
					<p style="color:#999;">No referrals captured yet. Click the URL above to fire one.</p>
				<?php else : ?>
					<table class="widefat striped" style="font-size:12px;">
						<thead><tr>
							<th>When (UTC)</th>
							<th>Aff ID</th>
							<th>Session</th>
							<th>Country</th>
							<th>Device</th>
							<th>UTM source</th>
							<th>UTM campaign</th>
							<th>Referrer</th>
							<th>Landed URL</th>
							<th>Converted?</th>
						</tr></thead>
						<tbody>
						<?php foreach ( $recent as $r ) : ?>
							<tr>
								<td style="white-space:nowrap;color:#666;font-family:ui-monospace,monospace;font-size:11px;"><?php echo esc_html( $r->landed_at ); ?></td>
								<td><?php echo (int) $r->affiliate_id; ?></td>
								<td style="font-family:ui-monospace,monospace;font-size:10px;color:#666;"><?php echo esc_html( substr( $r->session_id, 0, 14 ) ); ?>…</td>
								<td><?php echo esc_html( $r->ip_country ?? '—' ); ?></td>
								<td><?php echo esc_html( $r->device_type ?? '—' ); ?></td>
								<td><?php echo esc_html( $r->utm_source ?? '—' ); ?></td>
								<td><?php echo esc_html( $r->utm_campaign ?? '—' ); ?></td>
								<td><?php echo esc_html( $r->referrer_domain ?? '—' ); ?></td>
								<td style="max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:ui-monospace,monospace;font-size:11px;color:#666;" title="<?php echo esc_attr( $r->landed_url ); ?>"><?php echo esc_html( substr( $r->landed_url, 0, 50 ) ); ?>…</td>
								<td><?php echo $r->converted_at ? '<span style="color:#059669;">✓ ' . esc_html( $r->converted_at ) . '</span>' : '—'; ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:14px;" onsubmit="return confirm('Purge ALL referral rows? Used only for clean re-testing.');">
						<?php wp_nonce_field( 'asteris_aff_delete_test_referrals' ); ?>
						<input type="hidden" name="action" value="asteris_aff_delete_test_referrals">
						<button type="submit" class="button button-link-delete">Purge all referrals (test reset)</button>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	public static function handle_create_test(): void {
		check_admin_referer( 'asteris_aff_create_test_affiliate' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		global $wpdb;
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}aff_affiliates WHERE public_id = %s",
			self::TEST_PUBLIC_ID
		) );
		if ( $existing ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-test&flash=exists' ) );
			exit;
		}

		$now = current_time( 'mysql', true );
		$wpdb->insert( $wpdb->prefix . 'aff_affiliates', [
			'public_id'                 => self::TEST_PUBLIC_ID,
			'status'                    => 'approved',
			'display_name'              => 'Sprint 2 Test Affiliate',
			'email'                     => 'test-affiliate@asteriscommerce.local',
			'country_code'              => 'AU',
			'payout_method'             => 'stripe_connect',
			'commission_rate_y1_bp'     => 2000,
			'commission_rate_y2plus_bp' => 1000,
			'applied_at'                => $now,
			'approved_at'               => $now,
			'updated_at'                => $now,
		] );

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-test&flash=created' ) );
		exit;
	}

	public static function handle_purge_referrals(): void {
		check_admin_referer( 'asteris_aff_delete_test_referrals' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}aff_referrals" );
		$wpdb->query( "DELETE FROM {$wpdb->prefix}aff_events WHERE event_type = 'click.recorded'" );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-test&flash=purged' ) );
		exit;
	}
}
