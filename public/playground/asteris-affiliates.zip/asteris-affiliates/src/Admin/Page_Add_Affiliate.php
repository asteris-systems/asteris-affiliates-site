<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Manually add an affiliate from the admin — bypasses the public signup
 * funnel. Use for hand-picked outreach, CSV imports, re-onboarding.
 *
 * Form INSERTs with status='approved' + optionally fires welcome email.
 */
final class Page_Add_Affiliate {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_add_create', [ self::class, 'handle_create' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$extra = isset( $_GET['extra'] ) ? sanitize_text_field( wp_unslash( $_GET['extra'] ) ) : '';
		$default_y1 = (int) Settings::get( 'commission_rate_y1_bp', 2000 );
		$default_y2 = (int) Settings::get( 'commission_rate_y2plus_bp', 1000 );
		?>
		<div class="wrap">
			<h1>Add Affiliate Manually</h1>
			<p style="color:#666;max-width:720px;">Skip the public signup. Affiliate lands as <strong>approved</strong> immediately and (optionally) gets the welcome email.</p>

			<?php if ( $flash === 'invalid' || $flash === 'duplicate' || $flash === 'db_error' ) : ?>
				<div class="notice notice-error is-dismissible" style="padding:12px 16px;"><p>✗ <?php echo esc_html( $extra ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:680px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px;margin-top:18px;">
				<?php wp_nonce_field( 'asteris_aff_add_create' ); ?>
				<input type="hidden" name="action" value="asteris_aff_add_create">

				<h2 style="margin-top:0;">Who</h2>
				<table class="form-table" role="presentation">
					<tr><th>Display name *</th><td><input type="text" name="display_name" required maxlength="120" class="regular-text"></td></tr>
					<tr><th>Email *</th><td><input type="email" name="email" required maxlength="254" class="regular-text"></td></tr>
					<tr><th>First name</th><td><input type="text" name="first_name" maxlength="80" class="regular-text"></td></tr>
					<tr><th>Last name</th><td><input type="text" name="last_name" maxlength="80" class="regular-text"></td></tr>
					<tr><th>Country (ISO-2)</th><td><input type="text" name="country_code" maxlength="2" value="US" class="regular-text" style="max-width:80px;text-transform:uppercase;"></td></tr>
					<tr><th>Public ID</th><td>
						<input type="text" name="public_id" maxlength="48" pattern="^[a-z0-9](?:[a-z0-9-]{1,46}[a-z0-9])?$" placeholder="(blank = auto-generate)" class="regular-text" style="font-family:ui-monospace,monospace;max-width:320px;text-transform:lowercase;">
						<p class="description">Leave blank for a random ID. Or set a vanity one — e.g. <code>alex</code> → tracking link becomes <code><?php echo esc_html( home_url( '/?ref=alex' ) ); ?></code>. Lower-case letters / numbers / hyphens only, 3–48 chars. Must be unique.</p>
					</td></tr>
				</table>

				<h2>Commission</h2>
				<table class="form-table" role="presentation">
					<tr><th>Year 1 (bp)</th><td><input type="number" name="commission_rate_y1_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( $default_y1 ); ?>" class="regular-text" style="max-width:140px;"> <span style="color:#666;font-size:13px;">2000 = 20%</span></td></tr>
					<tr><th>Year 2+ (bp)</th><td><input type="number" name="commission_rate_y2plus_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( $default_y2 ); ?>" class="regular-text" style="max-width:140px;"></td></tr>
					<tr><th>Custom rate override (bp)</th><td><input type="number" name="custom_rate_override_bp" min="0" max="10000" step="50" placeholder="(blank = use Y1/Y2 rates)" class="regular-text" style="max-width:140px;"></td></tr>
				</table>

				<h2>Context</h2>
				<table class="form-table" role="presentation">
					<tr><th>Audience size</th><td><select name="audience_size" class="regular-text" style="max-width:240px;">
						<option value="">(unspecified)</option>
						<option value="&lt;1k">&lt;1,000</option>
						<option value="1k-10k">1,000–10,000</option>
						<option value="10k-50k">10,000–50,000</option>
						<option value="50k-200k">50,000–200,000</option>
						<option value="&gt;200k">&gt;200,000</option>
					</select></td></tr>
					<tr><th>Promotion plan</th><td><textarea name="promotion_plan" rows="3" class="large-text" placeholder="Newsletter, channel, podcast, etc."></textarea></td></tr>
					<tr><th>Internal notes</th><td><textarea name="notes_internal" rows="3" class="large-text" placeholder="Anything future-you should remember"></textarea></td></tr>
				</table>

				<h2>Onboarding</h2>
				<table class="form-table" role="presentation">
					<tr><th>Send welcome email?</th><td><label><input type="checkbox" name="send_welcome" value="1" checked> Email the affiliate now with portal sign-in link</label></td></tr>
				</table>

				<p style="margin-top:20px;">
					<button type="submit" class="button button-primary button-large" style="background:#06D6A0;border-color:#06D6A0;">Create affiliate</button>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates' ) ); ?>" class="button">Cancel</a>
				</p>
			</form>
		</div>
		<?php
	}

	public static function handle_create(): void {
		check_admin_referer( 'asteris_aff_add_create' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$display_name = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
		$email        = isset( $_POST['email'] )        ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

		if ( $display_name === '' || ! is_email( $email ) ) {
			self::redirect( 'invalid', 'Display name + valid email both required.' );
		}
		if ( Affiliate_Repository::find_by_email( $email ) ) {
			self::redirect( 'duplicate', 'An affiliate with that email already exists.' );
		}

		// Optional public_id — validate format + uniqueness if provided.
		// Leave blank to let Affiliate_Repository::insert auto-generate.
		$public_id = null;
		if ( ! empty( $_POST['public_id'] ) ) {
			$public_id = Affiliate_Repository::sanitise_public_id( (string) wp_unslash( $_POST['public_id'] ) );
			if ( $public_id === null ) {
				self::redirect( 'invalid', 'Public ID must be 3–48 lower-case letters / numbers / hyphens, with no leading or trailing hyphen.' );
			}
			if ( ! Affiliate_Repository::is_public_id_available( $public_id ) ) {
				self::redirect( 'duplicate', 'Public ID "' . $public_id . '" is already used by another affiliate.' );
			}
		}

		$now = current_time( 'mysql', true );
		$custom_override = ! empty( $_POST['custom_rate_override_bp'] ) ? (int) $_POST['custom_rate_override_bp'] : null;

		$insert_fields = [
			'first_name'                => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : null,
			'last_name'                 => isset( $_POST['last_name'] )  ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) )  : null,
			'display_name'              => $display_name,
			'email'                     => $email,
			'country_code'              => isset( $_POST['country_code'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['country_code'] ) ) ) : 'US',
			'status'                    => 'approved',
			'commission_rate_y1_bp'     => isset( $_POST['commission_rate_y1_bp'] )     ? (int) $_POST['commission_rate_y1_bp']     : 2000,
			'commission_rate_y2plus_bp' => isset( $_POST['commission_rate_y2plus_bp'] ) ? (int) $_POST['commission_rate_y2plus_bp'] : 1000,
			'custom_rate_override_bp'   => $custom_override,
			'audience_size'             => isset( $_POST['audience_size'] )   ? sanitize_text_field( wp_unslash( $_POST['audience_size'] ) ) : null,
			'promotion_plan'            => isset( $_POST['promotion_plan'] )  ? sanitize_textarea_field( wp_unslash( $_POST['promotion_plan'] ) ) : null,
			'notes_internal'            => isset( $_POST['notes_internal'] )  ? sanitize_textarea_field( wp_unslash( $_POST['notes_internal'] ) ) : null,
			'applied_at'                => $now,
			'approved_at'               => $now,
		];
		// Only include public_id if customer supplied one — empty lets the
		// repository auto-generate.
		if ( $public_id !== null ) {
			$insert_fields['public_id'] = $public_id;
		}
		$id = Affiliate_Repository::insert( $insert_fields );

		if ( ! $id ) {
			self::redirect( 'db_error', 'Database insert failed.' );
		}

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'affiliate.added_manually',
			'affiliate_id' => $id,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'email' => $email, 'display_name' => $display_name ] ),
		] );

		if ( isset( $_POST['send_welcome'] ) ) {
			$body = "Hi {$display_name},\n\nYou've been added as an affiliate. Sign in to grab your tracking links:\n"
			      . home_url( '/affiliate-portal/' ) . "\n";
			wp_mail( $email, 'You\'re in — sign in to your affiliate portal', $body );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=created_manually' ) );
		exit;
	}

	private static function redirect( string $flash, string $extra = '' ): void {
		wp_safe_redirect( add_query_arg( [
			'page' => 'asteris-affiliates-add', 'flash' => $flash, 'extra' => $extra,
		], admin_url( 'admin.php' ) ) );
		exit;
	}
}
