<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * High-level affiliate program reports.
 *
 *   - Date-range filter (9A — defaults to last 30 days, picker for custom)
 *   - Overview: total commissions, payout-ready, clicks, conversions in window
 *   - Top 10 affiliates by approved+paid earnings in window
 *   - Refund rate heatmap (top 5 by refund rate, only affiliates with >= 5 commissions)
 */
final class Page_Reports {

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		// Date range — defaults to last 30 days. ISO format YYYY-MM-DD.
		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		$to   = isset( $_GET['to'] )   ? sanitize_text_field( wp_unslash( $_GET['to'] ) )   : gmdate( 'Y-m-d' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) { $from = gmdate( 'Y-m-d', strtotime( '-30 days' ) ); }
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to   ) ) { $to   = gmdate( 'Y-m-d' ); }
		$from_dt = $from . ' 00:00:00';
		$to_dt   = $to   . ' 23:59:59';

		global $wpdb;
		$p = $wpdb->prefix;

		$overview = [
			'commissions_in_range' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_commissions WHERE created_at BETWEEN %s AND %s", $from_dt, $to_dt ) ),
			'earnings_in_range'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE created_at BETWEEN %s AND %s AND status IN ('approved','paid')", $from_dt, $to_dt ) ),
			'pending_cents'        => (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE status = 'pending'" ),
			'payout_ready'         => (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE status = 'approved'" ),
			'clicks_in_range'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE landed_at BETWEEN %s AND %s", $from_dt, $to_dt ) ),
			'conv_rate'            => 0.0,
		];
		if ( $overview['clicks_in_range'] > 0 ) {
			$overview['conv_rate'] = round( ( $overview['commissions_in_range'] / $overview['clicks_in_range'] ) * 100, 1 );
		}

		$top = $wpdb->get_results( $wpdb->prepare(
			"SELECT
			   a.id, a.display_name, a.email, a.public_id,
			   COALESCE(SUM(CASE WHEN c.status IN ('approved','paid') THEN c.amount_cents ELSE 0 END),0) AS earnings_cents,
			   COUNT(c.id) AS commission_count
			 FROM {$p}aff_affiliates a
			 LEFT JOIN {$p}aff_commissions c ON c.affiliate_id = a.id AND c.created_at BETWEEN %s AND %s
			 WHERE a.status = 'approved'
			 GROUP BY a.id
			 HAVING commission_count > 0
			 ORDER BY earnings_cents DESC
			 LIMIT 10",
			$from_dt, $to_dt
		) );

		$rr = $wpdb->get_results( $wpdb->prepare(
			"SELECT
			   a.id, a.display_name, a.email,
			   COUNT(c.id) AS total,
			   SUM(CASE WHEN c.status = 'refunded' THEN 1 ELSE 0 END) AS refunded
			 FROM {$p}aff_affiliates a
			 INNER JOIN {$p}aff_commissions c ON c.affiliate_id = a.id AND c.created_at BETWEEN %s AND %s
			 GROUP BY a.id
			 HAVING total >= 5
			 ORDER BY (refunded * 1.0 / total) DESC
			 LIMIT 5",
			$from_dt, $to_dt
		) );

		$preset = static function ( string $label, int $days ): string {
			$f = gmdate( 'Y-m-d', strtotime( '-' . $days . ' days' ) );
			$t = gmdate( 'Y-m-d' );
			return '<a href="' . esc_url( add_query_arg( [ 'page' => 'asteris-affiliates-reports', 'from' => $f, 'to' => $t ], admin_url( 'admin.php' ) ) ) . '" class="button" style="font-size:11px;">' . esc_html( $label ) . '</a>';
		};
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Reports', 'asteris-affiliates' ); ?></h1>
			<p style="color:#666;"><?php esc_html_e( 'Click any affiliate to drill into their detail page.', 'asteris-affiliates' ); ?></p>

			<!-- Date-range picker -->
			<form method="get" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;margin:14px 0 18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
				<input type="hidden" name="page" value="asteris-affiliates-reports">
				<label style="font-size:12px;color:#666;font-weight:600;"><?php esc_html_e( 'From', 'asteris-affiliates' ); ?>
					<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>" style="margin-left:4px;">
				</label>
				<label style="font-size:12px;color:#666;font-weight:600;"><?php esc_html_e( 'To', 'asteris-affiliates' ); ?>
					<input type="date" name="to" value="<?php echo esc_attr( $to ); ?>" style="margin-left:4px;">
				</label>
				<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;"><?php esc_html_e( 'Apply', 'asteris-affiliates' ); ?></button>
				<span style="border-left:1px solid #e5e7eb;height:24px;margin:0 4px;"></span>
				<?php echo $preset( __( 'Last 7d', 'asteris-affiliates' ), 7 ); // phpcs:ignore ?>
				<?php echo $preset( __( 'Last 30d', 'asteris-affiliates' ), 30 ); // phpcs:ignore ?>
				<?php echo $preset( __( 'Last 90d', 'asteris-affiliates' ), 90 ); // phpcs:ignore ?>
				<?php echo $preset( __( 'Last year', 'asteris-affiliates' ), 365 ); // phpcs:ignore ?>
				<span style="margin-left:auto;color:#666;font-size:12px;">
					<?php
					/* translators: %1$s = from date, %2$s = to date */
					echo esc_html( sprintf( __( 'Showing %1$s → %2$s', 'asteris-affiliates' ), $from, $to ) );
					?>
				</span>
			</form>

			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:18px 0;">
				<?php foreach ( [
					[ __( 'Commissions', 'asteris-affiliates' ), number_format_i18n( $overview['commissions_in_range'] ), '#0a857a' ],
					[ __( 'Earnings', 'asteris-affiliates' ), '$' . number_format( $overview['earnings_in_range'] / 100, 2 ), '#06D6A0' ],
					[ __( 'Payout-ready', 'asteris-affiliates' ), '$' . number_format( $overview['payout_ready'] / 100, 2 ), '#059669' ],
					[ __( 'Pending', 'asteris-affiliates' ), '$' . number_format( $overview['pending_cents'] / 100, 2 ), '#ea580c' ],
					[ __( 'Clicks', 'asteris-affiliates' ), number_format_i18n( $overview['clicks_in_range'] ), '#06D6A0' ],
					[ __( 'Conversion rate', 'asteris-affiliates' ), $overview['conv_rate'] . '%', '#0a857a' ],
				] as $c ) : [ $l, $v, $clr ] = $c; ?>
					<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo esc_attr( $clr ); ?>;border-radius:8px;padding:14px 16px;">
						<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $l ); ?></div>
						<div style="font-size:22px;color:#0a0a0a;font-weight:800;margin-top:2px;"><?php echo esc_html( $v ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<h2 style="margin-top:24px;"><?php esc_html_e( 'Top 10 affiliates · in range', 'asteris-affiliates' ); ?></h2>
			<table class="widefat striped" style="font-size:13px;">
				<thead><tr><th>#</th><th><?php esc_html_e( 'Affiliate', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Email', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Commissions', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Earnings', 'asteris-affiliates' ); ?></th></tr></thead>
				<tbody>
				<?php if ( ! $top ) : ?>
					<tr><td colspan="5" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No commissions in the selected range.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $top as $i => $r ) : ?>
					<tr>
						<td>#<?php echo (int) ( $i + 1 ); ?></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->id ) ); ?>" style="color:#06D6A0;font-weight:600;"><?php echo esc_html( $r->display_name ); ?></a></td>
						<td style="color:#666;font-size:12px;"><?php echo esc_html( $r->email ); ?></td>
						<td><?php echo (int) $r->commission_count; ?></td>
						<td><strong>$<?php echo esc_html( number_format( $r->earnings_cents / 100, 2 ) ); ?></strong></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>

			<h2 style="margin-top:24px;"><?php esc_html_e( 'Refund-rate heatmap · in range', 'asteris-affiliates' ); ?></h2>
			<p style="color:#666;font-size:13px;"><?php esc_html_e( 'Affiliates with ≥5 commissions in range. Auto-suspend triggers at the threshold configured in Settings (default 20%).', 'asteris-affiliates' ); ?></p>
			<table class="widefat striped" style="font-size:13px;">
				<thead><tr><th><?php esc_html_e( 'Affiliate', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Email', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Commissions', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Refunded', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Refund rate', 'asteris-affiliates' ); ?></th></tr></thead>
				<tbody>
				<?php if ( ! $rr ) : ?>
					<tr><td colspan="5" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No affiliates with enough commission volume yet.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $rr as $r ) :
					$pct = (int) round( ( (int) $r->refunded / (int) $r->total ) * 100 );
					$colour = $pct >= 20 ? '#dc2626' : ( $pct >= 10 ? '#ea580c' : '#059669' );
				?>
					<tr>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->id ) ); ?>" style="color:#06D6A0;font-weight:600;"><?php echo esc_html( $r->display_name ); ?></a></td>
						<td style="color:#666;font-size:12px;"><?php echo esc_html( $r->email ); ?></td>
						<td><?php echo (int) $r->total; ?></td>
						<td><?php echo (int) $r->refunded; ?></td>
						<td><strong style="color:<?php echo esc_attr( $colour ); ?>;"><?php echo (int) $pct; ?>%</strong></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
