<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Shared helper for sortable admin column headers.
 *
 *   Sort_Helper::th( 'Earnings', 'earnings', $current_orderby, $current_order, $base_url )
 *     → renders an <th> with a link that toggles ASC/DESC
 *
 *   [ $orderby_sql, $order_sql ] = Sort_Helper::resolve( $whitelist, $default_orderby, $default_order )
 *     → returns safe ORDER BY column + direction for use in raw SQL
 */
final class Sort_Helper {

	/** Render a sortable <th> for the given column. */
	public static function th( string $label, string $col_key, string $current_orderby, string $current_order, string $base_url ): string {
		$is_active = $current_orderby === $col_key;
		$next_dir  = ( $is_active && strtolower( $current_order ) === 'asc' ) ? 'desc' : 'asc';
		$url       = add_query_arg( [ 'orderby' => $col_key, 'order' => $next_dir ], $base_url );
		$arrow     = $is_active ? ( strtolower( $current_order ) === 'asc' ? ' ▲' : ' ▼' ) : '';
		return '<th><a href="' . esc_url( $url ) . '" style="text-decoration:none;color:inherit;">' . esc_html( $label ) . '<span style="color:#06D6A0;">' . esc_html( $arrow ) . '</span></a></th>';
	}

	/**
	 * Resolve safe (orderby_sql, order_sql) from $_GET. Only columns in the
	 * whitelist are honoured — protects against SQL injection in ORDER BY.
	 *
	 * @param array<string,string> $whitelist   key → actual SQL column expression
	 */
	public static function resolve( array $whitelist, string $default_orderby = 'id', string $default_order = 'DESC' ): array {
		$orderby_in = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : $default_orderby;
		$order_in   = isset( $_GET['order'] )   ? strtoupper( sanitize_key( wp_unslash( $_GET['order'] ) ) ) : $default_order;

		$orderby_sql = $whitelist[ $orderby_in ] ?? $whitelist[ $default_orderby ] ?? 'id';
		$order_sql   = in_array( $order_in, [ 'ASC', 'DESC' ], true ) ? $order_in : 'DESC';

		return [ $orderby_sql, $order_sql, $orderby_in, strtolower( $order_sql ) ];
	}
}
