<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Free_Tier;

defined( 'ABSPATH' ) || exit;

/**
 * Vanity landing pages admin.
 *
 * Manage /go/{handle} branded landing pages. Each page is tied to an
 * affiliate and drops their tracking cookie on view.
 *
 * Pro-only — page renders an upgrade pitch when free.
 */
final class Page_Landing_Pages {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_landing_save',   [ self::class, 'handle_save' ] );
		add_action( 'admin_post_asteris_aff_landing_delete', [ self::class, 'handle_delete' ] );
		add_action( 'admin_post_asteris_aff_landing_toggle', [ self::class, 'handle_toggle' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		if ( Free_Tier::is_free() ) {
			self::render_pro_upsell();
			return;
		}

		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$edit  = isset( $_GET['edit'] )  ? (int) $_GET['edit'] : 0;
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT p.*, a.display_name AS aff_name FROM {$wpdb->prefix}aff_landing_pages p LEFT JOIN {$wpdb->prefix}aff_affiliates a ON a.id = p.affiliate_id ORDER BY p.id DESC LIMIT 200" );
		$editing = $edit ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}aff_landing_pages WHERE id = %d", $edit ) ) : null;
		$affiliates = Affiliate_Repository::list( [ 'status' => 'approved', 'limit' => 500 ] );
		?>
		<div class="wrap" style="max-width:1100px;">
			<h1><?php esc_html_e( 'Vanity Landing Pages', 'asteris-affiliates' ); ?></h1>
			<p style="color:#666;"><?php esc_html_e( 'Create branded /go/{handle} landing pages for each affiliate. Each page sets the affiliate\'s tracking cookie on view + counts views.', 'asteris-affiliates' ); ?></p>

			<?php self::render_flash( $flash ); ?>

			<!-- Add/edit form -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:24px;margin:18px 0;">
				<h2 style="margin:0 0 14px;font-size:16px;"><?php echo $editing ? esc_html__( 'Edit landing page', 'asteris-affiliates' ) : esc_html__( 'Create a landing page', 'asteris-affiliates' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'asteris_aff_landing_save' ); ?>
					<input type="hidden" name="action" value="asteris_aff_landing_save">
					<?php if ( $editing ) : ?><input type="hidden" name="id" value="<?php echo (int) $editing->id; ?>"><?php endif; ?>

					<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Affiliate', 'asteris-affiliates' ); ?></span>
							<select name="affiliate_id" required style="width:100%;">
								<option value=""><?php esc_html_e( '— Select —', 'asteris-affiliates' ); ?></option>
								<?php foreach ( $affiliates as $a ) : ?>
									<option value="<?php echo (int) $a->id; ?>" <?php selected( $editing && (int) $editing->affiliate_id === (int) $a->id ); ?>><?php echo esc_html( $a->display_name . ' (' . $a->email . ')' ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Handle (URL slug)', 'asteris-affiliates' ); ?></span>
							<input type="text" name="handle" required maxlength="48" pattern="[a-z0-9-]+" value="<?php echo esc_attr( $editing->handle ?? '' ); ?>" style="width:100%;" placeholder="<?php esc_attr_e( 'eg sarah-promo', 'asteris-affiliates' ); ?>">
							<div style="color:#999;font-size:11px;margin-top:2px;"><?php echo esc_html( home_url( '/go/' ) ); ?><strong id="aff-handle-preview"><?php echo esc_html( $editing->handle ?? '...' ); ?></strong></div>
						</label>
					</div>

					<label style="display:block;margin-top:14px;"><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Headline', 'asteris-affiliates' ); ?></span>
						<input type="text" name="headline" maxlength="140" value="<?php echo esc_attr( $editing->headline ?? '' ); ?>" style="width:100%;" placeholder="<?php esc_attr_e( 'eg Save 20% on your first order', 'asteris-affiliates' ); ?>">
					</label>

					<label style="display:block;margin-top:14px;"><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Subhead', 'asteris-affiliates' ); ?></span>
						<textarea name="subhead" rows="2" style="width:100%;"><?php echo esc_textarea( $editing->subhead ?? '' ); ?></textarea>
					</label>

					<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px;">
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'CTA label', 'asteris-affiliates' ); ?></span>
							<input type="text" name="cta_label" maxlength="48" value="<?php echo esc_attr( $editing->cta_label ?? 'Get started →' ); ?>" style="width:100%;">
						</label>
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'CTA target URL', 'asteris-affiliates' ); ?></span>
							<input type="url" name="cta_target_url" value="<?php echo esc_attr( $editing->cta_target_url ?? home_url( '/' ) ); ?>" style="width:100%;">
						</label>
					</div>

					<label style="display:block;margin-top:14px;"><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Hero image URL (optional)', 'asteris-affiliates' ); ?></span>
						<input type="url" name="hero_image_url" value="<?php echo esc_attr( $editing->hero_image_url ?? '' ); ?>" style="width:100%;" placeholder="https://...">
					</label>

					<p style="margin-top:18px;">
						<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;"><?php echo $editing ? esc_html__( 'Save changes', 'asteris-affiliates' ) : esc_html__( 'Create landing page', 'asteris-affiliates' ); ?></button>
						<?php if ( $editing ) : ?><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-landing' ) ); ?>" class="button"><?php esc_html_e( 'Cancel', 'asteris-affiliates' ); ?></a><?php endif; ?>
					</p>
				</form>
				<script>
				document.querySelector('input[name="handle"]')?.addEventListener('input', function(e){
					document.getElementById('aff-handle-preview').textContent = e.target.value || '...';
				});
				</script>
			</div>

			<!-- List -->
			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th><?php esc_html_e( 'URL', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Headline', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Affiliate', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Views', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Status', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'asteris-affiliates' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="6" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No landing pages yet.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$url = home_url( '/go/' . $r->handle );
					$edit_url = admin_url( 'admin.php?page=asteris-affiliates-landing&edit=' . (int) $r->id );
					$toggle_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_landing_toggle&id=' . (int) $r->id ), 'asteris_aff_landing_toggle_' . (int) $r->id );
					$delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_landing_delete&id=' . (int) $r->id ), 'asteris_aff_landing_delete_' . (int) $r->id );
					?>
					<tr>
						<td><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;font-family:ui-monospace,monospace;">/go/<?php echo esc_html( $r->handle ); ?> ↗</a></td>
						<td><?php echo esc_html( $r->headline ?: '—' ); ?></td>
						<td><?php echo esc_html( $r->aff_name ?? '—' ); ?></td>
						<td><strong><?php echo (int) $r->views; ?></strong></td>
						<td><?php echo $r->active ? '<span style="color:#059669;">● Active</span>' : '<span style="color:#999;">○ Off</span>'; ?></td>
						<td>
							<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small"><?php esc_html_e( 'Edit', 'asteris-affiliates' ); ?></a>
							<a href="<?php echo esc_url( $toggle_url ); ?>" class="button button-small"><?php echo $r->active ? esc_html__( 'Disable', 'asteris-affiliates' ) : esc_html__( 'Enable', 'asteris-affiliates' ); ?></a>
							<a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small" style="color:#dc2626;" onclick="return confirm('<?php esc_attr_e( 'Delete this landing page?', 'asteris-affiliates' ); ?>')"><?php esc_html_e( 'Delete', 'asteris-affiliates' ); ?></a>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function render_pro_upsell(): void {
		?>
		<div class="wrap" style="max-width:780px;">
			<h1><?php esc_html_e( 'Vanity Landing Pages', 'asteris-affiliates' ); ?></h1>
			<div style="background:linear-gradient(135deg,#06D6A0,#0a857a);color:#fff;padding:36px;border-radius:12px;margin:24px 0;">
				<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;opacity:0.85;font-weight:700;margin-bottom:8px;">✨ PRO FEATURE</div>
				<h2 style="margin:0 0 12px;color:#fff;font-size:28px;letter-spacing:-1px;"><?php esc_html_e( 'Branded landing pages per affiliate', 'asteris-affiliates' ); ?></h2>
				<p style="margin:0 0 22px;font-size:15px;opacity:0.95;line-height:1.5;"><?php esc_html_e( "Give each affiliate a clean /go/{handle} URL with custom headline, hero image, and CTA. Cleaner to share on Instagram bio / podcasts / SMS than a raw ?ref= link. Tracks views independently of click-through.", 'asteris-affiliates' ); ?></p>
				<a href="https://asterisaffiliates.com/pricing?utm_source=plugin&utm_medium=landing_pages&utm_campaign=upsell" target="_blank" rel="noopener" style="background:#fff;color:#0a857a;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:800;font-size:15px;display:inline-block;"><?php esc_html_e( 'Upgrade to Pro →', 'asteris-affiliates' ); ?></a>
			</div>
		</div>
		<?php
	}

	public static function handle_save(): void {
		check_admin_referer( 'asteris_aff_landing_save' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		if ( Free_Tier::is_free() ) { wp_die( 'Pro only.', 403 ); }

		$id           = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$affiliate_id = isset( $_POST['affiliate_id'] ) ? (int) $_POST['affiliate_id'] : 0;
		$handle       = isset( $_POST['handle'] ) ? sanitize_key( wp_unslash( $_POST['handle'] ) ) : '';
		$headline     = isset( $_POST['headline'] ) ? sanitize_text_field( wp_unslash( $_POST['headline'] ) ) : '';
		$subhead      = isset( $_POST['subhead'] )  ? sanitize_textarea_field( wp_unslash( $_POST['subhead'] ) ) : '';
		$cta_label    = isset( $_POST['cta_label'] ) ? sanitize_text_field( wp_unslash( $_POST['cta_label'] ) ) : '';
		$cta_url      = isset( $_POST['cta_target_url'] ) ? esc_url_raw( wp_unslash( $_POST['cta_target_url'] ) ) : '';
		$hero_url     = isset( $_POST['hero_image_url'] ) ? esc_url_raw( wp_unslash( $_POST['hero_image_url'] ) ) : '';

		if ( $affiliate_id === 0 || $handle === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-landing&flash=missing_field' ) ); exit;
		}
		// Uniqueness — exclude self when editing
		global $wpdb;
		$exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}aff_landing_pages WHERE handle = %s AND id != %d LIMIT 1",
			$handle, $id
		) );
		if ( $exists ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-landing&flash=handle_taken' . ( $id ? '&edit=' . $id : '' ) ) ); exit;
		}

		$now = current_time( 'mysql', true );
		$data = [
			'affiliate_id'   => $affiliate_id,
			'handle'         => $handle,
			'headline'       => $headline,
			'subhead'        => $subhead,
			'cta_label'      => $cta_label,
			'cta_target_url' => $cta_url,
			'hero_image_url' => $hero_url,
			'updated_at'     => $now,
		];
		if ( $id ) {
			$wpdb->update( $wpdb->prefix . 'aff_landing_pages', $data, [ 'id' => $id ] );
			$flash = 'updated';
		} else {
			$data['created_at'] = $now;
			$data['active']     = 1;
			$wpdb->insert( $wpdb->prefix . 'aff_landing_pages', $data );
			$flash = 'created';
		}
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-landing&flash=' . $flash ) ); exit;
	}

	public static function handle_delete(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_landing_delete_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'aff_landing_pages', [ 'id' => $id ] );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-landing&flash=deleted' ) ); exit;
	}

	public static function handle_toggle(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_landing_toggle_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}aff_landing_pages SET active = 1 - active WHERE id = %d", $id ) );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-landing&flash=toggled' ) ); exit;
	}

	private static function render_flash( string $f ): void {
		$map = [
			'created'      => [ 'ok',  '✓ Landing page created.' ],
			'updated'      => [ 'ok',  '✓ Landing page updated.' ],
			'deleted'      => [ 'warn','⚠ Landing page deleted.' ],
			'toggled'      => [ 'ok',  '✓ Landing page status toggled.' ],
			'missing_field'=> [ 'err', '✗ Affiliate and handle are required.' ],
			'handle_taken' => [ 'err', '✗ That handle is already in use. Pick another.' ],
		];
		if ( ! isset( $map[ $f ] ) ) { return; }
		[ $kind, $msg ] = $map[ $f ];
		$style = $kind === 'ok' ? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: ( $kind === 'warn' ? 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;' );
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . esc_html( $msg ) . '</p></div>';
	}
}
