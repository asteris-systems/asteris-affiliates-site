<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Global activity log viewer.
 *
 * Reads wp_aff_events — every commission, click, payout, cron run, admin
 * edit, fraud suspension, email send/failure is recorded there.
 *
 * Filter by event_type prefix (commission.*, affiliate.*, cron.*, email.*, etc).
 */
final class Page_Activity {

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$filter = isset( $_GET['type'] ) ? sanitize_text_field( wp_unslash( $_GET['type'] ) ) : '';
		$limit  = isset( $_GET['limit'] ) ? max( 50, min( 500, (int) $_GET['limit'] ) ) : 100;

		global $wpdb;
		$where  = '1=1';
		$params = [];
		if ( $filter !== '' ) {
			$where .= ' AND event_type LIKE %s';
			$params[] = $wpdb->esc_like( $filter ) . '%';
		}
		$sql = "SELECT * FROM {$wpdb->prefix}aff_events WHERE {$where} ORDER BY id DESC LIMIT %d";
		$params[] = $limit;
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );

		$preset_filters = [
			''                => 'All',
			'affiliate.'      => 'Affiliate · status',
			'commission.'     => 'Commission · lifecycle',
			'click.'          => 'Clicks',
			'coupon.'         => 'Coupons',
			'email.'          => 'Email · send/fail',
			'cron.'           => 'Cron runs',
		];
		?>
		<div class="wrap">
			<h1>Activity log</h1>
			<p style="color:#666;">Every event the plugin emits. Last <strong><?php echo (int) $limit; ?></strong> entries.</p>

			<div style="margin:14px 0;display:flex;gap:6px;flex-wrap:wrap;">
				<?php foreach ( $preset_filters as $val => $label ) :
					$active = $filter === $val;
					$url = $val === ''
						? admin_url( 'admin.php?page=asteris-affiliates-activity' )
						: admin_url( 'admin.php?page=asteris-affiliates-activity&type=' . urlencode( $val ) );
				?>
					<a href="<?php echo esc_url( $url ); ?>" class="button button-small" style="<?php echo $active ? 'background:#06D6A0;border-color:#06D6A0;color:#fff;' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
				<form method="get" style="display:inline-flex;gap:6px;align-items:center;margin-left:8px;">
					<input type="hidden" name="page" value="asteris-affiliates-activity">
					<input type="text" name="type" value="<?php echo esc_attr( $filter ); ?>" placeholder="custom prefix, e.g. payout." style="padding:3px 8px;font-size:12px;">
					<button class="button button-small">Filter</button>
				</form>
			</div>

			<table class="widefat striped" style="font-size:12px;">
				<thead><tr>
					<th style="width:170px;">When (UTC)</th>
					<th style="width:240px;">Event</th>
					<th style="width:140px;">Actor</th>
					<th style="width:80px;">Affiliate</th>
					<th>Payload</th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="5" style="text-align:center;padding:30px;color:#999;">No events match.</td></tr>
				<?php else : foreach ( $rows as $r ) : ?>
					<tr>
						<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( $r->occurred_at ); ?></td>
						<td><code style="font-size:11px;"><?php echo esc_html( $r->event_type ); ?></code></td>
						<td style="font-size:11px;color:#666;"><?php echo esc_html( $r->actor ); ?></td>
						<td><?php if ( $r->affiliate_id ) : ?>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->affiliate_id ) ); ?>" style="color:#06D6A0;">#<?php echo (int) $r->affiliate_id; ?></a>
						<?php endif; ?></td>
						<td style="font-family:ui-monospace,monospace;font-size:10px;color:#666;word-break:break-all;"><?php echo esc_html( (string) $r->payload ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
