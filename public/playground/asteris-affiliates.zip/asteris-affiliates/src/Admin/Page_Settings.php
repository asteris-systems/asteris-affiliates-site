<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Settings admin page — the full settings form.
 *
 * Uses admin-post.php (NOT WP Settings API — see feedback_admin_post_pattern.md
 * standing rule). Single form, single nonce, single redirect.
 */
final class Page_Settings {

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$s     = Settings::all();
		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		?>
		<?php $tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'commissions'; ?>
		<?php
		// v1.2.0 — surface integration detection at the top of Settings so
		// the customer can confirm which adapters are actually wired up.
		// Full breakdown lives on the Overview page; this is a one-liner.
		$integrations = Page_Overview::detect_integrations();
		?>
		<div class="wrap">
			<h1>Asteris Affiliates · Settings</h1>

			<div style="margin:12px 0 0;padding:10px 14px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:6px;font-size:13px;color:#475569;">
				<strong style="color:#0a0a0a;">Detected integrations:</strong>
				<?php foreach ( $integrations as $info ) : ?>
					<span style="margin-left:10px;" title="<?php echo esc_attr( $info['notes'] ); ?>">
						<?php
						if ( $info['state'] === 'active' ) {
							echo '<span style="color:#06D6A0;font-weight:700;">✓</span>';
						} elseif ( $info['state'] === 'requires_pro' ) {
							echo '<span style="color:#d97706;font-weight:700;" title="Installed but Pro licence required">★</span>';
						} else {
							echo '<span style="color:#cbd5e1;">○</span>';
						}
						?>
						<?php echo esc_html( $info['label'] ); ?>
					</span>
				<?php endforeach; ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Page_Overview::SLUG ) ); ?>" style="float:right;color:#06D6A0;font-weight:600;text-decoration:none;">Overview →</a>
			</div>

			<style>
				.aff-tabs { display:flex; gap:0; margin:18px 0 0; border-bottom:1px solid #ccd0d4; }
				.aff-tabs a { padding:10px 18px; text-decoration:none; color:#555; border-bottom:2px solid transparent; font-weight:500; font-size:14px; }
				.aff-tabs a.active { color:#06D6A0; border-bottom-color:#06D6A0; font-weight:700; }
				.aff-tab-section { display:none; }
				.aff-tab-section.active { display:block; }
				body.aff-tab-commissions #aff-tab-commissions,
				body.aff-tab-attribution #aff-tab-attribution,
				body.aff-tab-payouts #aff-tab-payouts,
				body.aff-tab-stripe #aff-tab-stripe,
				body.aff-tab-fraud #aff-tab-fraud,
				body.aff-tab-signup #aff-tab-signup { display:block; }
				body.aff-tab-pro #aff-tab-pro { display:block; }
				body.aff-tab-paypal #aff-tab-paypal { display:block; }
				body.aff-tab-cloud #aff-tab-cloud { display:block; }
			</style>
			<script>document.body.classList.add('aff-tab-<?php echo esc_js( $tab ); ?>');</script>

			<nav class="aff-tabs">
				<?php foreach ( [
					'commissions' => '💰 Commissions',
					'attribution' => '🎯 Attribution',
					'payouts'     => '🏦 Payouts',
					'stripe'      => '🟦 Stripe',
					'paypal'      => '🅿️ PayPal',
					'fraud'       => '🛡️ Anti-fraud',
					'signup'      => '✍ Signup form',
					'pro'         => '✨ Pro features',
					'cloud'       => '☁️ Cloud assist',
				] as $t => $label ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-settings&tab=' . $t ) ); ?>" class="<?php echo $tab === $t ? 'active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</nav>

			<?php
			$flash_extra = isset( $_GET['extra'] ) ? sanitize_text_field( wp_unslash( $_GET['extra'] ) ) : '';
			?>
			<?php if ( $flash === 'saved' ) : ?>
				<div class="notice notice-success is-dismissible" style="padding:12px 16px;"><p>✓ Settings saved.</p></div>
			<?php elseif ( $flash === 'reset' ) : ?>
				<div class="notice notice-warning is-dismissible" style="padding:12px 16px;"><p>⚠ Reset to defaults.</p></div>
			<?php elseif ( $flash === 'stripe_bad_format' ) : ?>
				<div class="notice notice-error is-dismissible" style="padding:12px 16px;"><p>✗ Stripe key looks malformed. Must start with <code>sk_live_</code> or <code>sk_test_</code> followed by alphanumeric chars.</p></div>
			<?php elseif ( $flash === 'stripe_invalid' ) : ?>
				<div class="notice notice-error is-dismissible" style="padding:12px 16px;"><p>✗ Stripe rejected the key — <strong><?php echo esc_html( $flash_extra ); ?></strong>. Double-check it from <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener">dashboard.stripe.com/apikeys</a> (live vs test mode matters).</p></div>
			<?php elseif ( $flash === 'stripe_mu_failed' ) : ?>
				<div class="notice notice-warning is-dismissible" style="padding:12px 16px;"><p>⚠ Couldn't write to <code>wp-content/mu-plugins/</code> (<?php echo esc_html( $flash_extra ); ?>). Key saved to <code>wp_options</code> as fallback. To use the mu-plugin approach, ensure that directory is writable, then re-save.</p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:0 0 8px 8px;border-top:0;padding:24px 28px;max-width:840px;">
				<?php wp_nonce_field( 'asteris_aff_save_settings' ); ?>
				<input type="hidden" name="action" value="asteris_aff_save_settings">

				<div id="aff-tab-commissions" class="aff-tab-section">
				<h2 style="margin-top:0;">Commission rates</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="y1">Year 1 (basis points)</label></th>
						<td><input type="number" id="y1" name="commission_rate_y1_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( (int) $s['commission_rate_y1_bp'] ); ?>" class="regular-text" style="max-width:140px;"> <span style="color:#666;font-size:13px;">2000 = 20.00%</span></td>
					</tr>
					<tr>
						<th><label for="y2">Year 2+ (basis points)</label></th>
						<td><input type="number" id="y2" name="commission_rate_y2plus_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( (int) $s['commission_rate_y2plus_bp'] ); ?>" class="regular-text" style="max-width:140px;"> <span style="color:#666;font-size:13px;">1000 = 10.00%</span></td>
					</tr>
					<tr>
						<th><label for="cur">Commission currency</label></th>
						<td>
							<select id="cur" name="commission_currency" class="regular-text" style="max-width:280px;">
								<?php foreach ( \AsterisAffiliates\Core\Currencies::all() as $code => $label ) : ?>
									<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $code, strtoupper( (string) $s['commission_currency'] ) ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">Currency commissions are denominated in. Default USD. Does NOT auto-detect from WooCommerce — pick your store's currency explicitly. Existing commission rows keep their saved currency on display.</p>
						</td>
					</tr>
				</table>

				</div><!-- /aff-tab-commissions -->

				<div id="aff-tab-attribution" class="aff-tab-section">
				<h2 style="margin-top:0;">Attribution</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="cookie">Cookie window (days)</label></th>
						<td><input type="number" id="cookie" name="cookie_days" min="1" max="365" value="<?php echo esc_attr( (int) $s['cookie_days'] ); ?>" class="regular-text" style="max-width:120px;"> <span style="color:#666;font-size:13px;">Industry standard is 60 days</span></td>
					</tr>
					<tr>
						<th>Attribution priority</th>
						<td>
							<label><input type="radio" name="attribution_priority" value="coupon_first" <?php checked( 'coupon_first', $s['attribution_priority'] ); ?>> Coupon first (recommended) — coupon code beats link click if both exist</label><br>
							<label><input type="radio" name="attribution_priority" value="link_first" <?php checked( 'link_first', $s['attribution_priority'] ); ?>> Link first — last-click wins</label>
						</td>
					</tr>
					<tr>
						<th>Self-referral block</th>
						<td><label><input type="checkbox" name="self_referral_block" value="1" <?php checked( 1, (int) $s['self_referral_block'] ); ?>> Block affiliates from earning commission on their own orders</label></td>
					</tr>
				</table>

				</div><!-- /aff-tab-attribution -->

				<div id="aff-tab-payouts" class="aff-tab-section">
				<h2 style="margin-top:0;">Refund window</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="rwin">Refund window (days)</label></th>
						<td><input type="number" id="rwin" name="refund_window_days" min="0" max="90" value="<?php echo esc_attr( (int) $s['refund_window_days'] ); ?>" class="regular-text" style="max-width:120px;"> <span style="color:#666;font-size:13px;">Commissions stay <em>pending</em> until this many days after order. 0 = instant approval.</span></td>
					</tr>
				</table>

				<h2>Payouts</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="pmin">Minimum payout ($)</label></th>
						<td>$<input type="number" id="pmin" name="payout_min_dollars" min="0" max="10000" step="0.01" value="<?php echo esc_attr( number_format( (int) $s['payout_min_cents'] / 100, 2, '.', '' ) ); ?>" class="regular-text" style="max-width:140px;"> <span style="color:#666;font-size:13px;">Approved balance must exceed this for monthly payout to fire</span></td>
					</tr>
					<tr>
						<th><label for="pday">Payout day of month</label></th>
						<td><input type="number" id="pday" name="payout_day_of_month" min="1" max="28" value="<?php echo esc_attr( (int) $s['payout_day_of_month'] ); ?>" class="regular-text" style="max-width:120px;"> <span style="color:#666;font-size:13px;">1 = 1st of every month. Max 28 to avoid month-length edge cases.</span></td>
					</tr>
				</table>

				</div><!-- /aff-tab-payouts -->

				<div id="aff-tab-stripe" class="aff-tab-section">
				<h2 style="margin-top:0;">Stripe Connect (for auto-payouts)</h2>
				<?php
				$stripe_configured = \AsterisAffiliates\Payouts\Stripe_Connect::is_configured();
				$mu_file_exists    = \AsterisAffiliates\Core\Util\Secret_Writer::file_exists();
				$resolved_source   = '';
				$resolved_secret   = '';
				if ( defined( 'ASTERIS_AFFILIATES_STRIPE_SECRET' ) && ASTERIS_AFFILIATES_STRIPE_SECRET !== '' ) {
					$resolved_secret = (string) ASTERIS_AFFILIATES_STRIPE_SECRET;
					$resolved_source = $mu_file_exists
						? 'auto-generated mu-plugin (encrypted location)'
						: 'wp-config.php constant';
				} elseif ( $s['stripe_secret_key'] !== '' ) {
					$resolved_secret = (string) $s['stripe_secret_key'];
					$resolved_source = 'wp_options (legacy — re-save to upgrade to mu-plugin)';
				} elseif ( $stripe_configured ) {
					$resolved_secret = \AsterisAffiliates\Payouts\Stripe_Connect::resolve_secret_key();
					$resolved_source = 'WC Stripe Gateway (auto-detected)';
				}
				$masked = \AsterisAffiliates\Core\Util\Secret_Writer::mask( $resolved_secret );
				?>
				<p style="background:<?php echo $stripe_configured ? '#ecfdf5' : '#fef2f2'; ?>;border-left:3px solid <?php echo $stripe_configured ? '#06D6A0' : '#dc2626'; ?>;padding:10px 14px;border-radius:6px;margin:0 0 14px;color:<?php echo $stripe_configured ? '#065f46' : '#991b1b'; ?>;">
					<?php if ( $stripe_configured ) : ?>
						✓ <strong>Stripe is connected.</strong> Auto-payouts via Stripe Connect are active. Source: <strong><?php echo esc_html( $resolved_source ); ?></strong>. Key: <code style="background:rgba(0,0,0,0.05);padding:2px 6px;border-radius:3px;font-family:ui-monospace,monospace;"><?php echo esc_html( $masked ); ?></code>
					<?php else : ?>
						⚠ <strong>Stripe is NOT connected.</strong> Paste your key below — we'll save it securely in a mu-plugin file (NOT the database). Auto-payouts will activate immediately.
					<?php endif; ?>
				</p>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="stripe">Stripe secret key</label></th>
						<td>
							<input type="password" id="stripe" name="stripe_secret_key" value="" placeholder="<?php echo esc_attr( $resolved_secret !== '' ? 'Saved — paste a new key to rotate' : 'sk_live_xxxxxxxxxxxxxxxxxxxxxxxx' ); ?>" class="regular-text" style="width:100%;max-width:480px;font-family:ui-monospace,monospace;" autocomplete="off">
							<p class="description">Find it at <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener" style="color:#06D6A0;">dashboard.stripe.com/apikeys</a> → "Secret key". Starts with <code>sk_live_</code> (production) or <code>sk_test_</code> (testing).</p>
							<p class="description"><strong>Where we store it (in order of preference):</strong>
								<ol style="margin:6px 0 0 20px;font-size:13px;">
									<li><strong>wp-content/mu-plugins/asteris-affiliates-secrets.php</strong> — auto-generated when you paste a key here. Not in DB. Not web-accessible. Survives plugin updates. <em>Recommended for everyone.</em></li>
									<li><code>wp-config.php</code> constant — manual, but works on hosts where mu-plugins is locked.</li>
									<li>WC Stripe Gateway's saved key — auto-detected if installed.</li>
								</ol>
							</p>
							<?php if ( $mu_file_exists ) : ?>
								<p class="description" style="color:#059669;">✓ Secret stored in mu-plugin file (<code>wp-content/mu-plugins/asteris-affiliates-secrets.php</code>). Leave the field above blank to keep current; paste a new key to rotate.</p>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<h3 style="margin-top:24px;">Webhook (for failure detection)</h3>
				<p style="color:#666;font-size:13px;margin:0 0 10px;">Without this, a transfer that fails AT Stripe (after our sync API call succeeded — account closed, frozen, insufficient platform balance) won't propagate back. Affiliate would think they got paid when they didn't.</p>
				<p style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:10px 14px;font-size:13px;">
					<strong>Endpoint URL</strong> (paste into Stripe Dashboard → Developers → Webhooks → "Add endpoint"):<br>
					<code style="background:#fff;padding:4px 8px;border-radius:4px;display:inline-block;margin-top:6px;font-family:ui-monospace,monospace;font-size:12px;word-break:break-all;"><?php echo esc_html( rest_url( 'asteris-affiliates/v1/stripe-webhook' ) ); ?></code><br>
					<strong style="margin-top:8px;display:inline-block;">Events to subscribe</strong>: <code style="font-size:11px;">transfer.failed</code>, <code style="font-size:11px;">transfer.reversed</code>, <code style="font-size:11px;">account.updated</code>
				</p>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="whsec">Signing secret</label></th>
						<td>
							<?php $whsec_present = (string) $s['stripe_webhook_secret'] !== '' || ( defined( 'ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET' ) && ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET !== '' ); ?>
							<input type="password" id="whsec" name="stripe_webhook_secret" value="" placeholder="<?php echo esc_attr( $whsec_present ? 'Saved — paste a new secret to rotate' : 'whsec_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' ); ?>" class="regular-text" style="width:100%;max-width:480px;font-family:ui-monospace,monospace;" autocomplete="off">
							<p class="description">In Stripe Dashboard → Webhooks → click your endpoint → "Signing secret" → reveal & copy. Starts with <code>whsec_</code>. We store this via the same mu-plugin trick as the secret key (NOT in DB).</p>
							<?php if ( $whsec_present ) : ?>
								<p class="description" style="color:#059669;">✓ Webhook secret on file. Leave blank to keep current; paste a new value to rotate.</p>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				</div><!-- /aff-tab-stripe -->

				<div id="aff-tab-fraud" class="aff-tab-section">
				<h2 style="margin-top:0;">Anti-fraud</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="susp">Auto-suspend threshold (%)</label></th>
						<td><input type="number" id="susp" name="auto_suspend_refund_rate_pct" min="0" max="100" value="<?php echo esc_attr( (int) $s['auto_suspend_refund_rate_pct'] ); ?>" class="regular-text" style="max-width:120px;"> <span style="color:#666;font-size:13px;">Auto-suspend affiliates whose 30-day refund rate exceeds this. 20% is a sensible default.</span></td>
					</tr>
					<tr>
						<th>Bot blocking</th>
						<td>
							<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="block_bot_user_agents" value="1" <?php checked( 1, (int) $s['block_bot_user_agents'] ); ?>> Reject clicks from known bot user-agents</label>
							<label><input type="checkbox" name="block_ip_bursts" value="1" <?php checked( 1, (int) $s['block_ip_bursts'] ); ?>> Reject burst-click attempts (>20 clicks/min from same IP)</label>
						</td>
					</tr>
				</table>

				</div><!-- /aff-tab-fraud -->

				<div id="aff-tab-signup" class="aff-tab-section">
				<h2 style="margin-top:0;">Notifications</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th>Admin notifications</th>
						<td><label><input type="checkbox" name="send_admin_notifications" value="1" <?php checked( 1, (int) $s['send_admin_notifications'] ); ?>> Email admin on new applications + auto-suspends + payout-batch failures</label></td>
					</tr>
					<tr>
						<th><label for="aem">Admin email</label></th>
						<td><input type="email" id="aem" name="admin_notification_email" value="<?php echo esc_attr( (string) $s['admin_notification_email'] ); ?>" placeholder="<?php echo esc_attr( (string) get_option( 'admin_email' ) ); ?>" class="regular-text"> <span style="color:#666;font-size:13px;">Blank = WP admin email (<?php echo esc_html( (string) get_option( 'admin_email' ) ); ?>)</span></td>
					</tr>
				</table>

				<h2>Affiliate signup</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th>Approval required?</th>
						<td><label><input type="checkbox" name="signup_requires_approval" value="1" <?php checked( 1, (int) $s['signup_requires_approval'] ); ?>> New signups land as <em>pending</em> until you approve (recommended). Uncheck for auto-approve.</label></td>
					</tr>
					<tr>
						<th><label for="terms">Terms URL</label></th>
						<td><input type="url" id="terms" name="signup_terms_url" value="<?php echo esc_attr( (string) $s['signup_terms_url'] ); ?>" placeholder="https://yoursite.com/affiliate-terms" class="regular-text"></td>
					</tr>
				</table>

				<h2>Signup form appearance</h2>
				<p style="color:#666;font-size:13px;margin:0 0 10px;">Controls the <code>[aff_signup]</code> shortcode. Per-page overrides supported, e.g.<br>
					<code>[aff_signup button_color="#FF5B3F" button_label="Join now" heading="Become a partner"]</code></p>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="btnc">Button colour</label></th>
						<td>
							<input type="color" id="btnc" name="signup_button_color" value="<?php echo esc_attr( (string) $s['signup_button_color'] ); ?>" style="width:60px;height:38px;vertical-align:middle;border:1px solid #d1d5db;border-radius:6px;">
							<input type="text" name="signup_button_color_text" value="<?php echo esc_attr( (string) $s['signup_button_color'] ); ?>" pattern="^#[0-9a-fA-F]{3,8}$" placeholder="#06D6A0" class="regular-text" style="max-width:140px;vertical-align:middle;" onchange="document.getElementById('btnc').value=this.value;">
							<span style="color:#666;font-size:13px;margin-left:10px;">Default: <code style="background:#f3f4f6;padding:2px 6px;border-radius:3px;color:#06D6A0;">#06D6A0</code> (Asteris Affiliates teal)</span>
						</td>
					</tr>
					<tr>
						<th><label for="btnl">Button label</label></th>
						<td><input type="text" id="btnl" name="signup_button_label" value="<?php echo esc_attr( (string) $s['signup_button_label'] ); ?>" class="regular-text" style="width:380px;"></td>
					</tr>
					<tr>
						<th><label for="head">Form heading</label></th>
						<td><input type="text" id="head" name="signup_heading" value="<?php echo esc_attr( (string) $s['signup_heading'] ); ?>" class="regular-text" style="width:380px;"></td>
					</tr>
					<tr>
						<th><label for="intro">Intro text</label></th>
						<td><textarea id="intro" name="signup_intro" rows="2" class="large-text" style="max-width:560px;"><?php echo esc_textarea( (string) $s['signup_intro'] ); ?></textarea></td>
					</tr>
					<tr>
						<th>Optional fields</th>
						<td>
							<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="signup_show_first_last" value="1" <?php checked( 1, (int) $s['signup_show_first_last'] ); ?>> Show First + Last name</label>
							<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="signup_show_country" value="1" <?php checked( 1, (int) $s['signup_show_country'] ); ?>> Show Country (ISO-2)</label>
							<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="signup_show_audience" value="1" <?php checked( 1, (int) $s['signup_show_audience'] ); ?>> Show Audience size dropdown</label>
							<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="signup_show_promotion" value="1" <?php checked( 1, (int) $s['signup_show_promotion'] ); ?>> Show "How will you promote?" textarea</label>
							<label style="display:block;color:#666;font-size:13px;padding-left:18px;"><input type="checkbox" name="signup_require_promotion" value="1" <?php checked( 1, (int) $s['signup_require_promotion'] ); ?>> Require the promotion field (only matters if shown)</label>
						</td>
					</tr>
				</table>

				<details style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:12px 16px;margin:14px 0;">
					<summary style="cursor:pointer;font-weight:600;color:#374151;font-size:13px;">All shortcode attributes</summary>
					<pre style="margin:10px 0 0;font-size:11px;color:#374151;background:#fff;padding:12px;border-radius:4px;">[aff_signup
  button_color="#06D6A0"
  button_label="Apply now →"
  heading="Become an affiliate"
  intro="Earn commission on every customer you refer."
  show_first_last="1"
  show_country="1"
  show_audience="1"
  show_promotion="1"
  require_promotion="1"
]</pre>
					<p style="margin:8px 0 0;color:#666;font-size:12px;">Any attribute you omit falls back to the defaults above. Use <code>"0"</code> to hide a field.</p>
				</details>

				</div><!-- /aff-tab-signup -->

				<!-- ── PRO FEATURES tab ──────────────────────────────────────────── -->
				<div id="aff-tab-pro" class="aff-tab-section">
					<h2 style="margin-top:0;">✨ Pro features</h2>
					<p style="color:#666;">Toggles for Pro-only features. Without a valid Pro licence these flags are stored but their features stay gated (see ✨ Free vs Pro).</p>
					<table class="form-table" role="presentation">
						<tr>
							<th><label for="mlm_enabled">MLM / Two-tier referrals</label></th>
							<td>
								<label><input type="checkbox" id="mlm_enabled" name="mlm_enabled" value="1" <?php checked( (int) ( $s['mlm_enabled'] ?? 0 ) ); ?>>
									Enable parent_affiliate_id-based tier 2 commissions</label>
								<p class="description">Each affiliate can have a parent — set on the Affiliate Detail page. Parent earns tier-2 rate (default 5%) on every commission their child generates.</p>
							</td>
						</tr>
					</table>
				</div><!-- /aff-tab-pro -->

				<!-- ── PAYPAL tab ─────────────────────────────────────────────────── -->
				<div id="aff-tab-paypal" class="aff-tab-section">
					<h2 style="margin-top:0;">🅿️ PayPal Payouts API</h2>
					<p style="color:#666;">Configured PayPal will auto-send payouts when batch cron runs. Without credentials, PayPal-method payouts stay as manual mark-paid.</p>
					<table class="form-table" role="presentation">
						<tr>
							<th><label for="paypal_mode">Mode</label></th>
							<td>
								<select name="paypal_mode" id="paypal_mode">
									<option value="sandbox" <?php selected( ( $s['paypal_mode'] ?? 'sandbox' ), 'sandbox' ); ?>>Sandbox (testing)</option>
									<option value="live"    <?php selected( ( $s['paypal_mode'] ?? 'sandbox' ), 'live' ); ?>>Live (real money)</option>
								</select>
							</td>
						</tr>
						<tr>
							<th><label for="paypal_client_id">Client ID</label></th>
							<td><input type="text" id="paypal_client_id" name="paypal_client_id" value="<?php echo esc_attr( (string) ( $s['paypal_client_id'] ?? '' ) ); ?>" class="regular-text">
								<p class="description">From developer.paypal.com → My Apps & Credentials.</p></td>
						</tr>
						<tr>
							<th><label for="paypal_secret">Secret</label></th>
							<td><input type="password" id="paypal_secret" name="paypal_secret" value="<?php echo esc_attr( (string) ( $s['paypal_secret'] ?? '' ) ); ?>" class="regular-text" autocomplete="off">
								<p class="description">Stored encrypted via WP option. Leave blank to clear.</p></td>
						</tr>
					</table>
				</div><!-- /aff-tab-paypal -->

				<!-- ── CLOUD ASSIST tab ───────────────────────────────────────────── -->
				<div id="aff-tab-cloud" class="aff-tab-section">
					<h2 style="margin-top:0;">☁️ Cloud-assist fraud (Pro · opt-in)</h2>
					<p style="color:#666;">Optional anonymous cross-site signal sharing with pay.asteriscommerce.com. Hashes only — NO PII (no IPs / emails / UAs) leave your site. Hashes are salted with your site's signing secret so they're unique per site.</p>
					<table class="form-table" role="presentation">
						<tr>
							<th><label for="cloud_fraud_enabled">Enable cloud-assist</label></th>
							<td>
								<label><input type="checkbox" id="cloud_fraud_enabled" name="cloud_fraud_enabled" value="1" <?php checked( (int) ( $s['cloud_fraud_enabled'] ?? 0 ) ); ?>>
									Sync hashed fraud signals daily</label>
								<p class="description">Off by default. When on, you contribute to + receive cross-site fraud match data. Disable any time. See <a href="https://asterisaffiliates.com/docs/cloud-assist-fraud" target="_blank" rel="noopener">privacy details</a>.</p>
							</td>
						</tr>
					</table>
				</div><!-- /aff-tab-cloud -->

				<p style="margin-top:24px;">
					<button type="submit" class="button button-primary button-large" style="background:#06D6A0;border-color:#06D6A0;">Save settings</button>
					<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_save_settings&reset=1' ), 'asteris_aff_save_settings' ) ); ?>" class="button" style="margin-left:8px;" onclick="return confirm('Reset all Asteris Affiliates settings to defaults?');">↻ Reset to defaults</a>
				</p>
			</form>
		</div>
		<?php
	}

	public static function handle_save(): void {
		check_admin_referer( 'asteris_aff_save_settings' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		if ( isset( $_GET['reset'] ) ) {
			Settings::reset_to_defaults();
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-settings&flash=reset' ) );
			exit;
		}

		$changes = [
			'commission_rate_y1_bp'        => isset( $_POST['commission_rate_y1_bp'] ) ? max( 0, min( 10000, (int) $_POST['commission_rate_y1_bp'] ) ) : 2000,
			'commission_rate_y2plus_bp'    => isset( $_POST['commission_rate_y2plus_bp'] ) ? max( 0, min( 10000, (int) $_POST['commission_rate_y2plus_bp'] ) ) : 1000,
			'commission_currency'          => self::sanitise_currency( isset( $_POST['commission_currency'] ) ? (string) wp_unslash( $_POST['commission_currency'] ) : 'USD' ),
			'cookie_days'                  => isset( $_POST['cookie_days'] ) ? max( 1, min( 365, (int) $_POST['cookie_days'] ) ) : 60,
			'attribution_priority'         => ( isset( $_POST['attribution_priority'] ) && $_POST['attribution_priority'] === 'link_first' ) ? 'link_first' : 'coupon_first',
			'self_referral_block'          => isset( $_POST['self_referral_block'] ) ? 1 : 0,
			'refund_window_days'           => isset( $_POST['refund_window_days'] ) ? max( 0, min( 90, (int) $_POST['refund_window_days'] ) ) : 30,
			'payout_min_cents'             => isset( $_POST['payout_min_dollars'] ) ? max( 0, (int) round( ( (float) $_POST['payout_min_dollars'] ) * 100 ) ) : 10000,
			'payout_day_of_month'          => isset( $_POST['payout_day_of_month'] ) ? max( 1, min( 28, (int) $_POST['payout_day_of_month'] ) ) : 1,
			'auto_suspend_refund_rate_pct' => isset( $_POST['auto_suspend_refund_rate_pct'] ) ? max( 0, min( 100, (int) $_POST['auto_suspend_refund_rate_pct'] ) ) : 20,
			'block_bot_user_agents'        => isset( $_POST['block_bot_user_agents'] ) ? 1 : 0,
			'block_ip_bursts'              => isset( $_POST['block_ip_bursts'] ) ? 1 : 0,
			'send_admin_notifications'     => isset( $_POST['send_admin_notifications'] ) ? 1 : 0,
			'admin_notification_email'     => isset( $_POST['admin_notification_email'] ) ? sanitize_email( wp_unslash( $_POST['admin_notification_email'] ) ) : '',
			'signup_requires_approval'     => isset( $_POST['signup_requires_approval'] ) ? 1 : 0,
			'signup_terms_url'             => isset( $_POST['signup_terms_url'] ) ? esc_url_raw( wp_unslash( $_POST['signup_terms_url'] ) ) : '',

			// Signup form appearance — prefer the text input over the colour
			// picker if both are present (lets people paste exact hex).
			'signup_button_color'          => self::sanitise_hex_colour(
				isset( $_POST['signup_button_color_text'] ) && (string) $_POST['signup_button_color_text'] !== ''
					? (string) wp_unslash( $_POST['signup_button_color_text'] )
					: (string) ( $_POST['signup_button_color'] ?? '#06D6A0' )
			),
			'signup_button_label'          => isset( $_POST['signup_button_label'] ) ? sanitize_text_field( wp_unslash( $_POST['signup_button_label'] ) ) : 'Apply to be an affiliate →',
			'signup_heading'               => isset( $_POST['signup_heading'] ) ? sanitize_text_field( wp_unslash( $_POST['signup_heading'] ) ) : 'Become an affiliate',
			'signup_intro'                 => isset( $_POST['signup_intro'] ) ? sanitize_text_field( wp_unslash( $_POST['signup_intro'] ) ) : '',
			'signup_show_first_last'       => isset( $_POST['signup_show_first_last'] ) ? 1 : 0,
			'signup_show_country'          => isset( $_POST['signup_show_country'] ) ? 1 : 0,
			'signup_show_audience'         => isset( $_POST['signup_show_audience'] ) ? 1 : 0,
			'signup_show_promotion'        => isset( $_POST['signup_show_promotion'] ) ? 1 : 0,
			'signup_require_promotion'     => isset( $_POST['signup_require_promotion'] ) ? 1 : 0,

			// v1.1.3 — Pro tab + PayPal + Cloud assist
			'mlm_enabled'         => isset( $_POST['mlm_enabled'] ) ? 1 : 0,
			'cloud_fraud_enabled' => isset( $_POST['cloud_fraud_enabled'] ) ? 1 : 0,
			'paypal_mode'         => ( isset( $_POST['paypal_mode'] ) && $_POST['paypal_mode'] === 'live' ) ? 'live' : 'sandbox',
			'paypal_client_id'    => isset( $_POST['paypal_client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['paypal_client_id'] ) ) : '',
			'paypal_secret'       => isset( $_POST['paypal_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['paypal_secret'] ) ) : '',
		];

		Settings::update( $changes );

		// Handle Stripe secret SEPARATELY — writes to mu-plugin, not DB.
		// Empty input = "keep current" (so reloading the page without retyping
		// doesn't wipe a previously-saved key).
		$stripe_raw = isset( $_POST['stripe_secret_key'] ) ? trim( (string) wp_unslash( $_POST['stripe_secret_key'] ) ) : '';
		if ( $stripe_raw !== '' ) {
			// Live-validate against Stripe's /balance endpoint BEFORE saving.
			// Catches typos + revoked keys + sk_live vs sk_test mixups
			// immediately, instead of failing silently 3 days later when the
			// payout cron fires.
			$validation = \AsterisAffiliates\Payouts\Stripe_Connect::validate_key( $stripe_raw );
			if ( is_wp_error( $validation ) ) {
				wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-settings&flash=stripe_invalid&extra=' . urlencode( $validation->get_error_message() ) ) );
				exit;
			}
			$res = \AsterisAffiliates\Core\Util\Secret_Writer::write(
				'ASTERIS_AFFILIATES_STRIPE_SECRET',
				$stripe_raw
			);
			if ( is_wp_error( $res ) ) {
				// Fall back to DB option so the key isn't lost — warn user.
				Settings::update( [ 'stripe_secret_key' => $stripe_raw ] );
				wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-settings&flash=stripe_mu_failed&extra=' . urlencode( $res->get_error_message() ) ) );
				exit;
			}
			// Success — nuke any legacy DB-stored key so it doesn't shadow the mu-plugin
			Settings::update( [ 'stripe_secret_key' => '' ] );
		}

		// Webhook secret — same mu-plugin treatment as the Stripe key
		$whsec_raw = isset( $_POST['stripe_webhook_secret'] ) ? trim( (string) wp_unslash( $_POST['stripe_webhook_secret'] ) ) : '';
		if ( $whsec_raw !== '' ) {
			if ( ! preg_match( '/^whsec_[A-Za-z0-9]+$/', $whsec_raw ) ) {
				wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-settings&tab=stripe&flash=whsec_bad_format' ) );
				exit;
			}
			$res = \AsterisAffiliates\Core\Util\Secret_Writer::write( 'ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET', $whsec_raw );
			if ( is_wp_error( $res ) ) {
				Settings::update( [ 'stripe_webhook_secret' => $whsec_raw ] );
			} else {
				Settings::update( [ 'stripe_webhook_secret' => '' ] );
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-settings&flash=saved' ) );
		exit;
	}

	/** Accept only currency codes in our supported list; fall back to USD. */
	private static function sanitise_currency( string $input ): string {
		$code = strtoupper( trim( $input ) );
		return \AsterisAffiliates\Core\Currencies::is_valid( $code ) ? $code : 'USD';
	}

	/** Accept #RGB / #RRGGBB only; fall back to teal if malformed. */
	private static function sanitise_hex_colour( string $input ): string {
		$input = trim( $input );
		return preg_match( '/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/', $input ) ? $input : '#06D6A0';
	}
}
