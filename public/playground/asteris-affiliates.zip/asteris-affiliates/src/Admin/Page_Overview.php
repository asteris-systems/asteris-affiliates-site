<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Adapters\EDD_Adapter;
use AsterisAffiliates\Adapters\Surecart_Adapter;
use AsterisAffiliates\Core\Free_Tier;
use AsterisAffiliates\Public_\Portal_Router;

defined( 'ABSPATH' ) || exit;

/**
 * Overview admin page — new-customer setup landing.
 *
 * Closes the v1.1 onboarding gap: a fresh installer had no way to discover
 * (a) what URL to send applicants to, (b) what URL the affiliate portal
 * lives at, (c) that the vanity /go/{handle} pattern even exists, or
 * (d) which cart integrations are actually wired up vs dormant.
 *
 * This page surfaces all four. Auto-detects the signup page by scanning
 * for the [aff_signup] shortcode. Offers a "Create signup page" button
 * if no page has the shortcode yet.
 *
 * v1.2.0.
 */
final class Page_Overview {

	public const SLUG = 'asteris-affiliates-overview';

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_create_signup_page', [ self::class, 'handle_create_signup' ] );
	}

	/**
	 * Find a published post/page containing the [aff_signup] shortcode.
	 * Cached for 5 minutes — admin-only UX, no need to query on every render.
	 *
	 * Returns null if no shortcode page exists.
	 *
	 * @return \WP_Post|null
	 */
	public static function detect_signup_page(): ?\WP_Post {
		$cached = get_transient( 'asteris_aff_signup_page_id' );
		if ( is_numeric( $cached ) ) {
			$post = (int) $cached > 0 ? get_post( (int) $cached ) : null;
			if ( $post instanceof \WP_Post && $post->post_status === 'publish' && has_shortcode( $post->post_content, 'aff_signup' ) ) {
				return $post;
			}
			delete_transient( 'asteris_aff_signup_page_id' );
		}

		global $wpdb;
		$row = $wpdb->get_row(
			"SELECT ID FROM {$wpdb->posts}
			 WHERE post_status = 'publish'
			   AND post_type IN ('page','post')
			   AND post_content LIKE '%[aff_signup%'
			 ORDER BY post_date DESC
			 LIMIT 1"
		);
		$post = $row ? get_post( (int) $row->ID ) : null;
		set_transient( 'asteris_aff_signup_page_id', $post ? (int) $post->ID : -1, 5 * MINUTE_IN_SECONDS );
		return $post;
	}

	/**
	 * Detect WooCommerce, EDD, Surecart presence + licence-tier state.
	 *
	 * Returns three-state status:
	 *   - 'active'        — source plugin present AND (free OR Pro as required)
	 *   - 'requires_pro'  — source plugin present BUT plugin licence is free-tier
	 *                       (the adapter would activate after upgrading)
	 *   - 'no_source'     — source plugin not installed/active
	 *
	 * EDD and Surecart adapters are Pro-gated; WooCommerce works on free.
	 *
	 * @return array<string,array{label:string,state:string,version:?string,notes:string}>
	 */
	public static function detect_integrations(): array {
		$is_pro = Free_Tier::is_pro();
		$out    = [];

		// ── WooCommerce — works on both tiers ──────────────────────────
		$wc_present = class_exists( 'WooCommerce' );
		$out['woocommerce'] = [
			'label'   => 'WooCommerce',
			'state'   => $wc_present ? 'active' : 'no_source',
			'version' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
			'notes'   => $wc_present
				? 'Native integration — hooks WC order events directly. HPOS-compatible.'
				: 'Install + activate WooCommerce to enable affiliate tracking on WC orders.',
		];

		// ── EDD — Pro-gated ───────────────────────────────────────────
		$edd_present = EDD_Adapter::is_available();
		if ( ! $edd_present ) {
			$edd_state = 'no_source';
			$edd_notes = 'Adapter ships in core. Install + activate Easy Digital Downloads, and upgrade to a paid Asteris licence, to track EDD orders.';
		} elseif ( ! $is_pro ) {
			$edd_state = 'requires_pro';
			$edd_notes = 'EDD is installed, but the adapter requires a paid Asteris licence to activate. Upgrade to Starter ($149/yr) or higher to enable.';
		} else {
			$edd_state = 'active';
			$edd_notes = 'Adapter is live — EDD purchase events credit commissions in your wp_aff_commissions table.';
		}
		$out['edd'] = [
			'label'   => 'Easy Digital Downloads',
			'state'   => $edd_state,
			'version' => defined( 'EDD_VERSION' ) ? EDD_VERSION : null,
			'notes'   => $edd_notes,
		];

		// ── Surecart — Pro-gated ──────────────────────────────────────
		$sc_present = Surecart_Adapter::is_available();
		if ( ! $sc_present ) {
			$sc_state = 'no_source';
			$sc_notes = 'Adapter ships in core. Install + activate Surecart, and upgrade to a paid Asteris licence, to track Surecart orders.';
		} elseif ( ! $is_pro ) {
			$sc_state = 'requires_pro';
			$sc_notes = 'Surecart is installed, but the adapter requires a paid Asteris licence to activate. Upgrade to Starter ($149/yr) or higher to enable.';
		} else {
			$sc_state = 'active';
			$sc_notes = 'Adapter is live — Surecart order events credit commissions in your wp_aff_commissions table.';
		}
		$out['surecart'] = [
			'label'   => 'Surecart',
			'state'   => $sc_state,
			'version' => null, // Surecart doesn't expose a stable version constant
			'notes'   => $sc_notes,
		];

		return $out;
	}

	/** Visual properties for an integration state. */
	private static function state_props( string $state ): array {
		switch ( $state ) {
			case 'active':
				return [ 'icon' => '✓', 'icon_bg' => '#06D6A0', 'icon_fg' => '#fff', 'pill' => 'ACTIVE', 'pill_bg' => '#dcfce7', 'pill_fg' => '#166534' ];
			case 'requires_pro':
				return [ 'icon' => '★', 'icon_bg' => '#fef3c7', 'icon_fg' => '#92400e', 'pill' => 'DORMANT (Pro upgrade)', 'pill_bg' => '#fef3c7', 'pill_fg' => '#92400e' ];
			case 'no_source':
			default:
				return [ 'icon' => '○', 'icon_bg' => '#e5e7eb', 'icon_fg' => '#94a3b8', 'pill' => 'DORMANT (not installed)', 'pill_bg' => '#f1f5f9', 'pill_fg' => '#64748b' ];
		}
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$signup_page  = self::detect_signup_page();
		$portal_url   = home_url( Portal_Router::PORTAL_PATH . '/' );
		$rest_url     = rest_url( 'asteris-aff/v1/stats' );
		$vanity_pattern = home_url( '/go/{handle}' );
		$integrations = self::detect_integrations();
		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		?>
		<div class="wrap" style="max-width:1100px;">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<span style="color:#06D6A0;font-size:30px;line-height:1;">★</span>
				Asteris Affiliates · Overview
			</h1>

			<?php if ( $flash === 'signup_created' ) : ?>
				<div class="notice notice-success is-dismissible" style="margin:14px 0 0;"><p><strong>Signup page created.</strong> Edit the page to customise heading, intro and the form fields, then add it to your menu.</p></div>
			<?php elseif ( $flash === 'signup_create_failed' ) : ?>
				<div class="notice notice-error is-dismissible" style="margin:14px 0 0;"><p><strong>Could not create signup page.</strong> Try creating one manually and pasting the <code>[aff_signup]</code> shortcode.</p></div>
			<?php endif; ?>

			<p style="font-size:14px;color:#555;max-width:760px;margin:8px 0 24px;">
				Your live URLs and integration status. Bookmark this page — most customer setup questions answer themselves here.
			</p>

			<!-- URL panel -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:22px 24px;margin-bottom:24px;">
				<h2 style="margin:0 0 16px;font-size:17px;">★ Your live URLs</h2>

				<table style="width:100%;border-collapse:collapse;font-size:14px;">
					<tbody>
						<tr style="border-bottom:1px solid #f1f5f9;">
							<td style="padding:14px 0 14px;vertical-align:top;width:200px;">
								<div style="font-weight:700;color:#0a0a0a;">Signup page</div>
								<div style="color:#666;font-size:12px;margin-top:2px;">Where new affiliates apply</div>
							</td>
							<td style="padding:14px 0;">
								<?php if ( $signup_page ) : ?>
									<a href="<?php echo esc_url( get_permalink( $signup_page ) ); ?>" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;font-family:ui-monospace,monospace;text-decoration:none;">
										<?php echo esc_html( get_permalink( $signup_page ) ); ?> ↗
									</a>
									<div style="margin-top:4px;font-size:12px;color:#666;">
										Auto-detected from <strong><?php echo esc_html( get_the_title( $signup_page ) ); ?></strong> — <a href="<?php echo esc_url( get_edit_post_link( $signup_page->ID ) ); ?>" style="color:#06D6A0;">Edit page →</a>
									</div>
								<?php else : ?>
									<span style="color:#dc2626;font-weight:600;">⚠ Not detected</span>
									<div style="margin-top:6px;font-size:13px;color:#444;">
										Add the <code style="background:#f1f5f9;padding:1px 6px;border-radius:3px;font-size:12px;">[aff_signup]</code> shortcode to any published page or post.
									</div>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px;">
										<?php wp_nonce_field( 'asteris_aff_create_signup_page', '_aff_overview_nonce' ); ?>
										<input type="hidden" name="action" value="asteris_aff_create_signup_page">
										<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;">Create signup page now</button>
									</form>
								<?php endif; ?>
							</td>
						</tr>

						<tr style="border-bottom:1px solid #f1f5f9;">
							<td style="padding:14px 0 14px;vertical-align:top;">
								<div style="font-weight:700;color:#0a0a0a;">Affiliate portal</div>
								<div style="color:#666;font-size:12px;margin-top:2px;">Logged-in stats + payout history</div>
							</td>
							<td style="padding:14px 0;">
								<a href="<?php echo esc_url( $portal_url ); ?>" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;font-family:ui-monospace,monospace;text-decoration:none;">
									<?php echo esc_html( $portal_url ); ?> ↗
								</a>
								<div style="margin-top:4px;font-size:12px;color:#666;">Affiliates log in via standard WordPress login, then redirect here.</div>
							</td>
						</tr>

						<tr style="border-bottom:1px solid #f1f5f9;">
							<td style="padding:14px 0 14px;vertical-align:top;">
								<div style="font-weight:700;color:#0a0a0a;">Vanity URLs</div>
								<div style="color:#666;font-size:12px;margin-top:2px;">Branded per-affiliate landing pages</div>
							</td>
							<td style="padding:14px 0;">
								<code style="background:#f1f5f9;padding:3px 8px;border-radius:3px;font-size:13px;color:#06D6A0;font-weight:600;"><?php echo esc_html( $vanity_pattern ); ?></code>
								<div style="margin-top:6px;font-size:12px;color:#666;">
									Configure per affiliate at <a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-landing' ) ); ?>" style="color:#06D6A0;">Landing Pages →</a>
								</div>
							</td>
						</tr>

						<tr>
							<td style="padding:14px 0 0;vertical-align:top;">
								<div style="font-weight:700;color:#0a0a0a;">REST stats API</div>
								<div style="color:#666;font-size:12px;margin-top:2px;">For headless dashboards</div>
							</td>
							<td style="padding:14px 0 0;">
								<code style="background:#f1f5f9;padding:3px 8px;border-radius:3px;font-size:12.5px;font-family:ui-monospace,monospace;"><?php echo esc_html( $rest_url ); ?></code>
								<div style="margin-top:6px;font-size:12px;color:#666;">Cursor-paginated, transient-cached. Requires authenticated affiliate cookie or API key.</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<!-- Integration detection -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:22px 24px;margin-bottom:24px;">
				<h2 style="margin:0 0 8px;font-size:17px;">★ Detected cart integrations</h2>
				<p style="font-size:13px;color:#666;margin:0 0 16px;">
					All three adapters ship in core. Each activates automatically when its source plugin is installed and active. No configuration needed.
				</p>

				<table style="width:100%;border-collapse:collapse;font-size:14px;">
					<tbody>
						<?php foreach ( $integrations as $key => $info ) : $p = self::state_props( $info['state'] ); ?>
							<tr style="border-bottom:1px solid #f1f5f9;">
								<td style="padding:14px 0;width:48px;text-align:center;vertical-align:top;">
									<span style="display:inline-block;width:28px;height:28px;line-height:28px;border-radius:50%;background:<?php echo esc_attr( $p['icon_bg'] ); ?>;color:<?php echo esc_attr( $p['icon_fg'] ); ?>;font-weight:800;text-align:center;font-size:14px;"><?php echo esc_html( $p['icon'] ); ?></span>
								</td>
								<td style="padding:14px 12px;">
									<div style="font-weight:700;color:#0a0a0a;">
										<?php echo esc_html( $info['label'] ); ?>
										<span style="background:<?php echo esc_attr( $p['pill_bg'] ); ?>;color:<?php echo esc_attr( $p['pill_fg'] ); ?>;font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;margin-left:6px;vertical-align:middle;"><?php echo esc_html( $p['pill'] ); ?></span>
										<?php if ( ! empty( $info['version'] ) ) : ?>
											<span style="color:#94a3b8;font-size:12px;font-weight:500;margin-left:6px;">v<?php echo esc_html( $info['version'] ); ?></span>
										<?php endif; ?>
									</div>
									<div style="color:#666;font-size:12.5px;margin-top:4px;line-height:1.5;">
										<?php echo esc_html( $info['notes'] ); ?>
										<?php if ( $info['state'] === 'requires_pro' ) : ?>
											<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-free-tier' ) ); ?>" style="color:#06D6A0;font-weight:600;margin-left:4px;">See pricing →</a>
										<?php endif; ?>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<p style="margin:14px 0 0;font-size:12.5px;color:#94a3b8;">
					Need a different cart? Implement the <code style="background:#f1f5f9;padding:1px 5px;border-radius:3px;font-size:12px;">Order_Source</code> interface — single PHP file. See the EDD or Surecart adapter as a reference.
				</p>
			</div>

			<!-- Next steps -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:22px 24px;">
				<h2 style="margin:0 0 12px;font-size:17px;">★ Setup checklist</h2>
				<ul style="margin:0;padding-left:18px;font-size:14px;line-height:1.7;">
					<li>
						<?php echo $signup_page ? '✓' : '○'; ?>
						<strong>Signup page published</strong>
						— <?php echo $signup_page ? 'auto-detected, looks good.' : 'create one above or drop [aff_signup] anywhere.'; ?>
					</li>
					<li>○ <strong>Approve your first test affiliate</strong> — <a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-add' ) ); ?>" style="color:#06D6A0;">Add manually →</a></li>
					<li>○ <strong>Configure default commission rate</strong> — <a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-settings&tab=commissions' ) ); ?>" style="color:#06D6A0;">Settings · Commissions →</a></li>
					<li>○ <strong>Pick a payout method</strong> — Stripe Connect (0.25% fee) or PayPal API or bank-CSV — <a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-settings&tab=stripe' ) ); ?>" style="color:#06D6A0;">Settings · Payouts →</a></li>
					<li>○ <strong>Place a test order via <a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-test' ) ); ?>" style="color:#06D6A0;">Test Tracking</a></strong> — confirm attribution + commission flow before going live.</li>
				</ul>
			</div>
		</div>
		<?php
	}

	/**
	 * Create a basic published page with the [aff_signup] shortcode.
	 * Slug: /become-an-affiliate/ (commonly available; falls back if taken).
	 */
	public static function handle_create_signup(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		check_admin_referer( 'asteris_aff_create_signup_page', '_aff_overview_nonce' );

		$post_id = wp_insert_post( [
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'Become an affiliate',
			'post_name'    => 'become-an-affiliate',
			'post_content' => "<!-- wp:shortcode -->\n[aff_signup]\n<!-- /wp:shortcode -->",
		], true );

		delete_transient( 'asteris_aff_signup_page_id' );

		$flash = is_wp_error( $post_id ) ? 'signup_create_failed' : 'signup_created';
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&flash=' . $flash ) );
		exit;
	}
}
