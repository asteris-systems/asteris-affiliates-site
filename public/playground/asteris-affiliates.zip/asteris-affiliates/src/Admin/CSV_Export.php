<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Util\CSV_Exporter;

defined( 'ABSPATH' ) || exit;

/**
 * CSV export endpoints for the three list tables (affiliates / commissions /
 * payouts). Honours the same filters the admin page applies — `status`,
 * `search`, date range.
 *
 * URLs:
 *   admin-post.php?action=asteris_aff_export_affiliates&status=approved
 *   admin-post.php?action=asteris_aff_export_commissions&status=pending&from=…&to=…
 *   admin-post.php?action=asteris_aff_export_payouts&status=paid
 *
 * Nonce + capability checked. Streamed so 100k rows don't OOM.
 */
final class CSV_Export {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_export_affiliates',  [ self::class, 'export_affiliates' ] );
		add_action( 'admin_post_asteris_aff_export_commissions', [ self::class, 'export_commissions' ] );
		add_action( 'admin_post_asteris_aff_export_payouts',     [ self::class, 'export_payouts' ] );
	}

	private static function guard( string $nonce_key ): void {
		check_admin_referer( $nonce_key );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
	}

	public static function export_affiliates(): void {
		self::guard( 'asteris_aff_export_affiliates' );
		global $wpdb;
		$p = $wpdb->prefix;

		$where  = '1=1';
		$params = [];
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$search = isset( $_GET['s'] )      ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		if ( $status !== '' ) {
			$where .= ' AND status = %s';
			$params[] = $status;
		}
		if ( $search !== '' ) {
			$where .= ' AND (display_name LIKE %s OR email LIKE %s)';
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$params[] = $like;
			$params[] = $like;
		}
		$sql = "SELECT id, public_id, status, display_name, email, country_code,
		               commission_rate_y1_bp, commission_rate_y2plus_bp,
		               lifetime_earnings_cents, lifetime_referrals,
		               pending_balance_cents, approved_balance_cents, paid_balance_cents,
		               payout_method, applied_at, approved_at
		        FROM {$p}aff_affiliates WHERE {$where} ORDER BY id DESC LIMIT 100000";
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A );

		$cols = [ 'ID', 'Public ID', 'Status', 'Name', 'Email', 'Country', 'Y1 rate %', 'Y2+ rate %', 'Lifetime earnings $', 'Lifetime referrals', 'Pending $', 'Approved $', 'Paid $', 'Payout method', 'Applied at', 'Approved at' ];
		$gen = ( static function () use ( $rows ) {
			foreach ( $rows as $r ) {
				yield [
					$r['id'], $r['public_id'], $r['status'], $r['display_name'], $r['email'], $r['country_code'],
					number_format( $r['commission_rate_y1_bp'] / 100, 2 ),
					number_format( $r['commission_rate_y2plus_bp'] / 100, 2 ),
					number_format( $r['lifetime_earnings_cents'] / 100, 2 ),
					$r['lifetime_referrals'],
					number_format( $r['pending_balance_cents'] / 100, 2 ),
					number_format( $r['approved_balance_cents'] / 100, 2 ),
					number_format( $r['paid_balance_cents'] / 100, 2 ),
					$r['payout_method'], $r['applied_at'], $r['approved_at'],
				];
			}
		} )();

		CSV_Exporter::stream( 'affiliates-' . gmdate( 'Ymd-His' ) . '.csv', $cols, $gen );
	}

	public static function export_commissions(): void {
		self::guard( 'asteris_aff_export_commissions' );
		global $wpdb;
		$p = $wpdb->prefix;

		$where  = '1=1';
		$params = [];
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$from   = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to     = isset( $_GET['to'] )   ? sanitize_text_field( wp_unslash( $_GET['to'] ) )   : '';
		if ( $status !== '' ) { $where .= ' AND c.status = %s'; $params[] = $status; }
		if ( $from !== '' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) { $where .= ' AND c.created_at >= %s'; $params[] = $from . ' 00:00:00'; }
		if ( $to   !== '' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) )   { $where .= ' AND c.created_at <= %s'; $params[] = $to . ' 23:59:59'; }

		$sql = "SELECT c.id, c.affiliate_id, a.display_name AS aff_name, a.email AS aff_email,
		               c.order_id, c.customer_email, c.attribution_type, c.coupon_code,
		               c.amount_cents, c.currency, c.rate_bp, c.rate_year, c.tier_level,
		               c.status, c.refund_window_ends, c.approved_at, c.paid_at,
		               c.created_at
		        FROM {$p}aff_commissions c
		        LEFT JOIN {$p}aff_affiliates a ON a.id = c.affiliate_id
		        WHERE {$where} ORDER BY c.id DESC LIMIT 100000";
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A );

		$cols = [ 'Commission ID', 'Affiliate ID', 'Affiliate Name', 'Affiliate Email', 'Order ID', 'Customer Email', 'Attribution', 'Coupon', 'Amount $', 'Currency', 'Rate %', 'Year', 'Tier', 'Status', 'Refund window ends', 'Approved at', 'Paid at', 'Created at' ];
		$gen = ( static function () use ( $rows ) {
			foreach ( $rows as $r ) {
				yield [
					$r['id'], $r['affiliate_id'], $r['aff_name'], $r['aff_email'],
					$r['order_id'], $r['customer_email'], $r['attribution_type'], $r['coupon_code'],
					number_format( $r['amount_cents'] / 100, 2 ),
					$r['currency'],
					number_format( $r['rate_bp'] / 100, 2 ),
					$r['rate_year'], $r['tier_level'],
					$r['status'], $r['refund_window_ends'], $r['approved_at'], $r['paid_at'],
					$r['created_at'],
				];
			}
		} )();

		CSV_Exporter::stream( 'commissions-' . gmdate( 'Ymd-His' ) . '.csv', $cols, $gen );
	}

	public static function export_payouts(): void {
		self::guard( 'asteris_aff_export_payouts' );
		global $wpdb;
		$p = $wpdb->prefix;

		$where  = '1=1';
		$params = [];
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		if ( $status !== '' ) { $where .= ' AND p.status = %s'; $params[] = $status; }

		$sql = "SELECT p.id, p.affiliate_id, a.display_name AS aff_name, a.email AS aff_email,
		               p.batch_id, p.payout_method, p.total_cents, p.currency,
		               p.commission_count, p.status, p.stripe_transfer_id, p.bank_reference,
		               p.failure_reason, p.requested_at, p.paid_at
		        FROM {$p}aff_payouts p
		        LEFT JOIN {$p}aff_affiliates a ON a.id = p.affiliate_id
		        WHERE {$where} ORDER BY p.id DESC LIMIT 100000";
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A );

		$cols = [ 'Payout ID', 'Affiliate ID', 'Affiliate Name', 'Affiliate Email', 'Batch ID', 'Method', 'Total $', 'Currency', 'Commission count', 'Status', 'Stripe Transfer ID', 'Bank Reference', 'Failure Reason', 'Requested at', 'Paid at' ];
		$gen = ( static function () use ( $rows ) {
			foreach ( $rows as $r ) {
				yield [
					$r['id'], $r['affiliate_id'], $r['aff_name'], $r['aff_email'],
					$r['batch_id'], $r['payout_method'],
					number_format( $r['total_cents'] / 100, 2 ),
					$r['currency'], $r['commission_count'], $r['status'],
					$r['stripe_transfer_id'], $r['bank_reference'], $r['failure_reason'],
					$r['requested_at'], $r['paid_at'],
				];
			}
		} )();

		CSV_Exporter::stream( 'payouts-' . gmdate( 'Ymd-His' ) . '.csv', $cols, $gen );
	}

	/** Render an "Export CSV" button preserving current ?status/?s/?from/?to query args. */
	public static function button( string $action, array $forward_keys = [ 'status', 's', 'from', 'to' ] ): string {
		$args = [];
		foreach ( $forward_keys as $k ) {
			if ( isset( $_GET[ $k ] ) && $_GET[ $k ] !== '' ) {
				$args[ $k ] = sanitize_text_field( wp_unslash( $_GET[ $k ] ) );
			}
		}
		$args['action'] = $action;
		$url = wp_nonce_url(
			add_query_arg( $args, admin_url( 'admin-post.php' ) ),
			$action
		);
		return '<a href="' . esc_url( $url ) . '" class="button" style="background:#fff;border-color:#06D6A0;color:#06D6A0;font-weight:600;">↓ ' . esc_html__( 'Export CSV', 'asteris-affiliates' ) . '</a>';
	}
}
