<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\AI_Settings;
use AsterisShared\AI\Router;

defined( 'ABSPATH' ) || exit;

/**
 * Admin page for the BYO AI keys.
 *
 *  - OpenAI API key (masked when stored)
 *  - Anthropic API key (masked when stored)
 *  - Default model dropdown
 *  - Per-vendor "Test key" button (AJAX → Router::test_key)
 *
 * Keys are stored encrypted via AI_Settings; this page never echoes plaintext.
 * Save handler accepts a special sentinel "•••KEEP•••" placeholder so customers
 * can edit other fields without re-pasting their key.
 */
final class Page_AI_Settings {

	public const SLUG = 'asteris-affiliates-ai-settings';
	private const KEEP_SENTINEL = '•••KEEP•••';

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_ai_save', [ self::class, 'handle_save' ] );
		add_action( 'wp_ajax_asteris_aff_ai_test_key', [ self::class, 'handle_test_ajax' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$openai_masked    = AI_Settings::masked( AI_Settings::OPT_OPENAI_KEY );
		$anthropic_masked = AI_Settings::masked( AI_Settings::OPT_ANTHROPIC_KEY );
		$default_model    = AI_Settings::default_model();
		$flash            = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		?>
		<div class="wrap" style="max-width:760px;">
			<h1><?php esc_html_e( 'AI Settings', 'asteris-affiliates' ); ?></h1>
			<p style="color:#444;font-size:13.5px;line-height:1.55;">
				<?php esc_html_e( 'Asteris Affiliates uses your own OpenAI or Anthropic API key for AI features (swipe copy variants, future AI tools). We don\'t proxy through Asteris servers — your key calls the vendor directly, you pay the vendor directly. No quotas, no metering, no surprise bills from us.', 'asteris-affiliates' ); ?>
			</p>

			<?php self::render_flash( $flash ); ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
				style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:24px 28px;margin-top:18px;">
				<?php wp_nonce_field( 'asteris_aff_ai_save' ); ?>
				<input type="hidden" name="action" value="asteris_aff_ai_save">

				<!-- Anthropic -->
				<div style="margin-bottom:26px;padding-bottom:22px;border-bottom:1px solid #f3f4f6;">
					<label style="display:block;font-weight:600;margin-bottom:6px;">
						<?php esc_html_e( 'Anthropic API key (Claude models)', 'asteris-affiliates' ); ?>
					</label>
					<p style="margin:0 0 8px;color:#666;font-size:12px;">
						<?php
						printf(
							/* translators: 1: opening anchor 2: closing anchor */
							esc_html__( 'Get yours at %1$sconsole.anthropic.com%2$s. Used by every claude-* model.', 'asteris-affiliates' ),
							'<a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener">',
							'</a>'
						);
						?>
					</p>
					<div style="display:flex;gap:8px;align-items:center;">
						<input type="password" name="anthropic_key" id="aff-anthropic-key"
							value="<?php echo $anthropic_masked !== '' ? esc_attr( self::KEEP_SENTINEL ) : ''; ?>"
							placeholder="<?php echo $anthropic_masked !== '' ? esc_attr( $anthropic_masked ) : 'sk-ant-…'; ?>"
							autocomplete="off" spellcheck="false"
							style="flex:1;font-family:ui-monospace,monospace;font-size:13px;">
						<button type="button" class="button" data-test-key="anthropic">
							<?php esc_html_e( 'Test key', 'asteris-affiliates' ); ?>
						</button>
					</div>
					<div class="aff-key-test-result" data-vendor="anthropic" style="font-size:12px;margin-top:6px;min-height:18px;"></div>
				</div>

				<!-- OpenAI -->
				<div style="margin-bottom:26px;padding-bottom:22px;border-bottom:1px solid #f3f4f6;">
					<label style="display:block;font-weight:600;margin-bottom:6px;">
						<?php esc_html_e( 'OpenAI API key (GPT models)', 'asteris-affiliates' ); ?>
					</label>
					<p style="margin:0 0 8px;color:#666;font-size:12px;">
						<?php
						printf(
							/* translators: 1: opening anchor 2: closing anchor */
							esc_html__( 'Get yours at %1$splatform.openai.com%2$s. Used by every gpt-* or o-series model.', 'asteris-affiliates' ),
							'<a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">',
							'</a>'
						);
						?>
					</p>
					<div style="display:flex;gap:8px;align-items:center;">
						<input type="password" name="openai_key" id="aff-openai-key"
							value="<?php echo $openai_masked !== '' ? esc_attr( self::KEEP_SENTINEL ) : ''; ?>"
							placeholder="<?php echo $openai_masked !== '' ? esc_attr( $openai_masked ) : 'sk-…'; ?>"
							autocomplete="off" spellcheck="false"
							style="flex:1;font-family:ui-monospace,monospace;font-size:13px;">
						<button type="button" class="button" data-test-key="openai">
							<?php esc_html_e( 'Test key', 'asteris-affiliates' ); ?>
						</button>
					</div>
					<div class="aff-key-test-result" data-vendor="openai" style="font-size:12px;margin-top:6px;min-height:18px;"></div>
				</div>

				<!-- Default model -->
				<div style="margin-bottom:24px;">
					<label style="display:block;font-weight:600;margin-bottom:6px;">
						<?php esc_html_e( 'Default model', 'asteris-affiliates' ); ?>
					</label>
					<select name="default_model" style="min-width:380px;">
						<?php foreach ( AI_Settings::model_choices() as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $default_model, $val ); ?>>
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p style="margin:6px 0 0;color:#666;font-size:12px;">
						<?php esc_html_e( 'Used when a feature (e.g. swipe copy AI variant) doesn\'t specify a model. Make sure the matching vendor key is set above.', 'asteris-affiliates' ); ?>
					</p>
				</div>

				<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;">
					<?php esc_html_e( 'Save AI settings', 'asteris-affiliates' ); ?>
				</button>
			</form>

			<p style="color:#666;font-size:12px;margin-top:18px;line-height:1.5;">
				<?php esc_html_e( 'Keys are encrypted at rest (AES-256-CBC) using your site\'s AUTH_SALT. Never logged, never sent to Asteris, never included in debug exports.', 'asteris-affiliates' ); ?>
			</p>
		</div>

		<script>
		( function () {
			'use strict';
			var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			var nonce   = <?php echo wp_json_encode( wp_create_nonce( 'asteris_aff_ai_test_key' ) ); ?>;
			var KEEP    = <?php echo wp_json_encode( self::KEEP_SENTINEL ); ?>;

			document.querySelectorAll( '[data-test-key]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					var vendor = btn.dataset.testKey;
					var input  = document.getElementById( vendor === 'openai' ? 'aff-openai-key' : 'aff-anthropic-key' );
					var result = document.querySelector( '.aff-key-test-result[data-vendor="' + vendor + '"]' );
					var raw    = ( input.value || '' ).trim();
					if ( raw === '' ) {
						result.textContent = '⚠ Paste a key first.';
						result.style.color = '#9a3412';
						return;
					}
					// "Use stored key" means: send empty so the server reads the
					// encrypted-at-rest copy.
					var keyParam = raw === KEEP ? '' : raw;
					var original = btn.textContent;
					btn.disabled = true;
					btn.textContent = 'Testing…';
					result.textContent = '';

					var body = new URLSearchParams();
					body.set( 'action', 'asteris_aff_ai_test_key' );
					body.set( '_nonce', nonce );
					body.set( 'vendor', vendor );
					body.set( 'key',    keyParam );

					fetch( ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
						.then( function ( r ) { return r.json(); } )
						.then( function ( res ) {
							if ( res && res.success ) {
								result.textContent = '✓ Key works.';
								result.style.color = '#059669';
							} else {
								var msg = ( res && res.data && res.data.message ) || 'Unknown error';
								result.textContent = '✗ ' + msg;
								result.style.color = '#dc2626';
							}
						} )
						.catch( function ( e ) {
							result.textContent = '✗ Network error: ' + e.message;
							result.style.color = '#dc2626';
						} )
						.finally( function () {
							btn.disabled = false;
							btn.textContent = original;
						} );
				} );
			} );
		} )();
		</script>
		<?php
	}

	public static function handle_save(): void {
		check_admin_referer( 'asteris_aff_ai_save' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$anthropic = isset( $_POST['anthropic_key'] ) ? trim( (string) wp_unslash( $_POST['anthropic_key'] ) ) : '';
		$openai    = isset( $_POST['openai_key'] )    ? trim( (string) wp_unslash( $_POST['openai_key'] ) )    : '';
		$model     = isset( $_POST['default_model'] ) ? sanitize_text_field( wp_unslash( $_POST['default_model'] ) ) : '';

		// Sentinel = "leave the stored key alone." Anything else (including
		// empty string) is treated as the new value — empty deletes the key.
		if ( $anthropic !== self::KEEP_SENTINEL ) {
			AI_Settings::set_anthropic_key( $anthropic );
		}
		if ( $openai !== self::KEEP_SENTINEL ) {
			AI_Settings::set_openai_key( $openai );
		}
		if ( $model !== '' ) {
			AI_Settings::set_default_model( $model );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&flash=saved' ) );
		exit;
	}

	public static function handle_test_ajax(): void {
		if ( ! current_user_can( Menu::CAP ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden.' ], 403 );
		}
		check_ajax_referer( 'asteris_aff_ai_test_key', '_nonce' );

		$vendor = isset( $_POST['vendor'] ) ? sanitize_key( wp_unslash( $_POST['vendor'] ) ) : '';
		$key    = isset( $_POST['key'] )    ? trim( (string) wp_unslash( $_POST['key'] ) )    : '';

		if ( $vendor !== Router::VENDOR_OPENAI && $vendor !== Router::VENDOR_ANTHROPIC ) {
			wp_send_json_error( [ 'message' => 'Unknown vendor.' ], 400 );
		}

		// Empty key in the AJAX payload = use the encrypted-at-rest key.
		if ( $key === '' ) {
			$key = $vendor === Router::VENDOR_OPENAI
				? AI_Settings::get_openai_key()
				: AI_Settings::get_anthropic_key();
		}
		if ( $key === '' ) {
			wp_send_json_error( [ 'message' => 'No key to test.' ] );
		}

		$res = Router::test_key( $vendor, $key );
		if ( $res['ok'] ) {
			wp_send_json_success();
		}
		wp_send_json_error( [ 'message' => $res['error'] ] );
	}

	private static function render_flash( string $f ): void {
		if ( $f !== 'saved' ) { return; }
		echo '<div class="notice notice-success is-dismissible" style="margin:14px 0;"><p>✓ AI settings saved.</p></div>';
	}
}
