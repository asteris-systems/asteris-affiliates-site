<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Free_Tier;
use AsterisAffiliates\Swipe_Copy\Library;

defined( 'ABSPATH' ) || exit;

/**
 * Swipe Copy admin page.
 *
 * Manage the per-channel swipe copy library affiliates copy from in the
 * portal Links tab. 16 default snippets are seeded on activation; admin
 * can add, edit, deactivate, delete + generate AI variants (Pro).
 */
final class Page_Swipe_Copy {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_swipe_save',    [ self::class, 'handle_save' ] );
		add_action( 'admin_post_asteris_aff_swipe_delete',  [ self::class, 'handle_delete' ] );
		add_action( 'admin_post_asteris_aff_swipe_toggle',  [ self::class, 'handle_toggle' ] );
		// v1.3.14 — AI variant generation moved to the edit form (inline AJAX,
		// rewrites the textarea). The old "create-a-new-AI-row" handler is gone
		// — it created confusing duplicate rows prefixed "✨ AI:".
		add_action( 'wp_ajax_asteris_aff_swipe_ai_inline', [ self::class, 'handle_ai_inline_ajax' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$rows    = Library::list();
		$flash   = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$edit_id = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0;
		$editing = $edit_id > 0 ? Library::get( $edit_id ) : null;
		?>
		<div class="wrap" style="max-width:1100px;">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<?php esc_html_e( 'Swipe Copy library', 'asteris-affiliates' ); ?>
				<span style="background:#fff;border:1px solid #e5e7eb;color:#666;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:600;"><?php echo (int) count( $rows ); ?> <?php esc_html_e( 'snippets', 'asteris-affiliates' ); ?></span>
			</h1>
			<p style="color:#666;"><?php esc_html_e( 'Pre-written promo copy your affiliates can copy from the portal Links tab. Tokens like {{tracking_url}} are substituted at copy-time.', 'asteris-affiliates' ); ?></p>

			<?php self::render_flash( $flash ); ?>

			<!-- Add new / Edit existing (same form, mode toggles by ?edit=ID) -->
			<div id="asteris-edit-anchor" style="background:#fff;border:<?php echo $editing ? '2px solid #06D6A0' : '1px solid #e5e7eb'; ?>;border-radius:10px;padding:20px;margin:18px 0;">
				<h2 style="margin:0 0 14px;font-size:16px;">
					<?php if ( $editing ) : ?>
						<?php printf( esc_html__( 'Editing snippet #%d', 'asteris-affiliates' ), (int) $editing->id ); ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-swipe' ) ); ?>" style="font-size:12px;font-weight:normal;margin-left:10px;color:#6b7280;text-decoration:none;">← <?php esc_html_e( 'cancel edit', 'asteris-affiliates' ); ?></a>
					<?php else : ?>
						<?php esc_html_e( 'Add a new snippet', 'asteris-affiliates' ); ?>
					<?php endif; ?>
				</h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:grid;grid-template-columns:160px 1fr auto;gap:10px;align-items:end;">
					<?php wp_nonce_field( 'asteris_aff_swipe_save' ); ?>
					<input type="hidden" name="action" value="asteris_aff_swipe_save">
					<?php if ( $editing ) : ?>
						<input type="hidden" name="id" value="<?php echo (int) $editing->id; ?>">
					<?php endif; ?>
					<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Channel', 'asteris-affiliates' ); ?></span>
						<select name="channel" required style="width:100%;">
							<?php foreach ( self::channels() as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $editing->channel ?? '', $key ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Title (for affiliate to pick from)', 'asteris-affiliates' ); ?></span>
						<input type="text" name="title" required maxlength="120" style="width:100%;" placeholder="<?php esc_attr_e( 'e.g. Save 20% with my code', 'asteris-affiliates' ); ?>" value="<?php echo esc_attr( $editing->title ?? '' ); ?>">
					</label>
					<div style="display:flex;gap:8px;align-items:center;">
						<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;">
							<?php echo $editing ? esc_html__( 'Save changes', 'asteris-affiliates' ) : esc_html__( 'Add →', 'asteris-affiliates' ); ?>
						</button>
					</div>
					<label style="grid-column:1 / -1;">
						<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px;">
							<span style="font-size:12px;color:#666;font-weight:600;"><?php esc_html_e( 'Body', 'asteris-affiliates' ); ?></span>
							<?php if ( Free_Tier::is_pro() ) : ?>
								<button type="button" id="asteris-aff-regen-ai"
									data-nonce="<?php echo esc_attr( wp_create_nonce( 'asteris_aff_swipe_ai_inline' ) ); ?>"
									data-channel-selector="select[name=channel]"
									data-body-selector="textarea[name=body]"
									style="background:linear-gradient(135deg,#06D6A0 0%,#04a37c 100%);color:#fff;border:0;padding:5px 12px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;box-shadow:0 1px 3px rgba(6,214,160,0.3);">
									✨ <?php esc_html_e( 'Regenerate body with AI', 'asteris-affiliates' ); ?>
								</button>
							<?php endif; ?>
						</div>
						<textarea name="body" rows="5" required style="width:100%;font-family:ui-monospace,monospace;font-size:13px;" placeholder="<?php esc_attr_e( 'Use {{tracking_url}} placeholder for the affiliate\'s personalised link', 'asteris-affiliates' ); ?>"><?php echo esc_textarea( $editing->body ?? '' ); ?></textarea>
						<div id="asteris-aff-regen-status" style="font-size:12px;margin-top:6px;min-height:18px;color:#6b7280;"></div>
					</label>
				</form>
			</div>

			<?php if ( Free_Tier::is_pro() ) : ?>
			<script>
			( function () {
				'use strict';
				var btn = document.getElementById( 'asteris-aff-regen-ai' );
				if ( ! btn ) return;
				var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
				var status  = document.getElementById( 'asteris-aff-regen-status' );

				btn.addEventListener( 'click', function () {
					var channelEl = document.querySelector( btn.dataset.channelSelector );
					var bodyEl    = document.querySelector( btn.dataset.bodySelector );
					if ( ! channelEl || ! bodyEl ) return;
					var body = ( bodyEl.value || '' ).trim();
					if ( body === '' ) {
						status.textContent = '⚠ Type a starting body first — the AI rewrites what\'s there.';
						status.style.color = '#9a3412';
						return;
					}
					var original = btn.textContent;
					btn.disabled = true;
					btn.textContent = '✨ Generating…';
					bodyEl.style.opacity = '0.6';
					status.textContent = '';

					var fd = new URLSearchParams();
					fd.set( 'action',  'asteris_aff_swipe_ai_inline' );
					fd.set( '_nonce',  btn.dataset.nonce );
					fd.set( 'channel', channelEl.value );
					fd.set( 'body',    body );

					fetch( ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd } )
						.then( function ( r ) { return r.json(); } )
						.then( function ( res ) {
							if ( res && res.success && res.data && res.data.text ) {
								bodyEl.value = res.data.text;
								status.textContent = '✓ Generated. Review + Save changes, or click again for another variant.';
								status.style.color = '#059669';
							} else {
								var msg = ( res && res.data && res.data.message ) || 'unknown error';
								status.innerHTML = '✗ ' + msg;
								status.style.color = '#dc2626';
							}
						} )
						.catch( function ( e ) {
							status.textContent = '✗ Network error: ' + e.message;
							status.style.color = '#dc2626';
						} )
						.finally( function () {
							btn.disabled = false;
							btn.textContent = original;
							bodyEl.style.opacity = '1';
						} );
				} );
			} )();
			</script>
			<?php endif; ?>

			<!-- Existing snippets -->
			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th style="width:140px;"><?php esc_html_e( 'Channel', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Snippet', 'asteris-affiliates' ); ?></th>
					<th style="width:80px;text-align:center;"><?php esc_html_e( 'Active', 'asteris-affiliates' ); ?></th>
					<th style="width:240px;"><?php esc_html_e( 'Actions', 'asteris-affiliates' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="4" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No snippets yet — add one above.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) : ?>
					<tr>
						<td style="vertical-align:top;padding-top:14px;">
							<code style="font-size:11px;background:#f5f5f5;padding:2px 6px;border-radius:3px;"><?php echo esc_html( $r->channel ); ?></code>
							<?php if ( $r->ai_variant ) : ?>
								<div style="margin-top:6px;font-size:10px;color:#06D6A0;font-weight:600;letter-spacing:0.04em;">✨ AI VARIANT</div>
							<?php endif; ?>
						</td>
						<td style="vertical-align:top;padding-top:12px;padding-bottom:12px;">
							<div style="font-weight:600;color:#0a0a0a;margin-bottom:4px;"><?php echo esc_html( $r->title ); ?></div>
							<div style="color:#4b5563;font-size:12.5px;line-height:1.5;white-space:pre-wrap;word-break:break-word;"><?php echo esc_html( (string) $r->body ); ?></div>
						</td>
						<td style="text-align:center;vertical-align:top;padding-top:14px;"><?php echo $r->active ? '<span style="color:#059669;font-size:18px;">●</span>' : '<span style="color:#999;font-size:18px;">○</span>'; ?></td>
						<td style="vertical-align:top;padding-top:12px;">
							<?php
							$edit_url   = admin_url( 'admin.php?page=asteris-affiliates-swipe&edit=' . (int) $r->id ) . '#asteris-edit-anchor';
							$toggle_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_swipe_toggle&id=' . (int) $r->id ), 'asteris_aff_swipe_toggle_' . (int) $r->id );
							$delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_swipe_delete&id=' . (int) $r->id ), 'asteris_aff_swipe_delete_' . (int) $r->id );
							?>
							<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small button-primary" style="background:#06D6A0;border-color:#06D6A0;"><?php esc_html_e( 'Edit', 'asteris-affiliates' ); ?></a>
							<a href="<?php echo esc_url( $toggle_url ); ?>" class="button button-small"><?php echo $r->active ? esc_html__( 'Deactivate', 'asteris-affiliates' ) : esc_html__( 'Activate', 'asteris-affiliates' ); ?></a>
							<a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small" style="color:#dc2626;" onclick="return confirm('<?php esc_attr_e( 'Delete this snippet?', 'asteris-affiliates' ); ?>')"><?php esc_html_e( 'Delete', 'asteris-affiliates' ); ?></a>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>

			<?php if ( Free_Tier::is_free() ) : ?>
				<div style="background:#fff8e1;border-left:4px solid #b45309;border-radius:6px;padding:14px 18px;margin:18px 0;">
					✨ <strong><?php esc_html_e( 'AI swipe-copy generation is Pro-only.', 'asteris-affiliates' ); ?></strong>
					<?php esc_html_e( 'Upgrade to Pro to one-click generate fresh variants from your existing snippets.', 'asteris-affiliates' ); ?>
					<?php echo Free_Tier::upgrade_cta( 'swipe_copy' ); // phpcs:ignore ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function channels(): array {
		return [
			'email_subject'     => __( 'Email subject', 'asteris-affiliates' ),
			'email_body'        => __( 'Email body', 'asteris-affiliates' ),
			'twitter'           => __( 'Twitter / X', 'asteris-affiliates' ),
			'instagram_caption' => __( 'Instagram caption', 'asteris-affiliates' ),
			'linkedin'          => __( 'LinkedIn', 'asteris-affiliates' ),
			'facebook'          => __( 'Facebook', 'asteris-affiliates' ),
			'blog_intro'        => __( 'Blog intro', 'asteris-affiliates' ),
			'sms'               => __( 'SMS', 'asteris-affiliates' ),
		];
	}

	public static function handle_save(): void {
		check_admin_referer( 'asteris_aff_swipe_save' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$id      = isset( $_POST['id'] )      ? (int) $_POST['id'] : 0;
		$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';
		$title   = isset( $_POST['title'] )   ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$body    = isset( $_POST['body'] )    ? wp_kses_post( wp_unslash( $_POST['body'] ) ) : '';
		if ( $channel === '' || $title === '' || $body === '' ) {
			$back = $id > 0
				? admin_url( 'admin.php?page=asteris-affiliates-swipe&edit=' . $id . '&flash=missing_field' )
				: admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=missing_field' );
			wp_safe_redirect( $back ); exit;
		}
		if ( $id > 0 ) {
			Library::update( $id, $channel, $title, $body );
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=updated' ) ); exit;
		}
		Library::add( $channel, $title, $body, false );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=added' ) ); exit;
	}

	public static function handle_delete(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_swipe_delete_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		Library::delete( $id );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=deleted' ) ); exit;
	}

	public static function handle_toggle(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_swipe_toggle_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_swipe_copy SET active = 1 - active WHERE id = %d",
			$id
		) );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=toggled' ) ); exit;
	}

	/**
	 * v1.3.14 — Inline AJAX AI variant generation for the edit form.
	 *
	 * Takes the current body + channel from the editor and returns a regenerated
	 * variant. The JS replaces the textarea with the result so the user reviews
	 * before saving. Replaces the old "create-a-new-AI-row" admin-post handler
	 * which made confusing duplicate rows.
	 */
	public static function handle_ai_inline_ajax(): void {
		if ( ! current_user_can( Menu::CAP ) ) {
			wp_send_json_error( [ 'message' => 'Forbidden.' ], 403 );
		}
		check_ajax_referer( 'asteris_aff_swipe_ai_inline', '_nonce' );

		$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';
		$body    = isset( $_POST['body'] )    ? trim( (string) wp_unslash( $_POST['body'] ) ) : '';
		if ( $channel === '' || $body === '' ) {
			wp_send_json_error( [ 'message' => 'Missing channel or body.' ], 400 );
		}

		$variant = Library::ai_generate_variant( $body, $channel, get_bloginfo( 'name' ) );
		if ( is_array( $variant ) ) {
			$reason = (string) ( $variant['error'] ?? 'unknown' );
			$ai_settings_url = admin_url( 'admin.php?page=' . \AsterisAffiliates\Admin\Page_AI_Settings::SLUG );
			$friendly = [
				'no_key'       => '<a href="' . esc_url( $ai_settings_url ) . '">Add your OpenAI or Anthropic API key</a> in AI Settings to use AI variants.',
				'pro_only'     => 'AI variant generation requires the Pro tier.',
				'vendor_error' => 'AI vendor error: ' . esc_html( (string) ( $variant['message'] ?? 'unknown' ) ),
				'empty'        => 'The AI returned an empty response. Try again.',
			][ $reason ] ?? 'AI generation failed.';
			wp_send_json_error( [ 'message' => $friendly, 'reason' => $reason ] );
		}
		wp_send_json_success( [ 'text' => (string) $variant ] );
	}

	private static function render_flash( string $f ): void {
		$vendor_msg = isset( $_GET['msg'] ) ? sanitize_text_field( wp_unslash( $_GET['msg'] ) ) : '';
		$ai_settings_url = admin_url( 'admin.php?page=' . \AsterisAffiliates\Admin\Page_AI_Settings::SLUG );
		$map = [
			'added'           => [ 'ok',  '✓ Snippet added.' ],
			'updated'         => [ 'ok',  '✓ Snippet updated.' ],
			'deleted'         => [ 'warn','⚠ Snippet deleted.' ],
			'toggled'         => [ 'ok',  '✓ Snippet visibility toggled.' ],
			'ai_added'        => [ 'ok',  '✨ AI variant generated + added.' ],
			'ai_no_key'       => [ 'warn','⚠ No AI key configured. <a href="' . esc_url( $ai_settings_url ) . '">Add your OpenAI or Anthropic API key</a> to use AI variants.' ],
			'ai_vendor_error' => [ 'err', '✗ AI vendor error: ' . esc_html( $vendor_msg !== '' ? $vendor_msg : 'unknown' ) ],
			'ai_unavailable'  => [ 'warn','⚠ AI generation unavailable.' ],
			'pro_only'        => [ 'warn','⚠ This feature requires Pro.' ],
			'missing_field'   => [ 'err', '✗ All fields are required.' ],
			'not_found'       => [ 'err', '✗ Snippet not found.' ],
		];
		if ( ! isset( $map[ $f ] ) ) { return; }
		[ $kind, $msg ] = $map[ $f ];
		$style = $kind === 'ok' ? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: ( $kind === 'warn' ? 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;' );
		// $msg is built from a closed set of static strings + esc_html'd values
		// above (vendor_msg, link href escaped via esc_url). Safe to echo with
		// limited tags.
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . wp_kses( $msg, [ 'a' => [ 'href' => [] ] ] ) . '</p></div>';
	}
}
