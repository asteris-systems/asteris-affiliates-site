<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Free_Tier;
use AsterisAffiliates\Swipe_Copy\Library;

defined( 'ABSPATH' ) || exit;

/**
 * Swipe Copy admin page.
 *
 * Manage the per-channel swipe copy library affiliates copy from in the
 * portal Links tab. 16 default snippets are seeded on activation; admin
 * can add, edit, deactivate, delete + generate AI variants (Pro).
 */
final class Page_Swipe_Copy {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_swipe_save',    [ self::class, 'handle_save' ] );
		add_action( 'admin_post_asteris_aff_swipe_delete',  [ self::class, 'handle_delete' ] );
		add_action( 'admin_post_asteris_aff_swipe_toggle',  [ self::class, 'handle_toggle' ] );
		add_action( 'admin_post_asteris_aff_swipe_ai',      [ self::class, 'handle_ai_variant' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$rows  = Library::list();
		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		?>
		<div class="wrap" style="max-width:1100px;">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<?php esc_html_e( 'Swipe Copy library', 'asteris-affiliates' ); ?>
				<span style="background:#fff;border:1px solid #e5e7eb;color:#666;padding:2px 10px;border-radius:99px;font-size:11px;font-weight:600;"><?php echo (int) count( $rows ); ?> <?php esc_html_e( 'snippets', 'asteris-affiliates' ); ?></span>
			</h1>
			<p style="color:#666;"><?php esc_html_e( 'Pre-written promo copy your affiliates can copy from the portal Links tab. Tokens like {{tracking_url}} are substituted at copy-time.', 'asteris-affiliates' ); ?></p>

			<?php self::render_flash( $flash ); ?>

			<!-- Add new -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin:18px 0;">
				<h2 style="margin:0 0 14px;font-size:16px;"><?php esc_html_e( 'Add a new snippet', 'asteris-affiliates' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:grid;grid-template-columns:160px 1fr auto;gap:10px;align-items:end;">
					<?php wp_nonce_field( 'asteris_aff_swipe_save' ); ?>
					<input type="hidden" name="action" value="asteris_aff_swipe_save">
					<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Channel', 'asteris-affiliates' ); ?></span>
						<select name="channel" required style="width:100%;">
							<?php foreach ( self::channels() as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Title (for affiliate to pick from)', 'asteris-affiliates' ); ?></span>
						<input type="text" name="title" required maxlength="120" style="width:100%;" placeholder="<?php esc_attr_e( 'e.g. Save 20% with my code', 'asteris-affiliates' ); ?>">
					</label>
					<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;"><?php esc_html_e( 'Add →', 'asteris-affiliates' ); ?></button>
					<label style="grid-column:1 / -1;"><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Body', 'asteris-affiliates' ); ?></span>
						<textarea name="body" rows="3" required style="width:100%;" placeholder="<?php esc_attr_e( 'Use {{tracking_url}} placeholder for the affiliate\'s personalised link', 'asteris-affiliates' ); ?>"></textarea>
					</label>
				</form>
			</div>

			<!-- Existing snippets -->
			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th style="width:120px;"><?php esc_html_e( 'Channel', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Title', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Body preview', 'asteris-affiliates' ); ?></th>
					<th style="width:80px;text-align:center;"><?php esc_html_e( 'AI?', 'asteris-affiliates' ); ?></th>
					<th style="width:80px;text-align:center;"><?php esc_html_e( 'Active', 'asteris-affiliates' ); ?></th>
					<th style="width:220px;"><?php esc_html_e( 'Actions', 'asteris-affiliates' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="6" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No snippets yet — add one above.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) : ?>
					<tr>
						<td><code style="font-size:11px;background:#f5f5f5;padding:2px 6px;border-radius:3px;"><?php echo esc_html( $r->channel ); ?></code></td>
						<td><strong><?php echo esc_html( $r->title ); ?></strong></td>
						<td style="color:#666;font-size:12px;"><?php echo esc_html( mb_substr( (string) $r->body, 0, 80 ) . ( mb_strlen( (string) $r->body ) > 80 ? '…' : '' ) ); ?></td>
						<td style="text-align:center;"><?php echo $r->ai_variant ? '<span style="color:#06D6A0;">✓</span>' : '—'; ?></td>
						<td style="text-align:center;"><?php echo $r->active ? '<span style="color:#059669;">●</span>' : '<span style="color:#999;">○</span>'; ?></td>
						<td>
							<?php
							$toggle_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_swipe_toggle&id=' . (int) $r->id ), 'asteris_aff_swipe_toggle_' . (int) $r->id );
							$delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_swipe_delete&id=' . (int) $r->id ), 'asteris_aff_swipe_delete_' . (int) $r->id );
							?>
							<a href="<?php echo esc_url( $toggle_url ); ?>" class="button button-small"><?php echo $r->active ? esc_html__( 'Deactivate', 'asteris-affiliates' ) : esc_html__( 'Activate', 'asteris-affiliates' ); ?></a>
							<a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small" style="color:#dc2626;" onclick="return confirm('<?php esc_attr_e( 'Delete this snippet?', 'asteris-affiliates' ); ?>')"><?php esc_html_e( 'Delete', 'asteris-affiliates' ); ?></a>
							<?php if ( Free_Tier::is_pro() ) :
								$ai_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_swipe_ai&id=' . (int) $r->id ), 'asteris_aff_swipe_ai_' . (int) $r->id );
								?>
								<a href="<?php echo esc_url( $ai_url ); ?>" class="button button-small" style="background:#06D6A0;border-color:#06D6A0;color:#fff;" title="<?php esc_attr_e( 'Generate AI variant', 'asteris-affiliates' ); ?>">✨ AI</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>

			<?php if ( Free_Tier::is_free() ) : ?>
				<div style="background:#fff8e1;border-left:4px solid #b45309;border-radius:6px;padding:14px 18px;margin:18px 0;">
					✨ <strong><?php esc_html_e( 'AI swipe-copy generation is Pro-only.', 'asteris-affiliates' ); ?></strong>
					<?php esc_html_e( 'Upgrade to Pro to one-click generate fresh variants from your existing snippets.', 'asteris-affiliates' ); ?>
					<?php echo Free_Tier::upgrade_cta( 'swipe_copy' ); // phpcs:ignore ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function channels(): array {
		return [
			'email_subject'     => __( 'Email subject', 'asteris-affiliates' ),
			'email_body'        => __( 'Email body', 'asteris-affiliates' ),
			'twitter'           => __( 'Twitter / X', 'asteris-affiliates' ),
			'instagram_caption' => __( 'Instagram caption', 'asteris-affiliates' ),
			'linkedin'          => __( 'LinkedIn', 'asteris-affiliates' ),
			'facebook'          => __( 'Facebook', 'asteris-affiliates' ),
			'blog_intro'        => __( 'Blog intro', 'asteris-affiliates' ),
			'sms'               => __( 'SMS', 'asteris-affiliates' ),
		];
	}

	public static function handle_save(): void {
		check_admin_referer( 'asteris_aff_swipe_save' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';
		$title   = isset( $_POST['title'] )   ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$body    = isset( $_POST['body'] )    ? wp_kses_post( wp_unslash( $_POST['body'] ) ) : '';
		if ( $channel === '' || $title === '' || $body === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=missing_field' ) ); exit;
		}
		Library::add( $channel, $title, $body, false );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=added' ) ); exit;
	}

	public static function handle_delete(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_swipe_delete_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		Library::delete( $id );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=deleted' ) ); exit;
	}

	public static function handle_toggle(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_swipe_toggle_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_swipe_copy SET active = 1 - active WHERE id = %d",
			$id
		) );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=toggled' ) ); exit;
	}

	public static function handle_ai_variant(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_swipe_ai_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		if ( ! Free_Tier::is_pro() ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=pro_only' ) ); exit;
		}
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_swipe_copy WHERE id = %d",
			$id
		) );
		if ( ! $row ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=not_found' ) ); exit;
		}
		$variant = Library::ai_generate_variant( (string) $row->body, (string) $row->channel, get_bloginfo( 'name' ) );
		if ( ! $variant ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=ai_unavailable' ) ); exit;
		}
		Library::add( (string) $row->channel, '✨ AI: ' . substr( (string) $row->title, 0, 100 ), $variant, true );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-swipe&flash=ai_added' ) ); exit;
	}

	private static function render_flash( string $f ): void {
		$map = [
			'added'           => [ 'ok',  '✓ Snippet added.' ],
			'deleted'         => [ 'warn','⚠ Snippet deleted.' ],
			'toggled'         => [ 'ok',  '✓ Snippet visibility toggled.' ],
			'ai_added'        => [ 'ok',  '✨ AI variant generated + added.' ],
			'ai_unavailable'  => [ 'warn','⚠ AI provider unavailable. Install Asteris AI in Asteris WP to enable.' ],
			'pro_only'        => [ 'warn','⚠ This feature requires Pro.' ],
			'missing_field'   => [ 'err', '✗ All fields are required.' ],
			'not_found'       => [ 'err', '✗ Snippet not found.' ],
		];
		if ( ! isset( $map[ $f ] ) ) { return; }
		[ $kind, $msg ] = $map[ $f ];
		$style = $kind === 'ok' ? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: ( $kind === 'warn' ? 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;' );
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . esc_html( $msg ) . '</p></div>';
	}
}
