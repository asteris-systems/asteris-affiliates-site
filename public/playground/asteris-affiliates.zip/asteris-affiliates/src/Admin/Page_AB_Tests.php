<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Free_Tier;
use AsterisAffiliates\Email\AB_Engine;
use AsterisAffiliates\Email\Template_Registry;

defined( 'ABSPATH' ) || exit;

/**
 * A/B email tests admin.
 *
 * Create variant subjects + bodies for any of the 15 transactional email
 * templates. Variants share the template_slug and receive a weighted share
 * of sends. Open-tracking pixel records reads.
 *
 * Pro-only — page renders an upgrade pitch when free.
 */
final class Page_AB_Tests {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_ab_save',   [ self::class, 'handle_save' ] );
		add_action( 'admin_post_asteris_aff_ab_delete', [ self::class, 'handle_delete' ] );
		add_action( 'admin_post_asteris_aff_ab_toggle', [ self::class, 'handle_toggle' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		if ( Free_Tier::is_free() ) {
			self::render_pro_upsell();
			return;
		}

		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}aff_ab_emails ORDER BY template_slug, variant_label ASC" );

		// Group by template_slug
		$grouped = [];
		foreach ( $rows as $r ) { $grouped[ $r->template_slug ][] = $r; }
		?>
		<div class="wrap" style="max-width:1100px;">
			<h1><?php esc_html_e( 'A/B Email Tests', 'asteris-affiliates' ); ?></h1>
			<p style="color:#666;"><?php esc_html_e( 'Test different subject + body variants for any transactional email. Weighted distribution. Opens tracked via 1×1 pixel.', 'asteris-affiliates' ); ?></p>

			<?php self::render_flash( $flash ); ?>

			<!-- Add variant -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin:18px 0;">
				<h2 style="margin:0 0 14px;font-size:16px;"><?php esc_html_e( 'Add a variant', 'asteris-affiliates' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'asteris_aff_ab_save' ); ?>
					<input type="hidden" name="action" value="asteris_aff_ab_save">
					<div style="display:grid;grid-template-columns:1.5fr 100px 80px auto;gap:10px;align-items:end;">
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Template', 'asteris-affiliates' ); ?></span>
							<select name="template_slug" required style="width:100%;">
								<?php foreach ( self::template_choices() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Variant', 'asteris-affiliates' ); ?></span>
							<input type="text" name="variant_label" required maxlength="8" style="width:100%;" placeholder="A">
						</label>
						<label><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Weight', 'asteris-affiliates' ); ?></span>
							<input type="number" name="weight" min="1" max="100" value="50" style="width:100%;">
						</label>
						<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;"><?php esc_html_e( 'Add →', 'asteris-affiliates' ); ?></button>
					</div>
					<label style="display:block;margin-top:12px;"><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Subject', 'asteris-affiliates' ); ?></span>
						<input type="text" name="subject" required style="width:100%;" placeholder="<?php esc_attr_e( 'Variant subject line — token-friendly', 'asteris-affiliates' ); ?>">
					</label>
					<label style="display:block;margin-top:12px;"><span style="display:block;font-size:12px;color:#666;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Body (HTML allowed)', 'asteris-affiliates' ); ?></span>
						<textarea name="body" rows="6" required style="width:100%;font-family:ui-monospace,monospace;font-size:12px;"></textarea>
					</label>
				</form>
			</div>

			<!-- Tests grouped by template -->
			<?php if ( ! $grouped ) : ?>
				<p style="text-align:center;padding:30px;color:#999;background:#fff;border:1px solid #e5e7eb;border-radius:10px;"><?php esc_html_e( 'No variants yet. Add one above to start a test.', 'asteris-affiliates' ); ?></p>
			<?php else : foreach ( $grouped as $slug => $variants ) :
				$total_sent  = 0;
				$total_opens = 0;
				foreach ( $variants as $v ) { $total_sent += (int) $v->sent_count; $total_opens += (int) $v->open_count; }
			?>
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px;margin:14px 0;">
					<h3 style="margin:0 0 10px;font-size:15px;font-family:ui-monospace,monospace;"><?php echo esc_html( $slug ); ?>
						<span style="color:#999;font-size:12px;font-weight:400;font-family:inherit;">· <?php echo (int) $total_sent; ?> sent · <?php echo $total_sent > 0 ? esc_html( round( ( $total_opens / $total_sent ) * 100, 1 ) ) : '0'; ?>% open</span>
					</h3>
					<table class="widefat" style="font-size:13px;">
						<thead><tr><th><?php esc_html_e( 'Variant', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Subject', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Weight', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Sent', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Opens', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Open %', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Status', 'asteris-affiliates' ); ?></th><th><?php esc_html_e( 'Actions', 'asteris-affiliates' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $variants as $v ) :
							$open_pct = $v->sent_count > 0 ? round( ( $v->open_count / $v->sent_count ) * 100, 1 ) : 0;
							$best = $total_sent > 0 && $open_pct === max( array_map( static fn( $vv ) => $vv->sent_count > 0 ? round( ( $vv->open_count / $vv->sent_count ) * 100, 1 ) : 0, $variants ) );
							$toggle_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_ab_toggle&id=' . (int) $v->id ), 'asteris_aff_ab_toggle_' . (int) $v->id );
							$delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_ab_delete&id=' . (int) $v->id ), 'asteris_aff_ab_delete_' . (int) $v->id );
						?>
							<tr>
								<td><strong><?php echo esc_html( $v->variant_label ); ?></strong><?php if ( $best && $v->sent_count > 10 ) echo ' 🏆'; ?></td>
								<td style="font-size:12px;"><?php echo esc_html( mb_substr( (string) $v->subject, 0, 80 ) ); ?></td>
								<td><?php echo (int) $v->weight; ?></td>
								<td><?php echo (int) $v->sent_count; ?></td>
								<td><?php echo (int) $v->open_count; ?></td>
								<td><strong><?php echo esc_html( $open_pct ); ?>%</strong></td>
								<td><?php echo $v->active ? '<span style="color:#059669;">●</span>' : '<span style="color:#999;">○</span>'; ?></td>
								<td>
									<a href="<?php echo esc_url( $toggle_url ); ?>" class="button button-small"><?php echo $v->active ? esc_html__( 'Off', 'asteris-affiliates' ) : esc_html__( 'On', 'asteris-affiliates' ); ?></a>
									<a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small" style="color:#dc2626;" onclick="return confirm('<?php esc_attr_e( 'Delete this variant?', 'asteris-affiliates' ); ?>')"><?php esc_html_e( 'Delete', 'asteris-affiliates' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endforeach; endif; ?>

			<p style="color:#666;font-size:12px;margin-top:14px;"><?php esc_html_e( '🏆 = highest open rate (with >10 sends). Click tracking lands in v1.2.', 'asteris-affiliates' ); ?></p>
		</div>
		<?php
	}

	private static function template_choices(): array {
		$out = [];
		if ( class_exists( Template_Registry::class ) && method_exists( Template_Registry::class, 'all' ) ) {
			foreach ( Template_Registry::all() as $slug => $def ) {
				$out[ $slug ] = $slug . ( isset( $def['subject'] ) ? ' — ' . mb_substr( $def['subject'], 0, 50 ) : '' );
			}
		}
		// Sensible fallback when Registry::all() isn't exposed
		if ( ! $out ) {
			$out = [
				'approved'      => 'approved',
				'rejected'      => 'rejected',
				'commission'    => 'commission',
				'payout_sent'   => 'payout_sent',
				'monthly_recap' => 'monthly_recap',
				'magic_link'    => 'magic_link',
			];
		}
		return $out;
	}

	private static function render_pro_upsell(): void {
		?>
		<div class="wrap" style="max-width:780px;">
			<h1><?php esc_html_e( 'A/B Email Tests', 'asteris-affiliates' ); ?></h1>
			<div style="background:linear-gradient(135deg,#06D6A0,#0a857a);color:#fff;padding:36px;border-radius:12px;margin:24px 0;">
				<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;opacity:0.85;font-weight:700;margin-bottom:8px;">✨ PRO FEATURE</div>
				<h2 style="margin:0 0 12px;color:#fff;font-size:28px;letter-spacing:-1px;"><?php esc_html_e( 'Test what actually converts', 'asteris-affiliates' ); ?></h2>
				<p style="margin:0 0 22px;font-size:15px;opacity:0.95;line-height:1.5;"><?php esc_html_e( "Run weighted-distribution A/B tests on every transactional email — subject lines, body copy, CTA placement. Open-rate tracking surfaces the winner automatically. Replaces $30+/mo SaaS A/B email tools.", 'asteris-affiliates' ); ?></p>
				<a href="https://asterisaffiliates.com/pricing?utm_source=plugin&utm_medium=ab_tests&utm_campaign=upsell" target="_blank" rel="noopener" style="background:#fff;color:#0a857a;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:800;font-size:15px;display:inline-block;"><?php esc_html_e( 'Upgrade to Pro →', 'asteris-affiliates' ); ?></a>
			</div>
		</div>
		<?php
	}

	public static function handle_save(): void {
		check_admin_referer( 'asteris_aff_ab_save' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		if ( Free_Tier::is_free() ) { wp_die( 'Pro only.', 403 ); }

		$slug    = isset( $_POST['template_slug'] ) ? sanitize_key( wp_unslash( $_POST['template_slug'] ) ) : '';
		$label   = isset( $_POST['variant_label'] ) ? sanitize_text_field( wp_unslash( $_POST['variant_label'] ) ) : '';
		$weight  = isset( $_POST['weight'] )  ? (int) $_POST['weight'] : 50;
		$subject = isset( $_POST['subject'] ) ? wp_strip_all_tags( wp_unslash( $_POST['subject'] ) ) : '';
		$body    = isset( $_POST['body'] )    ? wp_kses_post( wp_unslash( $_POST['body'] ) ) : '';

		if ( $slug === '' || $label === '' || $subject === '' || $body === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-ab&flash=missing_field' ) ); exit;
		}
		AB_Engine::add_variant( $slug, $label, $subject, $body, $weight );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-ab&flash=added' ) ); exit;
	}

	public static function handle_delete(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_ab_delete_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'aff_ab_emails', [ 'id' => $id ] );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-ab&flash=deleted' ) ); exit;
	}

	public static function handle_toggle(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_ab_toggle_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}aff_ab_emails SET active = 1 - active WHERE id = %d", $id ) );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-ab&flash=toggled' ) ); exit;
	}

	private static function render_flash( string $f ): void {
		$map = [
			'added'        => [ 'ok',  '✓ Variant added.' ],
			'deleted'      => [ 'warn','⚠ Variant deleted.' ],
			'toggled'      => [ 'ok',  '✓ Variant status toggled.' ],
			'missing_field'=> [ 'err', '✗ Template, variant label, subject and body are all required.' ],
		];
		if ( ! isset( $map[ $f ] ) ) { return; }
		[ $kind, $msg ] = $map[ $f ];
		$style = $kind === 'ok' ? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: ( $kind === 'warn' ? 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;' );
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . esc_html( $msg ) . '</p></div>';
	}
}
