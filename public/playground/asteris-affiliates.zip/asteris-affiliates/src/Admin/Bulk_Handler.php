<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Email\Renderer;
use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Shared handler for bulk admin actions across the Affiliates + Commissions
 * + Payouts pages.
 *
 * All POSTs are nonced + capability-checked. Returns counts via flash params
 * so the redirected page can show "Approved N of M".
 */
final class Bulk_Handler {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_bulk_affiliates',   [ self::class, 'handle_affiliates' ] );
		add_action( 'admin_post_asteris_aff_bulk_commissions',  [ self::class, 'handle_commissions' ] );
		add_action( 'admin_post_asteris_aff_bulk_payouts',      [ self::class, 'handle_payouts' ] );
	}

	// ── Affiliates: bulk approve / reject / suspend / reinstate ─────────────

	public static function handle_affiliates(): void {
		check_admin_referer( 'asteris_aff_bulk_affiliates' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		$ids    = self::extract_ids( $_POST['ids'] ?? [] );
		if ( ! $action || ! $ids ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=nothing_selected' ) );
			exit;
		}

		$allowed = [ 'approve', 'reject', 'suspend', 'reinstate' ];
		if ( ! in_array( $action, $allowed, true ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=bad_action' ) );
			exit;
		}

		$now = current_time( 'mysql', true );
		$map = [
			'approve'   => [ 'status' => 'approved',  'approved_at'  => $now ],
			'reject'    => [ 'status' => 'rejected'                          ],
			'suspend'   => [ 'status' => 'suspended', 'suspended_at' => $now ],
			'reinstate' => [ 'status' => 'approved',  'suspended_at' => null ],
		];
		$update = $map[ $action ];

		$count = 0;
		foreach ( $ids as $id ) {
			$aff = Affiliate_Repository::find( $id );
			if ( ! $aff ) { continue; }
			Affiliate_Repository::update( $id, $update );

			if ( $action === 'approve' ) {
				Renderer::send_template( 'approved', $aff->email, [
					'display_name' => $aff->display_name,
					'portal_url'   => home_url( '/affiliate-portal/' ),
					'tracking_url' => add_query_arg( 'ref', $aff->public_id, home_url( '/' ) ),
					'y1_rate'      => (string) (int) round( (int) $aff->commission_rate_y1_bp / 100 ),
					'y2_rate'      => (string) (int) round( (int) $aff->commission_rate_y2plus_bp / 100 ),
					'cookie_days'  => (string) (int) Settings::get( 'cookie_days', 60 ),
				] );
			}
			self::log( 'affiliate.bulk_' . $action, $id, [ 'actor' => self::actor() ] );
			$count++;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=bulk_done&n=' . $count . '&a=' . $action ) );
		exit;
	}

	// ── Commissions: bulk approve / reject ──────────────────────────────────

	public static function handle_commissions(): void {
		check_admin_referer( 'asteris_aff_bulk_commissions' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		$ids    = self::extract_ids( $_POST['ids'] ?? [] );
		if ( ! $action || ! $ids ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-commissions&flash=nothing_selected' ) );
			exit;
		}
		if ( ! in_array( $action, [ 'approve', 'reject' ], true ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-commissions&flash=bad_action' ) );
			exit;
		}

		global $wpdb;
		$now   = current_time( 'mysql', true );
		$count = 0;
		foreach ( $ids as $id ) {
			if ( $action === 'approve' ) {
				$ok = $wpdb->update( $wpdb->prefix . 'aff_commissions',
					[ 'status' => 'approved', 'approved_at' => $now ],
					[ 'id' => $id, 'status' => 'pending' ]
				);
			} else {
				$ok = $wpdb->update( $wpdb->prefix . 'aff_commissions',
					[ 'status' => 'rejected' ],
					[ 'id' => $id, 'status' => 'pending' ]
				);
			}
			if ( $ok !== false && $ok > 0 ) {
				$count++;
				self::log( 'commission.bulk_' . $action, null, [
					'commission_id' => $id,
					'actor'         => self::actor(),
				] );
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-commissions&flash=bulk_done&n=' . $count . '&a=' . $action ) );
		exit;
	}

	// ── Payouts: bulk mark-paid / mark-failed ───────────────────────────────

	public static function handle_payouts(): void {
		check_admin_referer( 'asteris_aff_bulk_payouts' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		$ids    = self::extract_ids( $_POST['ids'] ?? [] );
		if ( ! $action || ! $ids ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=nothing_selected' ) );
			exit;
		}

		global $wpdb;
		$now   = current_time( 'mysql', true );
		$count = 0;
		foreach ( $ids as $id ) {
			if ( $action === 'mark_paid' ) {
				$wpdb->update( $wpdb->prefix . 'aff_payouts',
					[ 'status' => 'paid', 'paid_at' => $now ],
					[ 'id' => $id ]
				);
				$count++;
				self::log( 'payout.bulk_marked_paid', null, [ 'payout_id' => $id, 'actor' => self::actor() ] );
			} elseif ( $action === 'mark_failed' ) {
				$wpdb->update( $wpdb->prefix . 'aff_payouts',
					[ 'status' => 'failed', 'failure_reason' => 'admin_marked_failed' ],
					[ 'id' => $id ]
				);
				$count++;
				self::log( 'payout.bulk_marked_failed', null, [ 'payout_id' => $id, 'actor' => self::actor() ] );
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=bulk_done&n=' . $count . '&a=' . $action ) );
		exit;
	}

	// ── Helpers ─────────────────────────────────────────────────────────────

	/** @param mixed $raw */
	private static function extract_ids( $raw ): array {
		if ( ! is_array( $raw ) ) { return []; }
		$out = [];
		foreach ( $raw as $v ) {
			$id = (int) $v;
			if ( $id > 0 ) { $out[] = $id; }
		}
		return array_values( array_unique( $out ) );
	}

	private static function actor(): string {
		$u = wp_get_current_user();
		return 'admin:' . ( $u && $u->user_login ? $u->user_login : 'unknown' );
	}

	private static function log( string $event_type, ?int $affiliate_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event_type,
			'affiliate_id' => $affiliate_id,
			'actor'        => self::actor(),
			'payload'      => wp_json_encode( $payload ),
		] );
	}

	/**
	 * Render the bulk-action toolbar for use above a table.
	 * Pass the form action ('asteris_aff_bulk_affiliates' etc) and the action options.
	 *
	 * @param array<string,string> $options  bulk_action key → human label
	 */
	public static function toolbar( string $form_action, array $options, string $page_param ): string {
		ob_start();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="aff-bulk-form" style="display:flex;gap:6px;align-items:center;margin-bottom:8px;">
			<?php wp_nonce_field( $form_action ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( $form_action ); ?>">
			<select name="bulk_action" class="aff-bulk-select" style="font-size:13px;">
				<option value="">— <?php esc_html_e( 'Bulk action', 'asteris-affiliates' ); ?> —</option>
				<?php foreach ( $options as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<button type="submit" class="button" onclick="return confirm('<?php esc_attr_e( 'Apply to selected rows?', 'asteris-affiliates' ); ?>');"><?php esc_html_e( 'Apply', 'asteris-affiliates' ); ?></button>
			<span style="color:#666;font-size:11px;margin-left:4px;" class="aff-bulk-count">0 selected</span>
		</form>
		<script>
		(function(){
			var form = document.querySelector('form.aff-bulk-form[action]');
			document.addEventListener('change', function(e){
				if (e.target && e.target.matches('input.aff-row-cb, input.aff-cb-all')) {
					if (e.target.classList.contains('aff-cb-all')) {
						var checked = e.target.checked;
						document.querySelectorAll('input.aff-row-cb').forEach(function(cb){ cb.checked = checked; });
					}
					var n = document.querySelectorAll('input.aff-row-cb:checked').length;
					document.querySelectorAll('.aff-bulk-count').forEach(function(s){ s.textContent = n + ' selected'; });
					document.querySelectorAll('form.aff-bulk-form input[name="ids[]"]').forEach(function(el){ el.remove(); });
					document.querySelectorAll('input.aff-row-cb:checked').forEach(function(cb){
						var h = document.createElement('input');
						h.type = 'hidden'; h.name = 'ids[]'; h.value = cb.value;
						document.querySelectorAll('form.aff-bulk-form').forEach(function(f){ f.appendChild(h.cloneNode()); });
					});
				}
			});
		})();
		</script>
		<?php
		return (string) ob_get_clean();
	}

	/** Convenience: render a row-checkbox cell. */
	public static function row_checkbox( int $id ): string {
		return '<input type="checkbox" class="aff-row-cb" value="' . esc_attr( (string) $id ) . '" aria-label="' . esc_attr__( 'Select row', 'asteris-affiliates' ) . '">';
	}

	/** Convenience: render the "select-all" checkbox in a <th>. */
	public static function header_checkbox(): string {
		return '<input type="checkbox" class="aff-cb-all" aria-label="' . esc_attr__( 'Select all rows', 'asteris-affiliates' ) . '">';
	}
}
