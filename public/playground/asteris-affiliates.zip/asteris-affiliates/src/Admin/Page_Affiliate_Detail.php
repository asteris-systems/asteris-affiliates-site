<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Per-affiliate detail + edit view.
 *
 * URL: admin.php?page=asteris-affiliates&id=<int>
 * (Page_Affiliates::render() dispatches to here when ?id is present.)
 *
 * Edit form covers every field a customer (admin) might reasonably need
 * to change post-creation:
 *   - Display name, first/last
 *   - Email
 *   - Country
 *   - Status (with side-effect log)
 *   - Commission rates: Y1 / Y2+ / per-affiliate custom override
 *   - Payout method + paypal_email
 *   - Audience size, promotion plan, internal notes, partner-facing notes
 *
 * Sensitive payout details (Stripe Connect account ID, encrypted bank
 * details) are READ-ONLY shown here — those flow through the affiliate's
 * own portal (Sprint 5 build).
 */
final class Page_Affiliate_Detail {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_save_detail',   [ self::class, 'handle_save' ] );
		add_action( 'admin_post_asteris_aff_delete',        [ self::class, 'handle_delete' ] );
		add_action( 'admin_post_asteris_aff_resend_welcome',[ self::class, 'handle_resend_welcome' ] );
	}

	public static function render( int $id ): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) {
			echo '<div class="wrap"><h1>Affiliate not found</h1><p><a href="' . esc_url( admin_url( 'admin.php?page=asteris-affiliates' ) ) . '">← Back to list</a></p></div>';
			return;
		}

		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$extra = isset( $_GET['extra'] ) ? sanitize_text_field( wp_unslash( $_GET['extra'] ) ) : '';

		// Cheap quick stats — same pattern as the portal
		global $wpdb;
		$p = $wpdb->prefix;
		$stats = [
			'clicks_total'   => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d", $id ) ),
			'clicks_30d'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d AND landed_at > DATE_SUB(NOW(), INTERVAL 30 DAY)", $id ) ),
			'commissions'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_commissions WHERE affiliate_id = %d", $id ) ),
			'earnings_total' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE affiliate_id = %d AND status IN ('approved','paid')", $id ) ),
		];

		// Recent activity rows for this affiliate
		$activity = $wpdb->get_results( $wpdb->prepare(
			"SELECT occurred_at, event_type, actor, payload FROM {$p}aff_events WHERE affiliate_id = %d ORDER BY id DESC LIMIT 10",
			$id
		) );

		$status_colour = [ 'pending' => '#ea580c', 'approved' => '#059669', 'suspended' => '#b45309', 'rejected' => '#6b7280', 'terminated' => '#dc2626' ][ $aff->status ] ?? '#6b7280';
		?>
		<div class="wrap">
			<h1 style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates' ) ); ?>" style="text-decoration:none;color:#0073aa;">← Affiliates</a>
				<span style="color:#999;font-weight:300;">/</span>
				<?php echo esc_html( $aff->display_name ); ?>
				<span style="background:<?php echo esc_attr( $status_colour ); ?>;color:#fff;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;"><?php echo esc_html( $aff->status ); ?></span>
				<span style="font-family:ui-monospace,monospace;font-size:12px;color:#999;font-weight:400;">#<?php echo (int) $aff->id; ?></span>
			</h1>

			<?php self::render_flash( $flash, $extra ); ?>

			<!-- Quick stats strip -->
			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:14px 0 18px;">
				<?php foreach ( [
					[ 'Clicks · total',     number_format_i18n( $stats['clicks_total'] ),                          '#0a857a' ],
					[ 'Clicks · 30d',       number_format_i18n( $stats['clicks_30d'] ),                            '#06D6A0' ],
					[ 'Commissions',        number_format_i18n( $stats['commissions'] ),                           '#0a857a' ],
					[ 'Earnings · approved+paid', '$' . number_format( $stats['earnings_total'] / 100, 2 ),       '#059669' ],
				] as $card ) : [ $label, $value, $colour ] = $card; ?>
					<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo esc_attr( $colour ); ?>;border-radius:8px;padding:12px 14px;">
						<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $label ); ?></div>
						<div style="font-size:20px;color:#0a0a0a;font-weight:800;margin-top:2px;"><?php echo esc_html( $value ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<div style="display:grid;grid-template-columns:1fr 320px;gap:18px;">
				<div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px;">
						<?php wp_nonce_field( 'asteris_aff_save_detail_' . $id ); ?>
						<input type="hidden" name="action" value="asteris_aff_save_detail">
						<input type="hidden" name="id" value="<?php echo (int) $id; ?>">

						<h2 style="margin-top:0;">Identity</h2>
						<table class="form-table" role="presentation">
							<tr><th>Display name *</th><td><input type="text" name="display_name" required maxlength="120" value="<?php echo esc_attr( $aff->display_name ); ?>" class="regular-text" style="width:100%;"></td></tr>
							<tr><th>First name</th><td><input type="text" name="first_name" maxlength="80" value="<?php echo esc_attr( (string) $aff->first_name ); ?>" class="regular-text"></td></tr>
							<tr><th>Last name</th><td><input type="text" name="last_name" maxlength="80" value="<?php echo esc_attr( (string) $aff->last_name ); ?>" class="regular-text"></td></tr>
							<tr><th>Email *</th><td><input type="email" name="email" required maxlength="254" value="<?php echo esc_attr( $aff->email ); ?>" class="regular-text" style="width:100%;"> <p class="description">Changing the email also changes their portal sign-in identity. They'll need a fresh magic link.</p></td></tr>
							<tr><th>Country (ISO-2)</th><td><input type="text" name="country_code" maxlength="2" value="<?php echo esc_attr( $aff->country_code ); ?>" class="regular-text" style="max-width:80px;text-transform:uppercase;"></td></tr>
							<tr><th>Public ID *</th><td>
								<input type="text" name="public_id" required maxlength="48" minlength="3" pattern="^[a-z0-9](?:[a-z0-9-]{1,46}[a-z0-9])?$" value="<?php echo esc_attr( $aff->public_id ); ?>" class="regular-text" style="font-family:ui-monospace,monospace;max-width:320px;text-transform:lowercase;">
								<p class="description">Used in the affiliate's <code>?ref=…</code> link. Lower-case letters, numbers, hyphens only — 3 to 48 chars, no leading or trailing hyphen. <strong>Must be unique across all affiliates</strong> (validated at save).</p>
								<p class="description">Current tracking URL: <code style="background:#f9fafb;padding:2px 6px;border-radius:3px;"><?php echo esc_html( add_query_arg( 'ref', $aff->public_id, home_url( '/' ) ) ); ?></code></p>
							</td></tr>
						</table>

						<h2>Status</h2>
						<table class="form-table" role="presentation">
							<tr><th>Status</th><td>
								<select name="status" class="regular-text" style="max-width:240px;">
									<?php foreach ( [ 'pending' => 'Pending review', 'approved' => 'Approved', 'suspended' => 'Suspended', 'rejected' => 'Rejected', 'terminated' => 'Terminated' ] as $val => $label ) : ?>
										<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $aff->status ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description">Status changes are logged in the activity feed. Switching to <strong>approved</strong> from any other status does NOT auto-send the welcome email — use the button on the right.</p>
							</td></tr>
						</table>

						<h2>Commission rates</h2>
						<table class="form-table" role="presentation">
							<tr><th>Year 1 (bp)</th><td><input type="number" name="commission_rate_y1_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( (int) $aff->commission_rate_y1_bp ); ?>" class="regular-text" style="max-width:140px;"> <span style="color:#666;">2000 = 20%</span></td></tr>
							<tr><th>Year 2+ (bp)</th><td><input type="number" name="commission_rate_y2plus_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( (int) $aff->commission_rate_y2plus_bp ); ?>" class="regular-text" style="max-width:140px;"></td></tr>
							<tr><th>Custom override (bp)</th><td><input type="number" name="custom_rate_override_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( (string) ( $aff->custom_rate_override_bp ?? '' ) ); ?>" placeholder="(blank = use Y1/Y2 rates)" class="regular-text" style="max-width:140px;"> <p class="description">Set this to lock a flat per-affiliate rate that overrides the Y1/Y2 schedule. Used for special deals (e.g. a hero partner on 30% forever).</p></td></tr>
						</table>

						<h2>MLM / Two-tier <?php echo \AsterisAffiliates\Core\Free_Tier::is_pro() ? '' : \AsterisAffiliates\Core\Free_Tier::pro_badge(); // phpcs:ignore ?></h2>
						<table class="form-table" role="presentation">
							<tr><th>Parent affiliate</th><td>
								<?php
								$parents = \AsterisAffiliates\Affiliates\Affiliate_Repository::list( [ 'status' => 'approved', 'limit' => 500 ] );
								$current_parent = (int) ( $aff->parent_affiliate_id ?? 0 );
								?>
								<select name="parent_affiliate_id" style="max-width:360px;">
									<option value="0">— None —</option>
									<?php foreach ( $parents as $p ) :
										if ( (int) $p->id === (int) $aff->id ) { continue; } // can't be own parent
									?>
										<option value="<?php echo (int) $p->id; ?>" <?php selected( $current_parent, (int) $p->id ); ?>>
											<?php echo esc_html( $p->display_name . ' — ' . $p->email ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description">When set + MLM is enabled (Settings → Pro features), parent earns the tier-2 rate (default 5%) on every commission this affiliate generates.</p>
							</td></tr>
							<tr><th>Tier 2 rate (bp)</th><td><input type="number" name="tier2_rate_bp" min="0" max="10000" step="50" value="<?php echo esc_attr( (int) ( $aff->tier2_rate_bp ?? 500 ) ); ?>" class="regular-text" style="max-width:140px;"> <span style="color:#666;">500 = 5% — applies when THIS affiliate is the parent of someone else</span></td></tr>
						</table>

						<h2>Payouts</h2>
						<table class="form-table" role="presentation">
							<tr><th>Payout method</th><td>
								<select name="payout_method" class="regular-text" style="max-width:240px;">
									<?php foreach ( [ 'stripe_connect' => 'Stripe Connect', 'bank_transfer' => 'Bank transfer', 'paypal' => 'PayPal', 'manual' => 'Manual' ] as $val => $label ) : ?>
										<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $aff->payout_method ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td></tr>
							<tr><th>PayPal email</th><td><input type="email" name="paypal_email" maxlength="254" value="<?php echo esc_attr( (string) $aff->paypal_email ); ?>" class="regular-text" style="width:100%;"> <p class="description">Only used when payout method = PayPal.</p></td></tr>
							<tr><th>Stripe Connect</th><td><?php if ( $aff->stripe_connect_account_id ) : ?>
								<code style="font-family:ui-monospace,monospace;font-size:12px;background:#f9fafb;padding:4px 8px;border-radius:4px;"><?php echo esc_html( $aff->stripe_connect_account_id ); ?></code>
								<span style="margin-left:8px;color:#666;font-size:12px;">status: <?php echo esc_html( $aff->stripe_connect_status ?? '—' ); ?></span>
							<?php else : ?>
								<span style="color:#999;">Not connected. Affiliate connects via their portal.</span>
							<?php endif; ?></td></tr>
							<tr><th>Bank details</th><td><?php echo $aff->bank_details_encrypted ? '<span style="color:#059669;font-weight:600;">✓ on file</span> <span style="color:#666;font-size:12px;margin-left:8px;">(encrypted at rest, decrypted only during payout)</span>' : '<span style="color:#999;">None on file.</span>'; ?></td></tr>
						</table>

						<h2>Context</h2>
						<table class="form-table" role="presentation">
							<tr><th>Audience size</th><td>
								<select name="audience_size" class="regular-text" style="max-width:240px;">
									<option value="">(unspecified)</option>
									<?php foreach ( [ '<1k' => '<1,000', '1k-10k' => '1,000–10,000', '10k-50k' => '10,000–50,000', '50k-200k' => '50,000–200,000', '>200k' => '>200,000' ] as $val => $label ) : ?>
										<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $aff->audience_size ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td></tr>
							<tr><th>Promotion plan</th><td><textarea name="promotion_plan" rows="3" class="large-text"><?php echo esc_textarea( (string) $aff->promotion_plan ); ?></textarea></td></tr>
							<tr><th>Internal notes</th><td><textarea name="notes_internal" rows="4" class="large-text" placeholder="Private — visible only to admins"><?php echo esc_textarea( (string) $aff->notes_internal ); ?></textarea></td></tr>
							<tr><th>Partner-facing notes</th><td><textarea name="notes_partner_facing" rows="3" class="large-text" placeholder="Shown to the affiliate in their portal — e.g. payout notes, custom terms"><?php echo esc_textarea( (string) $aff->notes_partner_facing ); ?></textarea></td></tr>
						</table>

						<p style="margin-top:20px;">
							<button type="submit" class="button button-primary button-large" style="background:#06D6A0;border-color:#06D6A0;">Save changes</button>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates' ) ); ?>" class="button">Cancel</a>
						</p>
					</form>
				</div>

				<!-- Side rail -->
				<aside>
					<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px;margin-bottom:14px;">
						<h3 style="margin-top:0;font-size:14px;color:#374151;">Identifiers</h3>
						<div style="font-size:12px;color:#6b7280;margin-bottom:6px;">Public ID (used in <code>?ref=</code>)</div>
						<div style="font-family:ui-monospace,monospace;font-size:13px;background:#f9fafb;padding:6px 10px;border-radius:4px;margin-bottom:14px;word-break:break-all;"><?php echo esc_html( $aff->public_id ); ?></div>

						<div style="font-size:12px;color:#6b7280;margin-bottom:6px;">Tracking URL</div>
						<?php $url = add_query_arg( 'ref', $aff->public_id, home_url( '/' ) ); ?>
						<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener" style="font-family:ui-monospace,monospace;font-size:11px;background:#f9fafb;padding:6px 10px;border-radius:4px;display:block;word-break:break-all;text-decoration:none;color:#06D6A0;"><?php echo esc_html( $url ); ?></a>
					</div>

					<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px;margin-bottom:14px;">
						<h3 style="margin-top:0;font-size:14px;color:#374151;">Actions</h3>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:8px;">
							<?php wp_nonce_field( 'asteris_aff_resend_welcome_' . $id ); ?>
							<input type="hidden" name="action" value="asteris_aff_resend_welcome">
							<input type="hidden" name="id" value="<?php echo (int) $id; ?>">
							<button type="submit" class="button" style="width:100%;" <?php echo $aff->status !== 'approved' ? 'disabled title="Only sends to approved affiliates"' : ''; ?>>📧 Resend welcome email</button>
						</form>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('PERMANENTLY delete this affiliate? Referrals + commissions stay in the DB but the affiliate row is gone. Use Suspend instead if unsure.');">
							<?php wp_nonce_field( 'asteris_aff_delete_' . $id ); ?>
							<input type="hidden" name="action" value="asteris_aff_delete">
							<input type="hidden" name="id" value="<?php echo (int) $id; ?>">
							<button type="submit" class="button button-link-delete" style="width:100%;color:#b32d2e;">Delete affiliate</button>
						</form>
					</div>

					<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px;">
						<h3 style="margin-top:0;font-size:14px;color:#374151;">Timestamps</h3>
						<table style="font-size:12px;color:#6b7280;">
							<tr><td style="padding:3px 0;">Applied</td><td style="padding:3px 0 3px 12px;font-family:ui-monospace,monospace;"><?php echo esc_html( $aff->applied_at ); ?></td></tr>
							<tr><td style="padding:3px 0;">Approved</td><td style="padding:3px 0 3px 12px;font-family:ui-monospace,monospace;"><?php echo esc_html( $aff->approved_at ?? '—' ); ?></td></tr>
							<tr><td style="padding:3px 0;">Last login</td><td style="padding:3px 0 3px 12px;font-family:ui-monospace,monospace;"><?php echo esc_html( $aff->last_login_at ?? '—' ); ?></td></tr>
							<tr><td style="padding:3px 0;">Updated</td><td style="padding:3px 0 3px 12px;font-family:ui-monospace,monospace;"><?php echo esc_html( $aff->updated_at ); ?></td></tr>
						</table>
					</div>
				</aside>
			</div>

			<!-- Per-affiliate commission list (P1 fix Sprint 6) -->
			<?php
			$commissions = $wpdb->get_results( $wpdb->prepare(
				"SELECT id, order_id, amount_cents, currency, rate_bp, rate_year, status, attribution_type, coupon_code, created_at, refund_window_ends, paid_at
				 FROM {$p}aff_commissions
				 WHERE affiliate_id = %d
				 ORDER BY id DESC
				 LIMIT 50",
				$id
			) );
			?>
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px 22px;margin-top:18px;">
				<h2 style="margin-top:0;">Commissions <span style="color:#999;font-size:13px;font-weight:400;">(latest 50)</span></h2>
				<?php if ( ! $commissions ) : ?>
					<p style="color:#999;margin:8px 0 0;">No commissions yet for this affiliate.</p>
				<?php else : ?>
					<table class="widefat striped" style="font-size:12px;">
						<thead><tr>
							<th>ID</th><th>Order</th><th>Source</th><th>Rate</th>
							<th>Amount</th><th>Status</th><th>Refund window</th><th>Created</th><th>Paid</th>
						</tr></thead>
						<tbody>
						<?php foreach ( $commissions as $c ) :
							$st_clr = [ 'pending' => '#ea580c', 'approved' => '#059669', 'paid' => '#06D6A0', 'refunded' => '#b45309', 'rejected' => '#6b7280' ][ $c->status ] ?? '#6b7280';
						?>
							<tr>
								<td>#<?php echo (int) $c->id; ?></td>
								<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $c->order_id . '&action=edit' ) ); ?>">#<?php echo (int) $c->order_id; ?></a></td>
								<td><?php echo esc_html( $c->attribution_type ); ?><?php if ( $c->coupon_code ) : ?><div style="font-size:10px;color:#999;font-family:ui-monospace,monospace;"><?php echo esc_html( $c->coupon_code ); ?></div><?php endif; ?></td>
								<td><?php echo number_format( $c->rate_bp / 100, 1 ); ?>% <span style="color:#999;font-size:10px;">Y<?php echo (int) $c->rate_year; ?></span></td>
								<td><strong><?php echo esc_html( \AsterisAffiliates\Core\Currencies::symbol( $c->currency ) ); ?><?php echo esc_html( number_format( $c->amount_cents / 100, 2 ) ); ?></strong> <span style="color:#999;font-size:10px;"><?php echo esc_html( $c->currency ); ?></span></td>
								<td><span style="background:<?php echo esc_attr( $st_clr ); ?>;color:#fff;padding:1px 6px;border-radius:8px;font-size:9px;font-weight:700;text-transform:uppercase;"><?php echo esc_html( $c->status ); ?></span></td>
								<td style="font-family:ui-monospace,monospace;font-size:10px;color:#666;"><?php echo esc_html( $c->refund_window_ends ); ?></td>
								<td style="font-family:ui-monospace,monospace;font-size:10px;color:#666;"><?php echo esc_html( $c->created_at ); ?></td>
								<td style="font-family:ui-monospace,monospace;font-size:10px;color:#666;"><?php echo esc_html( $c->paid_at ?? '—' ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

			<?php if ( $activity ) : ?>
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px 22px;margin-top:18px;">
					<h2 style="margin-top:0;">Recent activity</h2>
					<table class="widefat striped" style="font-size:12px;">
						<thead><tr><th style="width:170px;">When (UTC)</th><th style="width:240px;">Event</th><th style="width:140px;">Actor</th><th>Detail</th></tr></thead>
						<tbody>
							<?php foreach ( $activity as $e ) : ?>
								<tr>
									<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( $e->occurred_at ); ?></td>
									<td><code style="font-size:11px;"><?php echo esc_html( $e->event_type ); ?></code></td>
									<td style="font-size:11px;color:#666;"><?php echo esc_html( $e->actor ); ?></td>
									<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;word-break:break-all;"><?php echo esc_html( (string) $e->payload ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ── Handlers ────────────────────────────────────────────────────────────

	public static function handle_save(): void {
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		check_admin_referer( 'asteris_aff_save_detail_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=not_found' ) );
			exit;
		}

		// Validate
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$display_name = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
		if ( ! is_email( $email ) || $display_name === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=invalid&extra=' . urlencode( 'Display name + valid email required.' ) ) );
			exit;
		}
		// Dup-email check (allow if it's still the same affiliate)
		$existing = Affiliate_Repository::find_by_email( $email );
		if ( $existing && (int) $existing->id !== $id ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=invalid&extra=' . urlencode( 'Another affiliate already uses that email.' ) ) );
			exit;
		}

		// Public ID — format-validate + uniqueness check.
		// Falls back to the existing value if the field is missing (shouldn't
		// happen via the form but be defensive against direct POSTs).
		$public_id_raw = isset( $_POST['public_id'] ) ? (string) wp_unslash( $_POST['public_id'] ) : $aff->public_id;
		$public_id     = Affiliate_Repository::sanitise_public_id( $public_id_raw );
		if ( $public_id === null ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=invalid&extra=' . urlencode( 'Public ID must be 3–48 lower-case letters / numbers / hyphens, with no leading or trailing hyphen.' ) ) );
			exit;
		}
		if ( ! Affiliate_Repository::is_public_id_available( $public_id, $id ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=invalid&extra=' . urlencode( 'Public ID "' . $public_id . '" is already used by another affiliate. Pick a different one.' ) ) );
			exit;
		}

		$new_status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : $aff->status;
		$valid_statuses = [ 'pending', 'approved', 'suspended', 'rejected', 'terminated' ];
		if ( ! in_array( $new_status, $valid_statuses, true ) ) {
			$new_status = $aff->status;
		}

		$now = current_time( 'mysql', true );
		$update = [
			'public_id'                 => $public_id,
			'display_name'              => $display_name,
			'first_name'                => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : null,
			'last_name'                 => isset( $_POST['last_name'] )  ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) )  : null,
			'email'                     => $email,
			'country_code'              => isset( $_POST['country_code'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['country_code'] ) ) ) : $aff->country_code,
			'status'                    => $new_status,
			'commission_rate_y1_bp'     => isset( $_POST['commission_rate_y1_bp'] )     ? max( 0, min( 10000, (int) $_POST['commission_rate_y1_bp'] ) )     : $aff->commission_rate_y1_bp,
			'commission_rate_y2plus_bp' => isset( $_POST['commission_rate_y2plus_bp'] ) ? max( 0, min( 10000, (int) $_POST['commission_rate_y2plus_bp'] ) ) : $aff->commission_rate_y2plus_bp,
			'custom_rate_override_bp'   => ( isset( $_POST['custom_rate_override_bp'] ) && $_POST['custom_rate_override_bp'] !== '' ) ? max( 0, min( 10000, (int) $_POST['custom_rate_override_bp'] ) ) : null,
			'payout_method'             => isset( $_POST['payout_method'] ) ? sanitize_key( wp_unslash( $_POST['payout_method'] ) ) : $aff->payout_method,
			'paypal_email'              => isset( $_POST['paypal_email'] ) ? sanitize_email( wp_unslash( $_POST['paypal_email'] ) ) : null,
			'audience_size'             => isset( $_POST['audience_size'] )       ? sanitize_text_field( wp_unslash( $_POST['audience_size'] ) ) : null,
			'promotion_plan'            => isset( $_POST['promotion_plan'] )      ? sanitize_textarea_field( wp_unslash( $_POST['promotion_plan'] ) ) : null,
			'notes_internal'            => isset( $_POST['notes_internal'] )      ? sanitize_textarea_field( wp_unslash( $_POST['notes_internal'] ) ) : null,
			'notes_partner_facing'      => isset( $_POST['notes_partner_facing'] )? sanitize_textarea_field( wp_unslash( $_POST['notes_partner_facing'] ) ) : null,
			// v1.1.3 — MLM
			'parent_affiliate_id'       => ( isset( $_POST['parent_affiliate_id'] ) && (int) $_POST['parent_affiliate_id'] > 0 && (int) $_POST['parent_affiliate_id'] !== $id ) ? (int) $_POST['parent_affiliate_id'] : null,
			'tier2_rate_bp'             => isset( $_POST['tier2_rate_bp'] ) ? max( 0, min( 10000, (int) $_POST['tier2_rate_bp'] ) ) : 500,
		];
		// Set approved_at if transitioning into approved
		if ( $aff->status !== 'approved' && $new_status === 'approved' ) {
			$update['approved_at'] = $now;
		}
		if ( $aff->status !== 'suspended' && $new_status === 'suspended' ) {
			$update['suspended_at'] = $now;
		}
		if ( $aff->status !== 'terminated' && $new_status === 'terminated' ) {
			$update['terminated_at'] = $now;
		}

		Affiliate_Repository::update( $id, $update );

		// Log changed fields for the activity feed (only the meaningful ones —
		// avoids logging timestamp updates as "changes")
		$diff = [];
		foreach ( [ 'public_id', 'display_name', 'email', 'status', 'commission_rate_y1_bp', 'commission_rate_y2plus_bp', 'custom_rate_override_bp', 'payout_method' ] as $field ) {
			if ( (string) $update[ $field ] !== (string) $aff->{$field} ) {
				$diff[ $field ] = [ 'from' => $aff->{$field}, 'to' => $update[ $field ] ];
			}
		}
		if ( $diff !== [] ) {
			global $wpdb;
			$wpdb->insert( $wpdb->prefix . 'aff_events', [
				'occurred_at'  => $now,
				'event_type'   => 'affiliate.edited',
				'affiliate_id' => $id,
				'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
				'payload'      => wp_json_encode( $diff ),
			] );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=saved' ) );
		exit;
	}

	public static function handle_delete(): void {
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		check_admin_referer( 'asteris_aff_delete_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=not_found' ) );
			exit;
		}

		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'aff_affiliates', [ 'id' => $id ] );
		// Referrals + commissions intentionally NOT deleted — they're historical
		// records that may still need to settle (refund-window, paid-out audit).
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'affiliate.deleted',
			'affiliate_id' => $id,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'email' => $aff->email, 'display_name' => $aff->display_name ] ),
		] );

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=deleted' ) );
		exit;
	}

	public static function handle_resend_welcome(): void {
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		check_admin_referer( 'asteris_aff_resend_welcome_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff || $aff->status !== 'approved' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=not_approved' ) );
			exit;
		}
		wp_mail(
			$aff->email,
			'You\'re in — sign in to your affiliate portal',
			"Hi {$aff->display_name},\n\nSign in to your portal:\n" . home_url( '/affiliate-portal/' ) . "\n"
		);
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&id=' . $id . '&flash=welcome_resent' ) );
		exit;
	}

	// ── Flash messages ──────────────────────────────────────────────────────

	private static function render_flash( string $flash, string $extra ): void {
		$map = [
			'saved'           => [ 'ok',   '✓ Saved.' ],
			'invalid'         => [ 'err',  '✗ ' . esc_html( $extra ) ],
			'welcome_resent'  => [ 'ok',   '✓ Welcome email resent.' ],
			'not_approved'    => [ 'err',  '✗ Welcome emails only send to approved affiliates.' ],
			'created_manually'=> [ 'ok',   '✓ Affiliate created.' ],
		];
		if ( ! isset( $map[ $flash ] ) ) { return; }
		[ $kind, $html ] = $map[ $flash ];
		$style = $kind === 'ok'
			? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;';
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . $html . '</p></div>'; // phpcs:ignore
	}
}
