<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Coupons\Code_Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Admin UI to map WC coupons → affiliates.
 *
 * Flow:
 *   1. Create the coupon in WC → Coupons (standard WC UI).
 *   2. Come here, pick the affiliate, paste the coupon code, click Assign.
 *   3. From that moment, any order using that coupon attributes to that
 *      affiliate (subject to Settings::attribution_priority).
 */
final class Page_Coupons {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_coupon_assign', [ self::class, 'handle_assign' ] );
		add_action( 'admin_post_asteris_aff_coupon_revoke', [ self::class, 'handle_revoke' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$flash = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$extra = isset( $_GET['extra'] ) ? sanitize_text_field( wp_unslash( $_GET['extra'] ) ) : '';
		$mappings = Code_Manager::list_all();
		$affiliates = Affiliate_Repository::list( [ 'status' => 'approved', 'limit' => 200 ] );
		?>
		<div class="wrap">
			<h1>Coupons</h1>
			<p style="color:#666;max-width:780px;">Assign existing WC coupons to affiliates. Any order using one of these coupons credits the assigned affiliate — even with no link click. Useful for podcasts, YouTube, in-person events.</p>
			<?php self::render_flash( $flash, $extra ); ?>

			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-top:14px;max-width:680px;">
				<h2 style="margin-top:0;">Assign a coupon</h2>
				<p style="color:#666;font-size:13px;margin:0 0 14px;">Coupon must already exist in <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=shop_coupon' ) ); ?>" target="_blank">WC → Coupons</a>.</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'asteris_aff_coupon_assign' ); ?>
					<input type="hidden" name="action" value="asteris_aff_coupon_assign">
					<table class="form-table" role="presentation">
						<tr>
							<th>Affiliate *</th>
							<td>
								<select name="affiliate_id" required class="regular-text" style="max-width:380px;">
									<option value="">— pick affiliate —</option>
									<?php foreach ( $affiliates as $a ) : ?>
										<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->display_name . ' · ' . $a->email ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th>Coupon code *</th>
							<td><input type="text" name="coupon_code" required maxlength="64" placeholder="e.g. ALEX25" class="regular-text" style="text-transform:uppercase;font-family:ui-monospace,monospace;"></td>
						</tr>
					</table>
					<p><button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;">Assign</button></p>
				</form>
			</div>

			<h2 style="margin-top:28px;">Active mappings</h2>
			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th>Coupon code</th><th>Affiliate</th><th>Email</th><th>Assigned</th><th>Actions</th>
				</tr></thead>
				<tbody>
				<?php if ( ! $mappings ) : ?>
					<tr><td colspan="5" style="text-align:center;padding:30px;color:#999;">No coupon mappings yet.</td></tr>
				<?php else : foreach ( $mappings as $m ) : ?>
					<tr>
						<td><code style="font-family:ui-monospace,monospace;font-size:13px;background:#f3f4f6;padding:3px 8px;border-radius:4px;"><?php echo esc_html( $m->coupon_code ); ?></code></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $m->affiliate_id ) ); ?>" style="color:#06D6A0;font-weight:600;"><?php echo esc_html( $m->affiliate_name ?? '?' ); ?></a></td>
						<td style="color:#666;font-size:12px;"><?php echo esc_html( $m->affiliate_email ?? '' ); ?></td>
						<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( $m->assigned_at ); ?></td>
						<td>
							<?php $url = wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_coupon_revoke&id=' . (int) $m->id ), 'asteris_aff_coupon_revoke_' . (int) $m->id ); ?>
							<a href="<?php echo esc_url( $url ); ?>" class="button button-small" onclick="return confirm('Revoke this mapping? Existing commissions stay, but new orders won\'t credit the affiliate.');" style="color:#b32d2e;">Revoke</a>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function handle_assign(): void {
		check_admin_referer( 'asteris_aff_coupon_assign' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$affiliate_id = isset( $_POST['affiliate_id'] ) ? (int) $_POST['affiliate_id'] : 0;
		$code         = isset( $_POST['coupon_code'] )  ? sanitize_text_field( wp_unslash( $_POST['coupon_code'] ) ) : '';

		if ( ! $affiliate_id || $code === '' ) {
			self::redirect( 'invalid', 'Both fields required.' );
		}
		$res = Code_Manager::assign( $affiliate_id, $code );
		if ( is_wp_error( $res ) ) {
			self::redirect( 'invalid', $res->get_error_message() );
		}
		self::redirect( 'assigned' );
	}

	public static function handle_revoke(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_coupon_revoke_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		Code_Manager::revoke( $id );
		self::redirect( 'revoked' );
	}

	private static function redirect( string $flash, string $extra = '' ): void {
		wp_safe_redirect( add_query_arg( [
			'page' => 'asteris-affiliates-coupons', 'flash' => $flash, 'extra' => $extra,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function render_flash( string $flash, string $extra ): void {
		$map = [
			'assigned' => [ 'ok',  '✓ Coupon assigned.' ],
			'revoked'  => [ 'warn','⚠ Coupon mapping revoked.' ],
			'invalid'  => [ 'err', '✗ ' . esc_html( $extra ) ],
		];
		if ( ! isset( $map[ $flash ] ) ) { return; }
		[ $kind, $html ] = $map[ $flash ];
		$style = match ( $kind ) {
			'ok'   => 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;',
			'warn' => 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;',
			default => 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;',
		};
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . $html . '</p></div>'; // phpcs:ignore
	}
}
