<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Free_Tier;

defined( 'ABSPATH' ) || exit;

/**
 * License admin page.
 *
 * Always rendered inside Affiliates admin (not deep-linked to the Installer)
 * so customers can always see + manage their licence key from the same place
 * they manage affiliates. Shows:
 *
 *   - Current status (Active / Expired / Invalid / Not activated)
 *   - Current tier (Free / Starter / Pro / Agency / Founder)
 *   - License key field (masked when active, raw input when entering)
 *   - Activate / Deactivate buttons
 *   - Asteris Installer cross-link (if installed) for multi-plugin licence mgmt
 *
 * v1.2.3.
 */
final class Page_License {

	public const SLUG       = 'asteris-affiliates-license';
	public const OPT_KEY    = 'asteris_aff_license_key';
	public const PRODUCT_ID = 'asteris_affiliates';

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_activate_license',   [ self::class, 'handle_activate' ] );
		add_action( 'admin_post_asteris_aff_deactivate_license', [ self::class, 'handle_deactivate' ] );
		add_action( 'admin_post_asteris_aff_revalidate_license', [ self::class, 'handle_revalidate' ] );
	}

	/** Return the Client instance, defensively guarded against the cross-plugin Client collision. */
	private static function client(): ?\AsterisShared\License\Client {
		if ( ! class_exists( '\\AsterisShared\\License\\Client' ) ) { return null; }
		if ( ! method_exists( '\\AsterisShared\\License\\Client', 'for_product' ) ) { return null; }
		return \AsterisShared\License\Client::for_product( self::PRODUCT_ID, self::OPT_KEY );
	}

	/** Friendly label for the current tier. */
	private static function tier_label( ?string $plan, string $status ): array {
		if ( $status !== 'active' ) {
			return [ 'label' => 'Free', 'colour' => '#64748b', 'bg' => '#f1f5f9' ];
		}
		$plan = strtolower( (string) $plan );
		switch ( $plan ) {
			case 'agency':  return [ 'label' => 'Agency',  'colour' => '#1d4ed8', 'bg' => '#dbeafe' ];
			case 'pro':     return [ 'label' => 'Pro',     'colour' => '#7c2d12', 'bg' => '#ffedd5' ];
			case 'starter': return [ 'label' => 'Starter', 'colour' => '#166534', 'bg' => '#dcfce7' ];
			case 'founder': return [ 'label' => 'Founder', 'colour' => '#9333ea', 'bg' => '#f3e8ff' ];
			default:        return [ 'label' => 'Pro (active)', 'colour' => '#166534', 'bg' => '#dcfce7' ];
		}
	}

	private static function status_label( string $status ): array {
		switch ( $status ) {
			case 'active':   return [ 'label' => '✓ Active',          'colour' => '#06D6A0', 'bg' => '#dcfce7', 'fg' => '#166534' ];
			case 'expired':  return [ 'label' => '⚠ Expired',         'colour' => '#d97706', 'bg' => '#fef3c7', 'fg' => '#92400e' ];
			case 'invalid':  return [ 'label' => '✗ Invalid key',     'colour' => '#dc2626', 'bg' => '#fee2e2', 'fg' => '#991b1b' ];
			case 'unset':    return [ 'label' => '○ Not activated',    'colour' => '#64748b', 'bg' => '#f1f5f9', 'fg' => '#475569' ];
			case 'unknown':
			default:         return [ 'label' => '? Status unknown',   'colour' => '#64748b', 'bg' => '#f1f5f9', 'fg' => '#475569' ];
		}
	}

	private static function masked_key( string $key ): string {
		$len = strlen( $key );
		if ( $len <= 8 ) { return str_repeat( '•', $len ); }
		return substr( $key, 0, 4 ) . str_repeat( '•', max( 4, $len - 8 ) ) . substr( $key, -4 );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$client       = self::client();
		$key          = $client ? $client->key() : '';
		$state        = $client ? $client->get_state() : [];
		$status       = $client ? $client->status() : 'unset';
		$plan         = $state['plan']            ?? null;
		$expires_at   = $state['expires_at']      ?? null;
		$last_checked = $state['last_checked_at'] ?? null;
		$tier         = self::tier_label( $plan, $status );
		$st           = self::status_label( $status );
		$installer    = Menu::installer_active();
		$flash        = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$flash_msg    = isset( $_GET['msg'] )   ? sanitize_text_field( wp_unslash( $_GET['msg'] ) ) : '';
		?>
		<div class="wrap" style="max-width:920px;">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<span style="color:#06D6A0;font-size:28px;line-height:1;">🔑</span>
				Asteris Affiliates · License
			</h1>

			<?php if ( $flash === 'activated' ) : ?>
				<div class="notice notice-success is-dismissible" style="margin-top:14px;"><p><strong>Licence activated.</strong> Pro features are now unlocked on this site.</p></div>
			<?php elseif ( $flash === 'deactivated' ) : ?>
				<div class="notice notice-warning is-dismissible" style="margin-top:14px;"><p>Licence deactivated on this site. Pro features are now disabled. The plugin keeps working on the free tier.</p></div>
			<?php elseif ( $flash === 'revalidated' ) : ?>
				<div class="notice notice-info is-dismissible" style="margin-top:14px;"><p>Re-checked licence against the server. Current status: <strong><?php echo esc_html( $st['label'] ); ?></strong>.</p></div>
			<?php elseif ( $flash === 'failed' ) : ?>
				<div class="notice notice-error is-dismissible" style="margin-top:14px;"><p><strong>Activation failed:</strong> <?php echo esc_html( $flash_msg ?: 'Unknown error.' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! $client ) : ?>
				<div class="notice notice-error" style="margin-top:14px;"><p><strong>Licence client unavailable.</strong> The shared <code>AsterisShared\License\Client</code> module didn't load (likely a sister-plugin version mismatch). Functioning on free tier. v1.2.1+ guards against this gracefully.</p></div>
			<?php endif; ?>

			<!-- Status cards -->
			<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:18px;">
				<!-- Status -->
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px 20px;">
					<div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:0.06em;">Licence status</div>
					<div style="margin-top:8px;display:inline-block;background:<?php echo esc_attr( $st['bg'] ); ?>;color:<?php echo esc_attr( $st['fg'] ); ?>;font-weight:700;padding:6px 14px;border-radius:999px;font-size:14px;">
						<?php echo esc_html( $st['label'] ); ?>
					</div>
				</div>

				<!-- Tier -->
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px 20px;">
					<div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:0.06em;">Current tier</div>
					<div style="margin-top:8px;display:inline-block;background:<?php echo esc_attr( $tier['bg'] ); ?>;color:<?php echo esc_attr( $tier['colour'] ); ?>;font-weight:700;padding:6px 14px;border-radius:999px;font-size:14px;">
						<?php echo esc_html( $tier['label'] ); ?>
					</div>
				</div>

				<!-- Installer -->
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px 20px;">
					<div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;letter-spacing:0.06em;">Asteris Installer</div>
					<div style="margin-top:8px;display:inline-block;background:<?php echo $installer ? '#dcfce7' : '#f1f5f9'; ?>;color:<?php echo $installer ? '#166534' : '#475569'; ?>;font-weight:700;padding:6px 14px;border-radius:999px;font-size:14px;">
						<?php echo $installer ? '✓ Installed' : '○ Not installed'; ?>
					</div>
				</div>
			</div>

			<!-- Key entry form -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px 28px;margin-top:18px;">
				<h2 style="font-size:17px;margin:0 0 6px;">Licence key</h2>
				<p style="font-size:13.5px;color:#64748b;margin:0 0 18px;line-height:1.55;">
					Paste your licence key from <a href="https://pay.asteriscommerce.com/account" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;">pay.asteriscommerce.com/account</a>. Activation contacts the licence server and unlocks Pro features here.
				</p>

				<?php if ( $key !== '' && $status === 'active' ) : ?>
					<!-- Active state — show masked key + Deactivate button -->
					<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:#f8fafc;border:1px solid #e5e7eb;border-radius:6px;padding:14px 18px;">
						<div style="flex:1;min-width:240px;">
							<div style="font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:4px;">Active key</div>
							<code style="font-family:ui-monospace,monospace;font-size:15px;color:#0a0a0a;background:transparent;padding:0;letter-spacing:0.04em;"><?php echo esc_html( self::masked_key( $key ) ); ?></code>
						</div>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0;">
							<?php wp_nonce_field( 'asteris_aff_revalidate_license', '_aff_license_nonce' ); ?>
							<input type="hidden" name="action" value="asteris_aff_revalidate_license">
							<button type="submit" class="button">Re-check status</button>
						</form>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0;" onsubmit="return confirm('Deactivate this licence on this site? Pro features will be disabled until you re-activate.');">
							<?php wp_nonce_field( 'asteris_aff_deactivate_license', '_aff_license_nonce' ); ?>
							<input type="hidden" name="action" value="asteris_aff_deactivate_license">
							<button type="submit" class="button" style="color:#b91c1c;">Deactivate on this site</button>
						</form>
					</div>

					<?php if ( $expires_at ) : ?>
						<p style="font-size:13px;color:#64748b;margin:14px 0 0;">
							Subscription renews <?php echo esc_html( gmdate( 'j M Y', (int) strtotime( $expires_at ) ) ); ?>.
							<?php if ( $last_checked ) : ?>
								Last checked: <?php echo esc_html( human_time_diff( (int) strtotime( $last_checked ), time() ) ); ?> ago.
							<?php endif; ?>
						</p>
					<?php endif; ?>

				<?php else : ?>
					<!-- Inactive / unset state — show input field + Activate button -->
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
						<?php wp_nonce_field( 'asteris_aff_activate_license', '_aff_license_nonce' ); ?>
						<input type="hidden" name="action" value="asteris_aff_activate_license">
						<div style="flex:1;min-width:300px;">
							<label for="aff_license_key" style="display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px;">License key</label>
							<input
								type="text"
								id="aff_license_key"
								name="license_key"
								value="<?php echo esc_attr( $key ); ?>"
								placeholder="e.g. A1B2-C3D4-E5F6-G7H8-I9J0-K1L2"
								autocomplete="off"
								spellcheck="false"
								style="width:100%;padding:10px 14px;font-family:ui-monospace,monospace;font-size:14.5px;border:1px solid #cbd5e1;border-radius:6px;letter-spacing:0.04em;"
								required
							>
						</div>
						<div>
							<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;padding:8px 22px;font-weight:600;height:auto;">Activate</button>
						</div>
					</form>

					<?php if ( $status === 'expired' ) : ?>
						<p style="margin:14px 0 0;padding:12px 14px;background:#fef3c7;border-left:3px solid #d97706;border-radius:4px;font-size:13.5px;color:#92400e;">
							Your licence expired. Renew at <a href="https://pay.asteriscommerce.com/account" target="_blank" rel="noopener" style="color:#92400e;font-weight:700;">pay.asteriscommerce.com/account</a> and re-activate above.
						</p>
					<?php elseif ( $status === 'invalid' ) : ?>
						<p style="margin:14px 0 0;padding:12px 14px;background:#fee2e2;border-left:3px solid #dc2626;border-radius:4px;font-size:13.5px;color:#991b1b;">
							The previous key was rejected. Double-check it from <a href="https://pay.asteriscommerce.com/account" target="_blank" rel="noopener" style="color:#991b1b;font-weight:700;">pay.asteriscommerce.com/account</a> — keys are case-sensitive.
						</p>
					<?php endif; ?>

					<p style="margin:18px 0 0;padding:14px 16px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:6px;font-size:13.5px;color:#475569;line-height:1.55;">
						<strong style="color:#0a0a0a;">No paid licence yet?</strong> Asteris Affiliates Free runs without one — up to 25 affiliates, single-tier referrals, manual payouts. <a href="https://asterisaffiliates.com/pricing" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;">See paid pricing →</a>
					</p>
				<?php endif; ?>
			</div>

			<!-- Asteris Installer cross-link -->
			<?php if ( $installer ) : ?>
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:18px 22px;margin-top:18px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
					<div style="flex:1;min-width:280px;">
						<div style="font-weight:700;color:#0a0a0a;">★ Asteris Installer is active on this site</div>
						<div style="font-size:13px;color:#64748b;margin-top:4px;line-height:1.5;">Manage licence keys across all your Asteris plugins (WC, WP, Cart, Affiliates) from one place.</div>
					</div>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-installer' ) ); ?>" class="button">Open Installer →</a>
				</div>
			<?php else : ?>
				<div style="background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:18px 22px;margin-top:18px;">
					<div style="font-weight:700;color:#0a0a0a;">★ Tip — install the Asteris Installer once</div>
					<p style="font-size:13.5px;color:#475569;margin:6px 0 10px;line-height:1.55;">
						The Asteris Installer plugin centralises licence keys for every Asteris product you run. Activate your key once there and it auto-applies across WC, WP, Cart and Affiliates — no per-plugin re-entry.
					</p>
					<a href="https://pay.asteriscommerce.com/account" target="_blank" rel="noopener" class="button">Get the Installer →</a>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function handle_activate(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		check_admin_referer( 'asteris_aff_activate_license', '_aff_license_nonce' );

		$key    = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$client = self::client();

		if ( ! $client ) {
			self::redirect( 'failed', 'Licence client unavailable on this site.' );
		}

		$res = $client->activate( $key );

		// Clear cached is_pro() so the next page load reflects the new state.
		Free_Tier::set_pro_override( null );

		if ( ! empty( $res['ok'] ) ) {
			self::redirect( 'activated' );
		}
		self::redirect( 'failed', $res['message'] ?? 'Activation failed.' );
	}

	public static function handle_deactivate(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		check_admin_referer( 'asteris_aff_deactivate_license', '_aff_license_nonce' );

		$client = self::client();
		if ( $client ) {
			$client->deactivate();
		}
		Free_Tier::set_pro_override( null );
		self::redirect( 'deactivated' );
	}

	public static function handle_revalidate(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		check_admin_referer( 'asteris_aff_revalidate_license', '_aff_license_nonce' );

		$client = self::client();
		if ( $client ) {
			$client->validate();
		}
		Free_Tier::set_pro_override( null );
		self::redirect( 'revalidated' );
	}

	private static function redirect( string $flash, string $msg = '' ): void {
		$args = [ 'page' => self::SLUG, 'flash' => $flash ];
		if ( $msg !== '' ) { $args['msg'] = rawurlencode( $msg ); }
		wp_safe_redirect( admin_url( 'admin.php?' . http_build_query( $args ) ) );
		exit;
	}
}
