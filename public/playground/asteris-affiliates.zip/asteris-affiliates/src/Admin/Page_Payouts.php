<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Payouts\Batch_Cron;
use AsterisAffiliates\Payouts\Payout_Repository;
use AsterisAffiliates\Payouts\Stripe_Connect;

defined( 'ABSPATH' ) || exit;

/**
 * Admin payouts management:
 *   - Stat cards (pending count + total, paid count + total)
 *   - Force-run batch button
 *   - Stripe configuration status
 *   - Filter pills (pending / processing / paid / failed)
 *   - List view per payout row with per-method action:
 *       Stripe → "Pay now" (fires transfer API)
 *       PayPal → "Mark paid" form (paste txn ID)
 *       Bank   → "Mark paid" form (paste bank reference)
 *       Failed → "Retry as manual" form
 */
final class Page_Payouts {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_payout_force_batch', [ self::class, 'handle_force_batch' ] );
		add_action( 'admin_post_asteris_aff_payout_stripe',      [ self::class, 'handle_stripe_pay' ] );
		add_action( 'admin_post_asteris_aff_payout_mark_paid',   [ self::class, 'handle_mark_paid' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$flash  = isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '';
		$extra  = isset( $_GET['extra'] ) ? sanitize_text_field( wp_unslash( $_GET['extra'] ) ) : '';
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$counts = Payout_Repository::counts_by_status();
		$rows   = Payout_Repository::list( $status !== '' ? $status : null );

		global $wpdb;
		$p = $wpdb->prefix;
		$pending_cents = (int) $wpdb->get_var( "SELECT COALESCE(SUM(total_cents),0) FROM {$p}aff_payouts WHERE status IN ('pending','processing')" );
		$paid_cents    = (int) $wpdb->get_var( "SELECT COALESCE(SUM(total_cents),0) FROM {$p}aff_payouts WHERE status = 'paid'" );

		$stripe_configured = Stripe_Connect::is_configured();
		// Add CSV export button to page header
		add_action( 'admin_notices', static function () {
			echo '<div class="aff-csv-bar" style="margin:8px 0;text-align:right;">' . CSV_Export::button( 'asteris_aff_export_payouts' ) . '</div>'; // phpcs:ignore
		} );
		?>
		<div class="wrap">
			<h1>Payouts
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-left:14px;" onsubmit="return confirm('Force-create a payout batch NOW for every affiliate with approved balance ≥ minimum threshold? This will INCLUDE Stripe auto-transfers if a key is configured. Are you sure?');">
					<?php wp_nonce_field( 'asteris_aff_payout_force_batch' ); ?>
					<input type="hidden" name="action" value="asteris_aff_payout_force_batch">
					<button type="submit" class="page-title-action" style="background:#06D6A0;border-color:#06D6A0;color:#fff;">⚡ Force-run batch now</button>
				</form>
			</h1>
			<p style="color:#666;max-width:780px;">Monthly batch runs automatically on day <?php echo (int) \AsterisAffiliates\Core\Settings::get( 'payout_day_of_month', 1 ); ?>. Force-run is for testing or off-cycle payouts.</p>

			<?php self::render_flash( $flash, $extra ); ?>

			<!-- Stripe configuration banner -->
			<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo $stripe_configured ? '#06D6A0' : '#ea580c'; ?>;border-radius:6px;padding:12px 16px;margin:14px 0;">
				<?php if ( $stripe_configured ) : ?>
					<strong style="color:#059669;">✓ Stripe is configured.</strong> Stripe-method payouts auto-execute in the batch run.
				<?php else : ?>
					<strong style="color:#ea580c;">⚠ Stripe is NOT configured.</strong> Stripe-method payouts will be created as "pending" only — you'll need to mark them paid manually.
					<details style="margin-top:8px;">
						<summary style="cursor:pointer;font-size:13px;color:#666;">How to configure Stripe</summary>
						<p style="margin:8px 0 0;font-size:13px;color:#666;">Three options (first one we find is used):</p>
						<ol style="font-size:13px;color:#666;margin:6px 0 0 20px;">
							<li>Add <code>define( 'ASTERIS_AFFILIATES_STRIPE_SECRET', 'sk_live_xxx' );</code> to <code>wp-config.php</code></li>
							<li>Save it in Affiliates → Settings (Sprint 6 — UI coming)</li>
							<li>Install the official <strong>WC Stripe Gateway</strong> with credentials — we'll auto-detect it</li>
						</ol>
					</details>
				<?php endif; ?>
			</div>

			<!-- Stat strip -->
			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:14px 0;">
				<?php foreach ( [
					[ 'Pending payouts',  number_format_i18n( $counts['pending'] + $counts['processing'] ), '#ea580c' ],
					[ 'Pending total',    '$' . number_format( $pending_cents / 100, 2 ), '#ea580c' ],
					[ 'Paid this lifetime', number_format_i18n( $counts['paid'] ), '#059669' ],
					[ 'Paid total',       '$' . number_format( $paid_cents / 100, 2 ),    '#06D6A0' ],
					[ 'Failed',           number_format_i18n( $counts['failed'] ),        '#dc2626' ],
				] as $c ) : [ $l, $v, $clr ] = $c; ?>
					<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo esc_attr( $clr ); ?>;border-radius:8px;padding:14px 16px;">
						<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $l ); ?></div>
						<div style="font-size:22px;color:#0a0a0a;font-weight:800;margin-top:2px;"><?php echo esc_html( $v ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<!-- Filter pills -->
			<p style="margin:14px 0;">
				<?php foreach ( [ '' => 'All', 'pending' => 'Pending', 'processing' => 'Processing', 'paid' => 'Paid', 'failed' => 'Failed' ] as $f => $label ) :
					$url = $f === '' ? admin_url( 'admin.php?page=asteris-affiliates-payouts' ) : admin_url( 'admin.php?page=asteris-affiliates-payouts&status=' . $f );
					$active = $status === $f;
				?>
					<a href="<?php echo esc_url( $url ); ?>" class="button button-small" style="<?php echo $active ? 'background:#06D6A0;border-color:#06D6A0;color:#fff;' : ''; ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</p>

			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th>ID</th><th>Batch</th><th>Affiliate</th><th>Method</th><th>Commissions</th><th>Amount</th><th>Status</th><th>Reference</th><th>Requested</th><th>Action</th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="10" style="text-align:center;padding:30px;color:#999;">No payouts match.</td></tr>
				<?php else : foreach ( $rows as $r ) :
					$colour = [ 'pending' => '#ea580c', 'processing' => '#0a857a', 'paid' => '#059669', 'failed' => '#dc2626' ][ $r->status ] ?? '#6b7280';
					$method_label = [ 'stripe_connect' => '🟦 Stripe', 'paypal' => '💸 PayPal', 'bank_transfer' => '🏦 Bank', 'manual' => 'Manual' ][ $r->payout_method ] ?? $r->payout_method;
				?>
					<tr>
						<td>#<?php echo (int) $r->id; ?></td>
						<td><code style="font-size:11px;"><?php echo esc_html( $r->batch_id ); ?></code></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->affiliate_id ) ); ?>" style="color:#06D6A0;font-weight:600;"><?php echo esc_html( $r->aff_name ?? '?' ); ?></a><div style="font-size:11px;color:#999;"><?php echo esc_html( $r->aff_email ?? '' ); ?></div></td>
						<td><?php echo esc_html( $method_label ); ?></td>
						<td><?php echo (int) $r->commission_count; ?></td>
						<td><strong>$<?php echo esc_html( number_format( $r->total_cents / 100, 2 ) ); ?></strong> <span style="color:#999;font-size:11px;"><?php echo esc_html( $r->currency ); ?></span></td>
						<td><span style="background:<?php echo esc_attr( $colour ); ?>;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;"><?php echo esc_html( $r->status ); ?></span></td>
						<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;word-break:break-all;">
							<?php echo esc_html( (string) ( $r->stripe_transfer_id ?: $r->bank_reference ?: $r->failure_reason ?: '—' ) ); ?>
						</td>
						<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( $r->requested_at ); ?></td>
						<td><?php self::render_row_action( $r, $stripe_configured ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function render_row_action( object $r, bool $stripe_configured ): void {
		if ( $r->status === 'paid' ) {
			echo '<span style="color:#059669;">✓ paid</span>';
			return;
		}
		if ( $r->status === 'pending' || $r->status === 'failed' ) {
			if ( $r->payout_method === 'stripe_connect' && $stripe_configured ) {
				// Stripe → one-click "Pay now"
				$url = wp_nonce_url(
					admin_url( 'admin-post.php?action=asteris_aff_payout_stripe&id=' . (int) $r->id ),
					'asteris_aff_payout_stripe_' . (int) $r->id
				);
				echo '<a href="' . esc_url( $url ) . '" class="button button-small" style="background:#06D6A0;border-color:#06D6A0;color:#fff;" onclick="return confirm(\'Send $' . esc_js( number_format( $r->total_cents / 100, 2 ) ) . ' via Stripe Connect now?\');">Pay via Stripe →</a>';
			} else {
				// PayPal / Bank / Stripe-without-key → inline mark-paid form
				$ref_label = $r->payout_method === 'paypal' ? 'PayPal txn ID' : ( $r->payout_method === 'stripe_connect' ? 'Stripe ref' : 'Bank reference' );
				?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;">
					<?php wp_nonce_field( 'asteris_aff_payout_mark_paid_' . (int) $r->id ); ?>
					<input type="hidden" name="action" value="asteris_aff_payout_mark_paid">
					<input type="hidden" name="id" value="<?php echo (int) $r->id; ?>">
					<input type="text" name="reference" required placeholder="<?php echo esc_attr( $ref_label ); ?>" style="font-size:11px;padding:2px 4px;max-width:140px;">
					<button class="button button-small" style="background:#0a857a;border-color:#0a857a;color:#fff;font-size:11px;">Mark paid</button>
				</form>
				<?php
			}
		}
	}

	// ── Handlers ────────────────────────────────────────────────────────────

	public static function handle_force_batch(): void {
		check_admin_referer( 'asteris_aff_payout_force_batch' );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$n = Batch_Cron::run_batch();
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=batch_run&extra=' . urlencode( $n . ' payout(s) created.' ) ) );
		exit;
	}

	public static function handle_stripe_pay(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_payout_stripe_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$payout = Payout_Repository::find( $id );
		if ( ! $payout ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=not_found' ) );
			exit;
		}
		global $wpdb;
		$dest = (string) $wpdb->get_var( $wpdb->prepare(
			"SELECT stripe_connect_account_id FROM {$wpdb->prefix}aff_affiliates WHERE id = %d",
			(int) $payout->affiliate_id
		) );
		if ( $dest === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=stripe_failed&extra=' . urlencode( 'No Stripe Connect account ID on affiliate.' ) ) );
			exit;
		}

		$result = Stripe_Connect::transfer(
			$dest,
			(int) $payout->total_cents,
			(string) $payout->currency,
			'Affiliate payout · manual · ' . $payout->batch_id
		);
		if ( is_wp_error( $result ) ) {
			Payout_Repository::mark_failed( $id, $result->get_error_message() );
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=stripe_failed&extra=' . urlencode( $result->get_error_message() ) ) );
			exit;
		}
		Payout_Repository::mark_paid( $id, (string) $result, 'stripe_transfer_id' );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=stripe_paid&extra=' . urlencode( (string) $result ) ) );
		exit;
	}

	public static function handle_mark_paid(): void {
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		check_admin_referer( 'asteris_aff_payout_mark_paid_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$reference = isset( $_POST['reference'] ) ? sanitize_text_field( wp_unslash( $_POST['reference'] ) ) : '';
		if ( $reference === '' ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=no_ref' ) );
			exit;
		}
		Payout_Repository::mark_paid( $id, $reference );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-payouts&flash=marked_paid' ) );
		exit;
	}

	private static function render_flash( string $flash, string $extra ): void {
		$map = [
			'batch_run'     => [ 'ok',  '✓ Batch run — ' . esc_html( $extra ) ],
			'stripe_paid'   => [ 'ok',  '✓ Paid via Stripe. Transfer ID: ' . esc_html( $extra ) ],
			'stripe_failed' => [ 'err', '✗ Stripe transfer failed: ' . esc_html( $extra ) ],
			'marked_paid'   => [ 'ok',  '✓ Marked paid.' ],
			'no_ref'        => [ 'err', '✗ Reference required.' ],
			'not_found'     => [ 'err', '✗ Payout not found.' ],
		];
		if ( ! isset( $map[ $flash ] ) ) { return; }
		[ $kind, $html ] = $map[ $flash ];
		$style = $kind === 'ok'
			? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;';
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . $html . '</p></div>'; // phpcs:ignore
	}
}
