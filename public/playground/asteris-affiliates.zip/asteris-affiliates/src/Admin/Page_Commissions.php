<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Commissions admin page.
 *
 * Filters: status (pending / approved / paid / refunded / rejected), affiliate.
 * Actions per row: approve early (skip refund window), reject (cancel without paying).
 *
 * Bulk approve / reject buttons land in Sprint 5 alongside the
 * automatic cron that flips pending→approved at refund_window_ends.
 */
final class Page_Commissions {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_commission_approve', [ self::class, 'handle_approve' ] );
		add_action( 'admin_post_asteris_aff_commission_reject',  [ self::class, 'handle_reject' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$flash  = isset( $_GET['flash'] )  ? sanitize_key( wp_unslash( $_GET['flash'] ) )  : '';
		$from   = isset( $_GET['from'] )   ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to     = isset( $_GET['to'] )     ? sanitize_text_field( wp_unslash( $_GET['to'] ) )   : '';

		global $wpdb;
		$prefix = $wpdb->prefix;

		$counts = [
			'pending'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}aff_commissions WHERE status = 'pending'" ),
			'approved' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}aff_commissions WHERE status = 'approved'" ),
			'paid'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}aff_commissions WHERE status = 'paid'" ),
			'refunded' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}aff_commissions WHERE status = 'refunded'" ),
			'rejected' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}aff_commissions WHERE status = 'rejected'" ),
		];
		$total = array_sum( $counts );

		// Column sort (9A)
		$sort_whitelist = [
			'id'         => 'c.id',
			'order_id'   => 'c.order_id',
			'aff_name'   => 'a.display_name',
			'amount'     => 'c.amount_cents',
			'status'     => 'c.status',
			'created_at' => 'c.created_at',
		];
		[ $orderby_sql, $order_sql, $orderby_in, $order_in ] = Sort_Helper::resolve( $sort_whitelist, 'id', 'DESC' );

		$where  = '1=1';
		$params = [];
		if ( $status !== '' ) { $where .= ' AND c.status = %s'; $params[] = $status; }
		if ( $from !== '' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) { $where .= ' AND c.created_at >= %s'; $params[] = $from . ' 00:00:00'; }
		if ( $to !== ''   && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to   ) ) { $where .= ' AND c.created_at <= %s'; $params[] = $to . ' 23:59:59'; }

		$sql = "SELECT c.*, a.display_name AS aff_name, a.email AS aff_email
		        FROM {$prefix}aff_commissions c
		        LEFT JOIN {$prefix}aff_affiliates a ON a.id = c.affiliate_id
		        WHERE {$where}
		        ORDER BY {$orderby_sql} {$order_sql}
		        LIMIT 200";
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );

		$base_url = add_query_arg( array_filter( [
			'page' => 'asteris-affiliates-commissions',
			'status' => $status, 'from' => $from, 'to' => $to,
		] ), admin_url( 'admin.php' ) );

		$totals_cents = (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_cents),0) FROM {$prefix}aff_commissions WHERE status IN ('approved','paid')" );
		?>
		<div class="wrap">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<?php esc_html_e( 'Commissions', 'asteris-affiliates' ); ?>
				<?php echo CSV_Export::button( 'asteris_aff_export_commissions' ); // phpcs:ignore ?>
			</h1>
			<?php self::render_flash( $flash ); ?>

			<!-- Date-range filter (9A) -->
			<form method="get" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;margin:14px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
				<input type="hidden" name="page" value="asteris-affiliates-commissions">
				<?php if ( $status !== '' ) : ?><input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>"><?php endif; ?>
				<label style="font-size:12px;color:#666;font-weight:600;"><?php esc_html_e( 'From', 'asteris-affiliates' ); ?>
					<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>" style="margin-left:4px;">
				</label>
				<label style="font-size:12px;color:#666;font-weight:600;"><?php esc_html_e( 'To', 'asteris-affiliates' ); ?>
					<input type="date" name="to" value="<?php echo esc_attr( $to ); ?>" style="margin-left:4px;">
				</label>
				<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;"><?php esc_html_e( 'Filter', 'asteris-affiliates' ); ?></button>
				<?php if ( $from !== '' || $to !== '' ) : ?>
					<a href="<?php echo esc_url( remove_query_arg( [ 'from', 'to' ] ) ); ?>" class="button"><?php esc_html_e( 'Clear', 'asteris-affiliates' ); ?></a>
				<?php endif; ?>
			</form>

			<!-- Filter pills + total -->
			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin:14px 0 18px;">
				<?php foreach ( [
					[ 'All',      $total,            '',          '#0a857a' ],
					[ 'Pending',  $counts['pending'],'pending',   '#ea580c' ],
					[ 'Approved', $counts['approved'],'approved', '#059669' ],
					[ 'Paid',     $counts['paid'],   'paid',      '#06D6A0' ],
					[ 'Refunded', $counts['refunded'],'refunded', '#b45309' ],
					[ 'Rejected', $counts['rejected'],'rejected', '#6b7280' ],
				] as $card ) : [ $label, $value, $f, $colour ] = $card;
					$url = $f === ''
						? admin_url( 'admin.php?page=asteris-affiliates-commissions' )
						: admin_url( 'admin.php?page=asteris-affiliates-commissions&status=' . $f );
					$active = $status === $f;
				?>
					<a href="<?php echo esc_url( $url ); ?>" style="display:block;background:#fff;border:1px solid <?php echo $active ? esc_attr( $colour ) : '#e5e7eb'; ?>;border-left:3px solid <?php echo esc_attr( $colour ); ?>;border-radius:8px;padding:12px 14px;text-decoration:none;">
						<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $label ); ?></div>
						<div style="font-size:22px;color:#0a0a0a;font-weight:800;margin-top:2px;"><?php echo esc_html( number_format_i18n( $value ) ); ?></div>
					</a>
				<?php endforeach; ?>
			</div>

			<p style="background:#ecfdf5;border-left:3px solid #06D6A0;padding:10px 14px;border-radius:6px;margin:14px 0;color:#065f46;">
				<strong>Outstanding owed (approved+paid):</strong> $<?php echo esc_html( number_format( $totals_cents / 100, 2 ) ); ?>
			</p>

			<?php echo Bulk_Handler::toolbar( 'asteris_aff_bulk_commissions', [
				'approve' => __( 'Approve early', 'asteris-affiliates' ),
				'reject'  => __( 'Reject', 'asteris-affiliates' ),
			], 'asteris-affiliates-commissions' ); // phpcs:ignore ?>

			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th style="width:24px;"><?php echo Bulk_Handler::header_checkbox(); // phpcs:ignore ?></th>
					<?php
					echo Sort_Helper::th( __( 'ID', 'asteris-affiliates' ), 'id', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					echo Sort_Helper::th( __( 'Order', 'asteris-affiliates' ), 'order_id', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					echo Sort_Helper::th( __( 'Affiliate', 'asteris-affiliates' ), 'aff_name', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					?>
					<th><?php esc_html_e( 'Customer', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Source', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Rate', 'asteris-affiliates' ); ?></th>
					<?php echo Sort_Helper::th( __( 'Amount', 'asteris-affiliates' ), 'amount', $orderby_in, $order_in, $base_url ); // phpcs:ignore ?>
					<?php echo Sort_Helper::th( __( 'Status', 'asteris-affiliates' ), 'status', $orderby_in, $order_in, $base_url ); // phpcs:ignore ?>
					<th><?php esc_html_e( 'Refund window ends', 'asteris-affiliates' ); ?></th>
					<?php echo Sort_Helper::th( __( 'Created', 'asteris-affiliates' ), 'created_at', $orderby_in, $order_in, $base_url ); // phpcs:ignore ?>
					<th><?php esc_html_e( 'Actions', 'asteris-affiliates' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="12" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No commissions match.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$colour = [ 'pending' => '#ea580c', 'approved' => '#059669', 'paid' => '#06D6A0', 'refunded' => '#b45309', 'rejected' => '#6b7280' ][ $r->status ] ?? '#6b7280';
				?>
					<tr>
						<td><?php echo $r->status === 'pending' ? Bulk_Handler::row_checkbox( (int) $r->id ) : ''; // phpcs:ignore ?></td>
						<td>#<?php echo (int) $r->id; ?></td>
						<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $r->order_id . '&action=edit' ) ); ?>">#<?php echo (int) $r->order_id; ?></a></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->affiliate_id ) ); ?>" style="color:#06D6A0;font-weight:600;"><?php echo esc_html( $r->aff_name ?? '?' ); ?></a><div style="font-size:11px;color:#999;"><?php echo esc_html( $r->aff_email ?? '' ); ?></div></td>
						<td style="font-size:12px;color:#666;"><?php echo esc_html( (string) $r->customer_email ); ?></td>
						<td><?php echo esc_html( $r->attribution_type ); ?><?php if ( $r->coupon_code ) : ?><div style="font-size:10px;color:#999;font-family:ui-monospace,monospace;"><?php echo esc_html( $r->coupon_code ); ?></div><?php endif; ?></td>
						<td><?php echo number_format( $r->rate_bp / 100, 1 ); ?>% <span style="color:#999;font-size:10px;">Y<?php echo (int) $r->rate_year; ?></span></td>
						<td><strong>$<?php echo esc_html( number_format( $r->amount_cents / 100, 2 ) ); ?></strong> <span style="color:#999;font-size:11px;"><?php echo esc_html( $r->currency ); ?></span></td>
						<td><span style="background:<?php echo esc_attr( $colour ); ?>;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;"><?php echo esc_html( $r->status ); ?></span></td>
						<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( $r->refund_window_ends ); ?></td>
						<td style="font-family:ui-monospace,monospace;font-size:11px;color:#666;"><?php echo esc_html( $r->created_at ); ?></td>
						<td>
							<?php if ( $r->status === 'pending' ) : ?>
								<?php echo self::action_link( 'approve', (int) $r->id, 'Approve early', '#059669' ); ?>
								<?php echo self::action_link( 'reject',  (int) $r->id, 'Reject', '#dc2626' ); ?>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
			<p style="color:#999;font-size:12px;margin-top:14px;"><?php esc_html_e( 'Showing up to 200 most recent matching rows. Use bulk above + CSV export for larger sets.', 'asteris-affiliates' ); ?></p>
		</div>
		<?php
	}

	private static function action_link( string $action, int $id, string $label, string $colour ): string {
		$url = wp_nonce_url(
			admin_url( 'admin-post.php?action=asteris_aff_commission_' . $action . '&id=' . $id ),
			'asteris_aff_commission_' . $action . '_' . $id
		);
		return '<a href="' . esc_url( $url ) . '" class="button button-small" style="background:' . esc_attr( $colour ) . ';border-color:' . esc_attr( $colour ) . ';color:#fff;margin-right:4px;" onclick="return confirm(\'' . esc_js( $label . ' commission #' . $id . '?' ) . '\');">' . esc_html( $label ) . '</a>';
	}

	public static function handle_approve(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_commission_approve_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->update( $wpdb->prefix . 'aff_commissions',
			[ 'status' => 'approved', 'approved_at' => $now ],
			[ 'id' => $id, 'status' => 'pending' ]
		);
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'commission.approved_early',
			'affiliate_id' => null,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'commission_id' => $id ] ),
		] );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-commissions&flash=approved' ) );
		exit;
	}

	public static function handle_reject(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'asteris_aff_commission_reject_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->update( $wpdb->prefix . 'aff_commissions',
			[ 'status' => 'rejected' ],
			[ 'id' => $id, 'status' => 'pending' ]
		);
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'commission.rejected',
			'affiliate_id' => null,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'commission_id' => $id ] ),
		] );
		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates-commissions&flash=rejected' ) );
		exit;
	}

	private static function render_flash( string $flash ): void {
		if ( $flash === 'bulk_done' ) {
			$n = isset( $_GET['n'] ) ? (int) $_GET['n'] : 0;
			$a = isset( $_GET['a'] ) ? sanitize_key( wp_unslash( $_GET['a'] ) ) : '';
			echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;background:#ecfdf5;border-left:4px solid #06D6A0;color:#065f46;"><p style="margin:0;">' . esc_html( sprintf( __( '✓ Bulk %2$s applied to %1$d commissions.', 'asteris-affiliates' ), $n, $a ) ) . '</p></div>';
			return;
		}
		if ( $flash === 'nothing_selected' ) {
			echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;"><p style="margin:0;">' . esc_html__( '✗ Nothing was selected for the bulk action.', 'asteris-affiliates' ) . '</p></div>';
			return;
		}
		$map = [
			'approved' => [ 'ok',   '✓ Commission approved.' ],
			'rejected' => [ 'warn', '⚠ Commission rejected.' ],
		];
		if ( ! isset( $map[ $flash ] ) ) { return; }
		[ $kind, $html ] = $map[ $flash ];
		$style = $kind === 'ok'
			? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;';
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . esc_html( $html ) . '</p></div>';
	}
}
