<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;

defined( 'ABSPATH' ) || exit;

/**
 * Affiliates list view + approve/reject actions.
 */
final class Page_Affiliates {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_approve', [ self::class, 'handle_status_change' ] );
		add_action( 'admin_post_asteris_aff_reject',  [ self::class, 'handle_status_change' ] );
		add_action( 'admin_post_asteris_aff_suspend', [ self::class, 'handle_status_change' ] );
		add_action( 'admin_post_asteris_aff_reinstate', [ self::class, 'handle_status_change' ] );
		Page_Affiliate_Detail::register();
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		// Dispatch to the detail/edit view when ?id is present
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		if ( $id > 0 ) {
			Page_Affiliate_Detail::render( $id );
			return;
		}

		$flash  = isset( $_GET['flash'] )  ? sanitize_key( wp_unslash( $_GET['flash'] ) )  : '';
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$search = isset( $_GET['s'] )      ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$counts = Affiliate_Repository::counts_by_status();
		$total  = array_sum( $counts );

		// Sort_Helper resolves safe ORDER BY column (9A — column sort)
		$sort_whitelist = [
			'id'           => 'id',
			'display_name' => 'display_name',
			'email'        => 'email',
			'status'       => 'status',
			'applied_at'   => 'applied_at',
			'earnings'     => 'lifetime_earnings_cents',
		];
		[ $orderby_sql, $order_sql, $orderby_in, $order_in ] = Sort_Helper::resolve( $sort_whitelist, 'id', 'DESC' );

		$rows = Affiliate_Repository::list( array_filter( [
			'status'  => $status,
			'search'  => $search,
			'orderby' => $orderby_sql,
			'order'   => $order_sql,
			'limit'   => 200,
		] ) );

		$base_url = add_query_arg( array_filter( [ 'page' => 'asteris-affiliates', 'status' => $status, 's' => $search ] ), admin_url( 'admin.php' ) );
		?>
		<div class="wrap">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<?php esc_html_e( 'Affiliates', 'asteris-affiliates' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-add' ) ); ?>" class="page-title-action" style="background:#06D6A0;border-color:#06D6A0;color:#fff;"><?php esc_html_e( '+ Add manually', 'asteris-affiliates' ); ?></a>
				<?php echo CSV_Export::button( 'asteris_aff_export_affiliates' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</h1>

			<?php self::render_flash( $flash ); ?>

			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin:14px 0 18px;">
				<?php foreach ( [
					[ 'All',        $total,                '',           '#0a857a' ],
					[ 'Pending',    $counts['pending'],    'pending',    '#ea580c' ],
					[ 'Approved',   $counts['approved'],   'approved',   '#059669' ],
					[ 'Suspended',  $counts['suspended'],  'suspended',  '#b45309' ],
					[ 'Rejected',   $counts['rejected'],   'rejected',   '#6b7280' ],
				] as $card ) : [ $label, $value, $f, $colour ] = $card;
					$url = $f === ''
						? admin_url( 'admin.php?page=asteris-affiliates' )
						: admin_url( 'admin.php?page=asteris-affiliates&status=' . $f );
					$active = $status === $f;
				?>
					<a href="<?php echo esc_url( $url ); ?>" style="display:block;background:#fff;border:1px solid <?php echo $active ? esc_attr( $colour ) : '#e5e7eb'; ?>;border-left:3px solid <?php echo esc_attr( $colour ); ?>;border-radius:8px;padding:12px 14px;text-decoration:none;">
						<div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php echo esc_html( $label ); ?></div>
						<div style="font-size:22px;color:#0a0a0a;font-weight:800;margin-top:2px;"><?php echo esc_html( number_format_i18n( $value ) ); ?></div>
					</a>
				<?php endforeach; ?>
			</div>

			<form method="get" style="margin-bottom:14px;">
				<input type="hidden" name="page" value="asteris-affiliates">
				<?php if ( $status !== '' ) : ?><input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>"><?php endif; ?>
				<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search name or email…" class="regular-text">
				<button type="submit" class="button">Search</button>
				<?php if ( $search !== '' ) : ?><a href="<?php echo esc_url( remove_query_arg( 's' ) ); ?>" class="button">Clear</a><?php endif; ?>
			</form>

			<?php echo Bulk_Handler::toolbar( 'asteris_aff_bulk_affiliates', [
				'approve'   => __( 'Approve', 'asteris-affiliates' ),
				'reject'    => __( 'Reject',  'asteris-affiliates' ),
				'suspend'   => __( 'Suspend', 'asteris-affiliates' ),
				'reinstate' => __( 'Reinstate', 'asteris-affiliates' ),
			], 'asteris-affiliates' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<table class="widefat striped" style="font-size:13px;">
				<thead><tr>
					<th style="width:24px;"><?php echo Bulk_Handler::header_checkbox(); // phpcs:ignore ?></th>
					<?php
					echo Sort_Helper::th( __( 'ID', 'asteris-affiliates' ), 'id', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					echo Sort_Helper::th( __( 'Name', 'asteris-affiliates' ), 'display_name', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					echo Sort_Helper::th( __( 'Email', 'asteris-affiliates' ), 'email', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					echo Sort_Helper::th( __( 'Status', 'asteris-affiliates' ), 'status', $orderby_in, $order_in, $base_url ); // phpcs:ignore
					?>
					<th><?php esc_html_e( 'Country', 'asteris-affiliates' ); ?></th>
					<th><?php esc_html_e( 'Y1 rate', 'asteris-affiliates' ); ?></th>
					<?php echo Sort_Helper::th( __( 'Earnings', 'asteris-affiliates' ), 'earnings', $orderby_in, $order_in, $base_url ); // phpcs:ignore ?>
					<th><?php esc_html_e( 'Public ID', 'asteris-affiliates' ); ?></th>
					<?php echo Sort_Helper::th( __( 'Applied', 'asteris-affiliates' ), 'applied_at', $orderby_in, $order_in, $base_url ); // phpcs:ignore ?>
					<th><?php esc_html_e( 'Actions', 'asteris-affiliates' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="11" style="text-align:center;padding:30px;color:#999;"><?php esc_html_e( 'No affiliates match those filters.', 'asteris-affiliates' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$status_colour = [ 'pending' => '#ea580c', 'approved' => '#059669', 'suspended' => '#b45309', 'rejected' => '#6b7280', 'terminated' => '#dc2626' ][ $r->status ] ?? '#6b7280';
				?>
					<?php $edit_url = admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->id ); ?>
					<tr>
						<td><?php echo Bulk_Handler::row_checkbox( (int) $r->id ); // phpcs:ignore ?></td>
						<td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo (int) $r->id; ?></a></td>
						<td><strong><a href="<?php echo esc_url( $edit_url ); ?>" style="text-decoration:none;color:#06D6A0;"><?php echo esc_html( $r->display_name ); ?></a></strong>
							<div style="font-size:11px;margin-top:2px;"><a href="<?php echo esc_url( $edit_url ); ?>" style="color:#999;text-decoration:none;"><?php esc_html_e( 'Edit →', 'asteris-affiliates' ); ?></a></div></td>
						<td><?php echo esc_html( $r->email ); ?></td>
						<td><span style="background:<?php echo esc_attr( $status_colour ); ?>;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;"><?php echo esc_html( $r->status ); ?></span></td>
						<td><?php echo esc_html( $r->country_code ); ?></td>
						<td><?php echo number_format( $r->commission_rate_y1_bp / 100, 1 ); ?>%</td>
						<td><strong>$<?php echo esc_html( number_format( (int) ( $r->lifetime_earnings_cents ?? 0 ) / 100, 2 ) ); ?></strong></td>
						<td><code style="font-size:11px;"><?php echo esc_html( $r->public_id ); ?></code></td>
						<td style="font-size:11px;color:#666;font-family:ui-monospace,monospace;"><?php echo esc_html( $r->applied_at ); ?></td>
						<td>
							<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=asteris-affiliates-impersonate&affiliate_id=' . (int) $r->id ), 'asteris_aff_impersonate_' . (int) $r->id ) ); ?>" class="button button-small" style="background:#fff;border-color:#06D6A0;color:#06D6A0;margin-right:4px;" title="<?php esc_attr_e( 'View portal as this affiliate', 'asteris-affiliates' ); ?>">👁</a>
							<?php if ( $r->status === 'pending' ) : ?>
								<?php echo self::action_link( 'approve', (int) $r->id, __( 'Approve', 'asteris-affiliates' ), '#059669' ); ?>
								<?php echo self::action_link( 'reject',  (int) $r->id, __( 'Reject', 'asteris-affiliates' ), '#dc2626' ); ?>
							<?php elseif ( $r->status === 'approved' ) : ?>
								<?php echo self::action_link( 'suspend', (int) $r->id, __( 'Suspend', 'asteris-affiliates' ), '#b45309' ); ?>
							<?php elseif ( in_array( $r->status, [ 'suspended', 'rejected' ], true ) ) : ?>
								<?php echo self::action_link( 'reinstate', (int) $r->id, __( 'Reinstate', 'asteris-affiliates' ), '#059669' ); ?>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function action_link( string $action, int $id, string $label, string $colour ): string {
		$url = wp_nonce_url(
			admin_url( 'admin-post.php?action=asteris_aff_' . $action . '&id=' . $id ),
			'asteris_aff_' . $action . '_' . $id
		);
		return '<a href="' . esc_url( $url ) . '" class="button button-small" style="background:' . esc_attr( $colour ) . ';border-color:' . esc_attr( $colour ) . ';color:#fff;margin-right:4px;" onclick="return confirm(\'' . esc_js( $label . ' affiliate #' . $id . '?' ) . '\');">' . esc_html( $label ) . '</a>';
	}

	public static function handle_status_change(): void {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$action_full = current_filter(); // admin_post_asteris_aff_<action>
		$action = str_replace( 'admin_post_asteris_aff_', '', $action_full );
		check_admin_referer( 'asteris_aff_' . $action . '_' . $id );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=not_found' ) );
			exit;
		}

		$now = current_time( 'mysql', true );
		$map = [
			'approve'   => [ 'status' => 'approved',  'approved_at'  => $now ],
			'reject'    => [ 'status' => 'rejected'                          ],
			'suspend'   => [ 'status' => 'suspended', 'suspended_at' => $now ],
			'reinstate' => [ 'status' => 'approved',  'suspended_at' => null ],
		];
		if ( ! isset( $map[ $action ] ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=bad_action' ) );
			exit;
		}

		// Free-tier cap: max 10 approved affiliates
		if ( in_array( $action, [ 'approve', 'reinstate' ], true )
			&& ! \AsterisAffiliates\Core\Free_Tier::can_approve_more_affiliates()
		) {
			wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=free_cap_hit' ) );
			exit;
		}

		Affiliate_Repository::update( $id, $map[ $action ] );

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'affiliate.' . $action,
			'affiliate_id' => $id,
			'actor'        => 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'from' => $aff->status, 'to' => $map[ $action ]['status'] ] ),
		] );

		// Fire welcome email on approve — routed through Email engine
		// so admin's WYSIWYG override is honoured.
		if ( $action === 'approve' ) {
			\AsterisAffiliates\Email\Renderer::send_template( 'approved', $aff->email, [
				'display_name' => $aff->display_name,
				'portal_url'   => home_url( '/affiliate-portal/' ),
				'tracking_url' => add_query_arg( 'ref', $aff->public_id, home_url( '/' ) ),
				'y1_rate'      => (string) (int) round( (int) $aff->commission_rate_y1_bp / 100 ),
				'y2_rate'      => (string) (int) round( (int) $aff->commission_rate_y2plus_bp / 100 ),
				'cookie_days'  => (string) (int) \AsterisAffiliates\Core\Settings::get( 'cookie_days', 60 ),
			] );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=' . $action . 'd' ) );
		exit;
	}

	private static function render_flash( string $flash ): void {
		// Bulk-done flash uses ?n=N&a=action from Bulk_Handler
		if ( $flash === 'bulk_done' ) {
			$n = isset( $_GET['n'] ) ? (int) $_GET['n'] : 0;
			$a = isset( $_GET['a'] ) ? sanitize_key( wp_unslash( $_GET['a'] ) ) : '';
			$style = 'background:#ecfdf5;border-left:4px solid #06D6A0;color:#065f46;';
			$msg = sprintf( /* translators: %1$d = count, %2$s = action verb */
				esc_html__( '✓ Bulk action %2$s applied to %1$d affiliates.', 'asteris-affiliates' ),
				$n, esc_html( $a )
			);
			echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . $msg . '</p></div>'; // phpcs:ignore
			return;
		}
		if ( $flash === 'nothing_selected' ) {
			echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;"><p style="margin:0;">' . esc_html__( '✗ Nothing was selected for the bulk action.', 'asteris-affiliates' ) . '</p></div>';
			return;
		}
		if ( $flash === 'free_cap_hit' ) {
			echo '<div class="notice is-dismissible" style="padding:14px 18px;margin:12px 0;background:#fff8e1;border-left:4px solid #b45309;color:#92400e;"><p style="margin:0;"><strong>' . esc_html__( '⚠ Free-tier cap reached.', 'asteris-affiliates' ) . '</strong> ' . esc_html__( 'The free tier supports up to 10 approved affiliates. Upgrade to Pro for unlimited affiliates.', 'asteris-affiliates' ) . ' ' . \AsterisAffiliates\Core\Free_Tier::upgrade_cta( 'cap_hit' ) . '</p></div>'; // phpcs:ignore
			return;
		}
		$map = [
			'approved'         => [ 'ok',   '✓ Affiliate approved + welcome email sent.' ],
			'rejected'         => [ 'warn', '⚠ Affiliate rejected.' ],
			'suspended'        => [ 'warn', '⚠ Affiliate suspended.' ],
			'reinstated'       => [ 'ok',   '✓ Affiliate reinstated.' ],
			'created_manually' => [ 'ok',   '✓ Affiliate created manually.' ],
			'not_found'        => [ 'err',  '✗ Affiliate not found.' ],
			'bad_action'       => [ 'err',  '✗ Unknown action.' ],
		];
		// Tolerate the +"d" suffix from handle_status_change
		$flash = preg_replace( '/d$/', 'ed', $flash, 1 );
		if ( ! isset( $map[ $flash ] ) ) { return; }
		[ $kind, $html ] = $map[ $flash ];
		$style = match ( $kind ) {
			'ok'   => 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;',
			'warn' => 'background:#fff8e1;border-left:4px solid #b45309;color:#92400e;',
			default=> 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;',
		};
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . esc_html( $html ) . '</p></div>';
	}
}
