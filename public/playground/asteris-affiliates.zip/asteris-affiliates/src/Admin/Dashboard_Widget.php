<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * WP admin dashboard widget.
 *
 * Shows store owner at-a-glance status when they log into wp-admin:
 *   - Pending approvals (with click-through)
 *   - Earnings owed this month
 *   - Top affiliate this month
 *   - Recent affiliate sign-ups
 */
final class Dashboard_Widget {

	public static function register(): void {
		add_action( 'wp_dashboard_setup', [ self::class, 'add_widget' ] );
	}

	public static function add_widget(): void {
		if ( ! current_user_can( Menu::CAP ) ) { return; }
		wp_add_dashboard_widget(
			'asteris_affiliates_widget',
			__( 'Asteris Affiliates · at a glance', 'asteris-affiliates' ),
			[ self::class, 'render' ]
		);
	}

	public static function render(): void {
		global $wpdb;
		$p = $wpdb->prefix;

		$pending_apps  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}aff_affiliates WHERE status = 'pending'" );
		$pending_comm  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}aff_commissions WHERE status = 'pending'" );
		$owed_cents    = (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE status = 'approved'" );
		$month_cents   = (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_cents),0) FROM {$p}aff_commissions WHERE status IN ('approved','paid') AND created_at >= DATE_FORMAT(NOW(),'%Y-%m-01')" );

		$top = $wpdb->get_row(
			"SELECT a.id, a.display_name, COALESCE(SUM(c.amount_cents),0) AS earnings
			 FROM {$p}aff_affiliates a
			 LEFT JOIN {$p}aff_commissions c ON c.affiliate_id = a.id AND c.created_at >= DATE_FORMAT(NOW(),'%Y-%m-01') AND c.status IN ('approved','paid')
			 WHERE a.status = 'approved'
			 GROUP BY a.id
			 HAVING earnings > 0
			 ORDER BY earnings DESC
			 LIMIT 1"
		);

		$recent = $wpdb->get_results(
			"SELECT id, display_name, email, applied_at FROM {$p}aff_affiliates ORDER BY id DESC LIMIT 5"
		);
		?>
		<div style="font-size:13px;">
			<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">
				<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid <?php echo $pending_apps > 0 ? '#ea580c' : '#06D6A0'; ?>;border-radius:6px;padding:10px 12px;">
					<div style="font-size:10px;color:#666;text-transform:uppercase;font-weight:700;letter-spacing:0.05em;"><?php esc_html_e( 'Pending applications', 'asteris-affiliates' ); ?></div>
					<div style="font-size:20px;font-weight:800;color:#0a0a0a;margin-top:2px;"><?php echo (int) $pending_apps; ?></div>
				</div>
				<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid #ea580c;border-radius:6px;padding:10px 12px;">
					<div style="font-size:10px;color:#666;text-transform:uppercase;font-weight:700;letter-spacing:0.05em;"><?php esc_html_e( 'Pending commissions', 'asteris-affiliates' ); ?></div>
					<div style="font-size:20px;font-weight:800;color:#0a0a0a;margin-top:2px;"><?php echo (int) $pending_comm; ?></div>
				</div>
				<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid #059669;border-radius:6px;padding:10px 12px;">
					<div style="font-size:10px;color:#666;text-transform:uppercase;font-weight:700;letter-spacing:0.05em;"><?php esc_html_e( 'Approved owed', 'asteris-affiliates' ); ?></div>
					<div style="font-size:20px;font-weight:800;color:#0a0a0a;margin-top:2px;">$<?php echo esc_html( number_format( $owed_cents / 100, 2 ) ); ?></div>
				</div>
				<div style="background:#fff;border:1px solid #e5e7eb;border-left:3px solid #06D6A0;border-radius:6px;padding:10px 12px;">
					<div style="font-size:10px;color:#666;text-transform:uppercase;font-weight:700;letter-spacing:0.05em;"><?php esc_html_e( 'This month', 'asteris-affiliates' ); ?></div>
					<div style="font-size:20px;font-weight:800;color:#0a0a0a;margin-top:2px;">$<?php echo esc_html( number_format( $month_cents / 100, 2 ) ); ?></div>
				</div>
			</div>

			<?php if ( $top ) : ?>
			<div style="background:#ecfdf5;border-left:3px solid #06D6A0;padding:10px 12px;border-radius:4px;margin-bottom:12px;">
				<span style="color:#065f46;"><?php esc_html_e( '🏆 Top this month:', 'asteris-affiliates' ); ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $top->id ) ); ?>" style="color:#06D6A0;font-weight:600;text-decoration:none;"><?php echo esc_html( $top->display_name ); ?></a>
					— $<?php echo esc_html( number_format( $top->earnings / 100, 2 ) ); ?>
				</span>
			</div>
			<?php endif; ?>

			<?php if ( $recent ) : ?>
			<div style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:0.05em;font-weight:700;margin-bottom:6px;"><?php esc_html_e( 'Recent sign-ups', 'asteris-affiliates' ); ?></div>
			<table style="width:100%;font-size:12px;">
				<tbody>
				<?php foreach ( $recent as $r ) : ?>
					<tr>
						<td style="padding:4px 0;"><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $r->id ) ); ?>" style="color:#06D6A0;text-decoration:none;font-weight:600;"><?php echo esc_html( $r->display_name ); ?></a></td>
						<td style="padding:4px 0;color:#666;"><?php echo esc_html( $r->email ); ?></td>
						<td style="padding:4px 0;color:#999;text-align:right;font-family:ui-monospace,monospace;"><?php echo esc_html( $r->applied_at ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>

			<p style="margin:14px 0 0;text-align:right;">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates' ) ); ?>" style="color:#06D6A0;font-weight:600;"><?php esc_html_e( 'Open Affiliates →', 'asteris-affiliates' ); ?></a>
			</p>
		</div>
		<?php
	}
}
