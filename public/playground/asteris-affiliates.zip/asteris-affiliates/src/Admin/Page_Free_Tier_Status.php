<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Core\Free_Tier;

defined( 'ABSPATH' ) || exit;

/**
 * Free vs Pro status page — shows what's gated + the upgrade pitch.
 *
 * Why this exists: customers on free tier hit walls (10-affiliate cap, no
 * Stripe auto-payouts, no MLM, etc) and we want a single page that answers
 * "what else does Pro unlock?" + "what am I missing?" without scrolling
 * through marketing-site copy.
 *
 * Hidden when Pro licence is active — the page becomes a celebration
 * dashboard ("you have everything").
 */
final class Page_Free_Tier_Status {

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$is_pro = Free_Tier::is_pro();
		$current = Free_Tier::current_approved_count();
		$cap = Free_Tier::FREE_AFFILIATE_CAP;
		$pct = $is_pro ? 0 : (int) min( 100, round( ( $current / $cap ) * 100 ) );

		$features = self::feature_matrix();
		?>
		<div class="wrap" style="max-width:1100px;">
			<h1 style="display:flex;align-items:center;gap:12px;">
				<?php esc_html_e( 'Free vs Pro', 'asteris-affiliates' ); ?>
				<?php if ( $is_pro ) : ?>
					<span style="background:#06D6A0;color:#fff;padding:4px 12px;border-radius:99px;font-size:12px;font-weight:800;letter-spacing:0.06em;">✓ PRO ACTIVE</span>
				<?php else : ?>
					<span style="background:#fff8e1;color:#92400e;padding:4px 12px;border-radius:99px;font-size:12px;font-weight:700;letter-spacing:0.06em;">FREE TIER</span>
				<?php endif; ?>
			</h1>

			<?php if ( $is_pro ) : ?>
				<div style="background:linear-gradient(135deg,#06D6A0,#0a857a);color:#fff;padding:24px 28px;border-radius:12px;margin:20px 0;">
					<h2 style="margin:0 0 6px;color:#fff;font-size:24px;">🎉 <?php esc_html_e( 'You have full access', 'asteris-affiliates' ); ?></h2>
					<p style="margin:0;opacity:0.95;"><?php esc_html_e( 'Every feature below is enabled on your install. Thanks for supporting an Australian-built indie plugin.', 'asteris-affiliates' ); ?></p>
				</div>
			<?php else : ?>
				<!-- Cap progress -->
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px 24px;margin:20px 0;">
					<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
						<div>
							<div style="font-size:12px;color:#666;text-transform:uppercase;letter-spacing:0.06em;font-weight:700;"><?php esc_html_e( 'Affiliates approved', 'asteris-affiliates' ); ?></div>
							<div style="font-size:32px;font-weight:800;color:#0a0a0a;margin-top:4px;"><?php echo (int) $current; ?> / <?php echo (int) $cap; ?></div>
							<?php if ( $current >= $cap ) : ?>
								<div style="color:#b45309;font-weight:600;margin-top:4px;">⚠ <?php esc_html_e( 'Cap reached — Pro unlocks unlimited', 'asteris-affiliates' ); ?></div>
							<?php endif; ?>
						</div>
						<a href="https://asterisaffiliates.com/pricing?utm_source=plugin&utm_medium=status_page&utm_campaign=hero" target="_blank" rel="noopener" style="background:#06D6A0;color:#fff;padding:14px 28px;border-radius:8px;text-decoration:none;font-weight:800;font-size:15px;"><?php esc_html_e( 'Upgrade to Pro →', 'asteris-affiliates' ); ?></a>
					</div>
					<div style="margin-top:14px;height:8px;background:#e5e7eb;border-radius:99px;overflow:hidden;">
						<div style="width:<?php echo (int) $pct; ?>%;height:100%;background:linear-gradient(90deg,#06D6A0,#0a857a);"></div>
					</div>
				</div>
			<?php endif; ?>

			<!-- Feature comparison table -->
			<table class="widefat striped" style="margin-top:18px;font-size:14px;">
				<thead>
					<tr>
						<th style="width:50%;padding:14px 18px;"><?php esc_html_e( 'Feature', 'asteris-affiliates' ); ?></th>
						<th style="width:25%;text-align:center;padding:14px;"><?php esc_html_e( 'Free', 'asteris-affiliates' ); ?></th>
						<th style="width:25%;text-align:center;padding:14px;background:#ecfdf5;"><?php esc_html_e( 'Pro', 'asteris-affiliates' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $features as $section_name => $rows ) : ?>
					<tr><td colspan="3" style="padding:14px 18px;background:#0a0a0a;color:#fff;font-weight:800;text-transform:uppercase;letter-spacing:0.06em;font-size:11px;"><?php echo esc_html( $section_name ); ?></td></tr>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<td style="padding:12px 18px;"><strong><?php echo esc_html( $row['label'] ); ?></strong>
								<?php if ( ! empty( $row['note'] ) ) : ?><div style="color:#666;font-size:12px;margin-top:2px;"><?php echo esc_html( $row['note'] ); ?></div><?php endif; ?>
							</td>
							<td style="text-align:center;padding:12px;"><?php echo self::cell( $row['free'] ); // phpcs:ignore ?></td>
							<td style="text-align:center;padding:12px;background:<?php echo $is_pro ? '#ecfdf5' : '#fafafa'; ?>;"><?php echo self::cell( $row['pro'], true ); // phpcs:ignore ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( ! $is_pro ) : ?>
				<!-- Pricing pitch -->
				<div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:30px;margin-top:24px;">
					<h2 style="margin:0 0 8px;font-size:24px;"><?php esc_html_e( 'Pro — 3 tiers, locked for life', 'asteris-affiliates' ); ?></h2>
					<p style="color:#666;margin:0 0 22px;"><?php esc_html_e( 'Your launch price is locked for the life of your subscription. No founder pricing, no Cart bundles, no surprise tier-up letters.', 'asteris-affiliates' ); ?></p>
					<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;">
						<?php foreach ( [
							[ 'Starter', '$149', '/yr', '1 site' ],
							[ 'Pro',     '$299', '/yr', '3 sites' ],
							[ 'Agency',  '$549', '/yr', '10 sites' ],
						] as $tier ) : ?>
							<div style="background:#0a0a0a;color:#fff;border-radius:10px;padding:20px;text-align:center;">
								<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;opacity:0.6;font-weight:700;"><?php echo esc_html( $tier[0] ); ?></div>
								<div style="font-size:36px;font-weight:800;margin:6px 0;letter-spacing:-1px;"><?php echo esc_html( $tier[1] ); ?><span style="font-size:14px;opacity:0.7;font-weight:600;"><?php echo esc_html( $tier[2] ); ?></span></div>
								<div style="font-size:13px;opacity:0.8;"><?php echo esc_html( $tier[3] ); ?></div>
							</div>
						<?php endforeach; ?>
					</div>
					<p style="margin:22px 0 0;text-align:center;">
						<a href="https://asterisaffiliates.com/pricing?utm_source=plugin&utm_medium=status_page&utm_campaign=pricing_cta" target="_blank" rel="noopener" style="background:#06D6A0;color:#fff;padding:14px 36px;border-radius:8px;text-decoration:none;font-weight:800;font-size:16px;display:inline-block;"><?php esc_html_e( 'See pricing + activate →', 'asteris-affiliates' ); ?></a>
					</p>
					<p style="text-align:center;color:#888;font-size:12px;margin:14px 0 0;">
						<?php esc_html_e( 'Replaces $300–$2,400/yr of AffiliateWP, Tapfiliate, Refersion, GoAffPro. Less cost, more inclusions, Australian-built.', 'asteris-affiliates' ); ?>
					</p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function cell( $value, bool $accent = false ): string {
		if ( $value === true ) {
			$colour = $accent ? '#06D6A0' : '#059669';
			return '<span style="color:' . esc_attr( $colour ) . ';font-size:20px;font-weight:800;">✓</span>';
		}
		if ( $value === false ) {
			return '<span style="color:#999;font-size:20px;">—</span>';
		}
		return '<span style="color:#0a0a0a;font-weight:700;font-size:13px;">' . esc_html( (string) $value ) . '</span>';
	}

	/** @return array<string,array<int,array{label:string,note?:string,free:mixed,pro:mixed}>> */
	private static function feature_matrix(): array {
		return [
			__( 'Affiliate management', 'asteris-affiliates' ) => [
				[ 'label' => __( 'Approved affiliates', 'asteris-affiliates' ), 'free' => __( 'Up to 10', 'asteris-affiliates' ), 'pro' => __( 'Unlimited', 'asteris-affiliates' ) ],
				[ 'label' => __( 'Sites per licence', 'asteris-affiliates' ), 'free' => '1', 'pro' => __( '1 / 3 / 10 by tier', 'asteris-affiliates' ) ],
				[ 'label' => __( 'Affiliate signup form', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Magic-link portal', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Admin impersonation', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Onboarding wizard', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
			],
			__( 'Tracking + attribution', 'asteris-affiliates' ) => [
				[ 'label' => __( '?ref= link tracking', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Coupon-code attribution', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Bot filter', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'UTM + device + country capture', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Vanity landing pages /go/{handle}', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Cloud-assist fraud (opt-in)', 'asteris-affiliates' ), 'note' => __( 'Anonymous cross-site signal sharing', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
			],
			__( 'Commissions', 'asteris-affiliates' ) => [
				[ 'label' => __( 'Per-affiliate rate', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Y1 / Y2+ rate distinction', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Per-product rate overrides', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Recurring commissions (WC Subscriptions)', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'MLM / two-tier referrals', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Refund-rate auto-suspend', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Refund window clawback', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
			],
			__( 'Payouts', 'asteris-affiliates' ) => [
				[ 'label' => __( 'Manual mark-paid', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Stripe Connect auto-transfers', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'PayPal Payouts API', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Encrypted bank-detail storage', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Monthly batch cron', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
			],
			__( 'Marketing tools', 'asteris-affiliates' ) => [
				[ 'label' => __( 'Swipe copy library (16 seed snippets)', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'AI-generated swipe copy variants', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'A/B email subject + body tests', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( '15 customisable email templates', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Email throttling', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
			],
			__( 'Integrations', 'asteris-affiliates' ) => [
				[ 'label' => __( 'WooCommerce', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Easy Digital Downloads', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Surecart', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'WC Subscriptions (recurring)', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Stripe Connect Express onboarding', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
			],
			__( 'Admin + reporting', 'asteris-affiliates' ) => [
				[ 'label' => __( 'Dashboard widget', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Reports + date-range', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'CSV export', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Bulk operations', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Column sort + filtering', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'WP-CLI commands', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Activity log', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Stats REST API', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
			],
			__( 'Support', 'asteris-affiliates' ) => [
				[ 'label' => __( 'Community forum', 'asteris-affiliates' ), 'free' => true, 'pro' => true ],
				[ 'label' => __( 'Premium email support', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
				[ 'label' => __( 'Direct access to engineering on bug reports', 'asteris-affiliates' ), 'free' => false, 'pro' => true ],
			],
		];
	}
}
