<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Public_\Magic_Link_Auth;

defined( 'ABSPATH' ) || exit;

/**
 * Admin "View portal as this affiliate" — opens the portal in a way the
 * authoring admin can see, with a visible banner + auto-logout after 30 min.
 *
 * Security model:
 *   - Only admins with Menu::CAP can trigger
 *   - Nonce + ?affiliate_id required
 *   - Sets the same auth cookie as Magic_Link_Auth, BUT records an extra
 *     marker cookie `asteris_aff_impersonated_by` containing the admin's
 *     user ID. Portal_Dashboard renders a yellow banner when this is set.
 *   - Every impersonation is logged to aff_events
 *   - Admin can "Stop impersonating" via /affiliate-portal/?aff_action=stop_impersonating
 *     which clears BOTH cookies and redirects them back to wp-admin
 */
final class Impersonation {

	public const MARKER_COOKIE = 'asteris_aff_impersonated_by';

	public static function register(): void {
		add_action( 'admin_init', [ self::class, 'maybe_handle_start' ] );
		add_action( 'template_redirect', [ self::class, 'maybe_handle_stop' ], 5 );
	}

	public static function maybe_handle_start(): void {
		if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'asteris-affiliates-impersonate' ) { return; }
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$id = isset( $_GET['affiliate_id'] ) ? (int) $_GET['affiliate_id'] : 0;
		check_admin_referer( 'asteris_aff_impersonate_' . $id );

		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) { wp_die( esc_html__( 'Affiliate not found.', 'asteris-affiliates' ), 404 ); }

		Magic_Link_Auth::set_auth_cookie( (int) $aff->id );

		$admin = wp_get_current_user();
		setcookie(
			self::MARKER_COOKIE,
			(string) (int) $admin->ID,
			[
				'expires'  => time() + ( 30 * MINUTE_IN_SECONDS ),
				'path'     => '/',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			]
		);

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'admin.impersonation_started',
			'affiliate_id' => (int) $aff->id,
			'actor'        => 'admin:' . ( $admin->user_login ?: 'unknown' ),
			'payload'      => wp_json_encode( [ 'admin_user_id' => (int) $admin->ID ] ),
		] );

		wp_safe_redirect( home_url( '/affiliate-portal/' ) );
		exit;
	}

	public static function maybe_handle_stop(): void {
		$uri = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
		if ( ! str_starts_with( wp_parse_url( $uri, PHP_URL_PATH ) ?? '', '/affiliate-portal' ) ) { return; }
		$action = isset( $_GET['aff_action'] ) ? sanitize_key( wp_unslash( $_GET['aff_action'] ) ) : '';
		if ( $action !== 'stop_impersonating' ) { return; }

		Magic_Link_Auth::clear_auth_cookie();
		setcookie( self::MARKER_COOKIE, '', time() - 3600, '/', '', is_ssl(), true );
		unset( $_COOKIE[ self::MARKER_COOKIE ] );

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'admin.impersonation_ended',
			'affiliate_id' => null,
			'actor'        => 'system',
			'payload'      => wp_json_encode( [ 'returned_to_admin' => true ] ),
		] );

		wp_safe_redirect( admin_url( 'admin.php?page=asteris-affiliates&flash=impersonation_ended' ) );
		exit;
	}

	public static function is_impersonating(): bool {
		return ! empty( $_COOKIE[ self::MARKER_COOKIE ] );
	}

	public static function render_banner(): void {
		if ( ! self::is_impersonating() ) { return; }
		$stop_url = home_url( '/affiliate-portal/?aff_action=stop_impersonating' );
		?>
		<div style="background:#fff8e1;border:1px solid #b45309;border-radius:8px;padding:12px 16px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
			<span style="color:#92400e;font-weight:600;">⚠️ <?php esc_html_e( 'You are viewing this portal as an admin impersonating an affiliate. Actions you take here may be logged.', 'asteris-affiliates' ); ?></span>
			<a href="<?php echo esc_url( $stop_url ); ?>" style="background:#b45309;color:#fff;padding:6px 14px;border-radius:6px;text-decoration:none;font-weight:700;font-size:13px;"><?php esc_html_e( 'Stop impersonating', 'asteris-affiliates' ); ?></a>
		</div>
		<?php
	}
}
