<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Top-level admin menu for Asteris Affiliates.
 *
 *   ★ Asteris Affiliates                    (top-level, brand colour: #06D6A0)
 *     ├─ Affiliates    (default — list/detail view)
 *     ├─ Commissions   (pending approval queue + history)
 *     ├─ Payouts       (manual + batch payout management)
 *     ├─ Coupons       (vanity-code attribution)
 *     ├─ Emails        (template editor — ported from licence server)
 *     ├─ Reports       (top performers, revenue, refund-rate heatmap)
 *     ├─ Activity      (event log)
 *     └─ Settings      (global rates, refund window, payout config)
 *
 * Sprint 1 ships the skeleton: menu items + Affiliates list (empty state) +
 * Settings page (working form). Other pages = "Coming in Sprint X" stubs so
 * the menu is fully navigable from alpha.1.
 *
 * Gated to manage_options (admin role only). Same pattern as the licence server.
 */
final class Menu {

	public const CAP  = 'manage_options';
	public const SLUG = 'asteris-affiliates';

	public static function register(): void {
		add_action( 'admin_menu', [ self::class, 'add_menu' ] );
		add_action( 'admin_post_asteris_aff_save_settings', [ Page_Settings::class, 'handle_save' ] );
		Page_Overview::register();
		Page_License::register();
		Page_Test_Tracking::register();
		Page_Affiliates::register();
		Page_Add_Affiliate::register();
		Page_Commissions::register();
		Page_Coupons::register();
		Page_Emails::register();
		Page_Payouts::register();
		// v1.1.2 — admin pages for the new engines
		Page_Swipe_Copy::register();
		Page_Landing_Pages::register();
		Page_AB_Tests::register();
	}

	public static function add_menu(): void {
		// Top-level — teal (#06D6A0) menu icon via inline SVG, matches the
		// locked Asteris Affiliates brand colour.
		$icon = 'data:image/svg+xml;base64,' . base64_encode(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><text x="10" y="15" text-anchor="middle" font-size="16" fill="#06D6A0">★</text></svg>'
		);

		add_menu_page(
			__( 'Asteris Affiliates', 'asteris-affiliates' ),
			'Affiliates',
			self::CAP,
			self::SLUG,
			[ Page_Affiliates::class, 'render' ],
			$icon,
			4
		);

		add_submenu_page(
			self::SLUG,
			__( 'Affiliates', 'asteris-affiliates' ),
			__( 'Affiliates', 'asteris-affiliates' ),
			self::CAP,
			self::SLUG,
			[ Page_Affiliates::class, 'render' ]
		);

		// Overview / setup landing — added v1.2.0 to close the new-customer
		// "where do I find my URLs?" onboarding gap. Sits FIRST in the menu
		// so freshly-activated stores hit it before anything else.
		add_submenu_page(
			self::SLUG,
			__( 'Overview', 'asteris-affiliates' ),
			__( '★ Overview', 'asteris-affiliates' ),
			self::CAP,
			Page_Overview::SLUG,
			[ Page_Overview::class, 'render' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Add Affiliate', 'asteris-affiliates' ),
			'+ Add Affiliate',
			self::CAP,
			self::SLUG . '-add',
			[ Page_Add_Affiliate::class, 'render' ]
		);

		// Real pages (Sprint 4)
		add_submenu_page(
			self::SLUG, __( 'Commissions', 'asteris-affiliates' ), 'Commissions',
			self::CAP, self::SLUG . '-commissions', [ Page_Commissions::class, 'render' ]
		);
		add_submenu_page(
			self::SLUG, __( 'Coupons', 'asteris-affiliates' ), 'Coupons',
			self::CAP, self::SLUG . '-coupons', [ Page_Coupons::class, 'render' ]
		);

		// Real pages (Sprint 5A)
		add_submenu_page( self::SLUG, __( 'Emails',       'asteris-affiliates' ), 'Emails',       self::CAP, self::SLUG . '-emails',   [ Page_Emails::class,   'render' ] );
		add_submenu_page( self::SLUG, __( 'Reports',      'asteris-affiliates' ), 'Reports',      self::CAP, self::SLUG . '-reports',  [ Page_Reports::class,  'render' ] );
		add_submenu_page( self::SLUG, __( 'Activity log', 'asteris-affiliates' ), 'Activity log', self::CAP, self::SLUG . '-activity', [ Page_Activity::class, 'render' ] );

		// Real payouts page (Sprint 5B)
		add_submenu_page( self::SLUG, __( 'Payouts', 'asteris-affiliates' ), 'Payouts',
			self::CAP, self::SLUG . '-payouts', [ Page_Payouts::class, 'render' ] );

		// v1.1.2 — pages for new engines
		add_submenu_page( self::SLUG, __( 'Swipe Copy', 'asteris-affiliates' ), 'Swipe Copy',
			self::CAP, self::SLUG . '-swipe', [ Page_Swipe_Copy::class, 'render' ] );
		add_submenu_page( self::SLUG, __( 'Landing Pages', 'asteris-affiliates' ), 'Landing Pages',
			self::CAP, self::SLUG . '-landing', [ Page_Landing_Pages::class, 'render' ] );
		add_submenu_page( self::SLUG, __( 'A/B Tests', 'asteris-affiliates' ), 'A/B Tests',
			self::CAP, self::SLUG . '-ab', [ Page_AB_Tests::class, 'render' ] );

		add_submenu_page(
			self::SLUG,
			__( 'Settings', 'asteris-affiliates' ),
			__( 'Settings', 'asteris-affiliates' ),
			self::CAP,
			self::SLUG . '-settings',
			[ Page_Settings::class, 'render' ]
		);

		// v1.1.2 — Free vs Pro status (always visible)
		add_submenu_page( self::SLUG, __( 'Free vs Pro', 'asteris-affiliates' ), '✨ Free vs Pro',
			self::CAP, self::SLUG . '-free-tier', [ Page_Free_Tier_Status::class, 'render' ] );

		// Sprint 2 helper — retired in Sprint 3
		add_submenu_page(
			self::SLUG,
			__( 'Test Tracking', 'asteris-affiliates' ),
			'🧪 Test Tracking',
			self::CAP,
			self::SLUG . '-test',
			[ Page_Test_Tracking::class, 'render' ]
		);

		// v1.2.3 — License submenu (last item). Always renders inside Affiliates
		// admin (full key entry + status + tier + Installer cross-link). Lets
		// customers manage their licence without depending on the Installer
		// plugin being present.
		add_submenu_page(
			self::SLUG,
			__( 'License', 'asteris-affiliates' ),
			'🔑 License',
			self::CAP,
			Page_License::SLUG,
			[ Page_License::class, 'render' ]
		);
	}

	/**
	 * True when the Asteris Installer plugin is active in this WP install.
	 * The Installer registers a top-level menu under slug 'asteris-installer'
	 * (per AsterisInstaller\Admin_Page::SLUG). Surfaced on the License page
	 * as a cross-link for multi-plugin licence management.
	 */
	public static function installer_active(): bool {
		return class_exists( '\\AsterisInstaller\\Admin_Page' );
	}
}
