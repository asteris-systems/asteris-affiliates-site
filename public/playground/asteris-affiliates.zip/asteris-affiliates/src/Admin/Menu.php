<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Top-level admin menu for Asteris Affiliates.
 *
 *   ★ Asteris Affiliates                    (top-level, brand colour: #06D6A0)
 *     ├─ Affiliates    (default — list/detail view)
 *     ├─ Commissions   (pending approval queue + history)
 *     ├─ Payouts       (manual + batch payout management)
 *     ├─ Coupons       (vanity-code attribution)
 *     ├─ Emails        (template editor — ported from licence server)
 *     ├─ Reports       (top performers, revenue, refund-rate heatmap)
 *     ├─ Activity      (event log)
 *     └─ Settings      (global rates, refund window, payout config)
 *
 * Sprint 1 ships the skeleton: menu items + Affiliates list (empty state) +
 * Settings page (working form). Other pages = "Coming in Sprint X" stubs so
 * the menu is fully navigable from alpha.1.
 *
 * Gated to manage_options (admin role only). Same pattern as the licence server.
 */
final class Menu {

	public const CAP  = 'manage_options';
	public const SLUG = 'asteris-affiliates';

	public static function register(): void {
		add_action( 'admin_menu', [ self::class, 'add_menu' ] );
		add_action( 'admin_post_asteris_aff_save_settings', [ Page_Settings::class, 'handle_save' ] );
		Page_Overview::register();
		Page_Test_Tracking::register();
		Page_Affiliates::register();
		Page_Add_Affiliate::register();
		Page_Commissions::register();
		Page_Coupons::register();
		Page_Emails::register();
		Page_Payouts::register();
		// v1.1.2 — admin pages for the new engines
		Page_Swipe_Copy::register();
		Page_Landing_Pages::register();
		Page_AB_Tests::register();
	}

	public static function add_menu(): void {
		// Top-level — teal (#06D6A0) menu icon via inline SVG, matches the
		// locked Asteris Affiliates brand colour.
		$icon = 'data:image/svg+xml;base64,' . base64_encode(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><text x="10" y="15" text-anchor="middle" font-size="16" fill="#06D6A0">★</text></svg>'
		);

		add_menu_page(
			__( 'Asteris Affiliates', 'asteris-affiliates' ),
			'Affiliates',
			self::CAP,
			self::SLUG,
			[ Page_Affiliates::class, 'render' ],
			$icon,
			4
		);

		add_submenu_page(
			self::SLUG,
			__( 'Affiliates', 'asteris-affiliates' ),
			__( 'Affiliates', 'asteris-affiliates' ),
			self::CAP,
			self::SLUG,
			[ Page_Affiliates::class, 'render' ]
		);

		// Overview / setup landing — added v1.2.0 to close the new-customer
		// "where do I find my URLs?" onboarding gap. Sits FIRST in the menu
		// so freshly-activated stores hit it before anything else.
		add_submenu_page(
			self::SLUG,
			__( 'Overview', 'asteris-affiliates' ),
			__( '★ Overview', 'asteris-affiliates' ),
			self::CAP,
			Page_Overview::SLUG,
			[ Page_Overview::class, 'render' ]
		);

		add_submenu_page(
			self::SLUG,
			__( 'Add Affiliate', 'asteris-affiliates' ),
			'+ Add Affiliate',
			self::CAP,
			self::SLUG . '-add',
			[ Page_Add_Affiliate::class, 'render' ]
		);

		// Real pages (Sprint 4)
		add_submenu_page(
			self::SLUG, __( 'Commissions', 'asteris-affiliates' ), 'Commissions',
			self::CAP, self::SLUG . '-commissions', [ Page_Commissions::class, 'render' ]
		);
		add_submenu_page(
			self::SLUG, __( 'Coupons', 'asteris-affiliates' ), 'Coupons',
			self::CAP, self::SLUG . '-coupons', [ Page_Coupons::class, 'render' ]
		);

		// Real pages (Sprint 5A)
		add_submenu_page( self::SLUG, __( 'Emails',       'asteris-affiliates' ), 'Emails',       self::CAP, self::SLUG . '-emails',   [ Page_Emails::class,   'render' ] );
		add_submenu_page( self::SLUG, __( 'Reports',      'asteris-affiliates' ), 'Reports',      self::CAP, self::SLUG . '-reports',  [ Page_Reports::class,  'render' ] );
		add_submenu_page( self::SLUG, __( 'Activity log', 'asteris-affiliates' ), 'Activity log', self::CAP, self::SLUG . '-activity', [ Page_Activity::class, 'render' ] );

		// Real payouts page (Sprint 5B)
		add_submenu_page( self::SLUG, __( 'Payouts', 'asteris-affiliates' ), 'Payouts',
			self::CAP, self::SLUG . '-payouts', [ Page_Payouts::class, 'render' ] );

		// v1.1.2 — pages for new engines
		add_submenu_page( self::SLUG, __( 'Swipe Copy', 'asteris-affiliates' ), 'Swipe Copy',
			self::CAP, self::SLUG . '-swipe', [ Page_Swipe_Copy::class, 'render' ] );
		add_submenu_page( self::SLUG, __( 'Landing Pages', 'asteris-affiliates' ), 'Landing Pages',
			self::CAP, self::SLUG . '-landing', [ Page_Landing_Pages::class, 'render' ] );
		add_submenu_page( self::SLUG, __( 'A/B Tests', 'asteris-affiliates' ), 'A/B Tests',
			self::CAP, self::SLUG . '-ab', [ Page_AB_Tests::class, 'render' ] );

		add_submenu_page(
			self::SLUG,
			__( 'Settings', 'asteris-affiliates' ),
			__( 'Settings', 'asteris-affiliates' ),
			self::CAP,
			self::SLUG . '-settings',
			[ Page_Settings::class, 'render' ]
		);

		// v1.1.2 — Free vs Pro status (always visible)
		add_submenu_page( self::SLUG, __( 'Free vs Pro', 'asteris-affiliates' ), '✨ Free vs Pro',
			self::CAP, self::SLUG . '-free-tier', [ Page_Free_Tier_Status::class, 'render' ] );

		// Sprint 2 helper — retired in Sprint 3
		add_submenu_page(
			self::SLUG,
			__( 'Test Tracking', 'asteris-affiliates' ),
			'🧪 Test Tracking',
			self::CAP,
			self::SLUG . '-test',
			[ Page_Test_Tracking::class, 'render' ]
		);

		// v1.2.2 — License submenu (last item). Links to the Asteris Installer
		// plugin's central licence/installer page. The Installer is the
		// recommended pre-install: customers install asteris-installer once,
		// punch in their licence keys there, then it installs + activates the
		// paid plugins (WC, WP, Cart, Affiliates) automatically.
		//
		// If the Installer is active in this WP install, the submenu deep-links
		// directly to its top-level admin page (?page=asteris-installer).
		// If the Installer is NOT installed, the submenu renders a fallback
		// page explaining what it is + how to install it.
		add_submenu_page(
			self::SLUG,
			__( 'License', 'asteris-affiliates' ),
			'🔑 License',
			self::CAP,
			self::installer_active() ? 'asteris-installer' : self::SLUG . '-license-fallback',
			self::installer_active() ? '' : [ self::class, 'render_installer_missing' ]
		);
	}

	/**
	 * True when the Asteris Installer plugin is active in this WP install.
	 * The Installer registers a top-level menu under slug 'asteris-installer'
	 * (per AsterisInstaller\Admin_Page::SLUG).
	 */
	public static function installer_active(): bool {
		return class_exists( '\\AsterisInstaller\\Admin_Page' );
	}

	/**
	 * Fallback page shown when the customer clicks "License" but the Asteris
	 * Installer plugin isn't installed yet. Explains what to install and why.
	 */
	public static function render_installer_missing(): void {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		?>
		<div class="wrap" style="max-width:760px;">
			<h1 style="display:flex;align-items:center;gap:10px;">
				<span style="color:#06D6A0;font-size:28px;line-height:1;">🔑</span>
				Asteris Affiliates · License
			</h1>

			<div style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:24px 28px;margin-top:18px;">
				<p style="font-size:15px;line-height:1.65;color:#0a0a0a;margin:0 0 16px;">
					Licence management for Asteris plugins lives in a dedicated <strong>Asteris Installer</strong> plugin — a small helper that centralises licence keys for every Asteris product you run (WC, WP, Cart, Affiliates).
				</p>
				<p style="font-size:14.5px;line-height:1.65;color:#374151;margin:0 0 16px;">
					Install it once, paste your licence key there, and the Installer handles activation across every Asteris plugin on this site. You won't need to enter the same key in each plugin separately.
				</p>

				<h2 style="font-size:16px;margin:22px 0 10px;">How to install</h2>
				<ol style="font-size:14.5px;line-height:1.7;color:#374151;padding-left:20px;">
					<li>Open <a href="https://pay.asteriscommerce.com/account" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;">your account at pay.asteriscommerce.com</a> and download the Asteris Installer plugin (free, ships with every licence).</li>
					<li>WP admin → Plugins → Add New → Upload Plugin → choose the Installer ZIP.</li>
					<li>Activate. A new <strong>★ Asteris</strong> top-level menu appears in WP admin.</li>
					<li>Click into it, paste your licence key, hit Save.</li>
					<li>Come back to this page — the "License" link in the Affiliates sidebar will now jump straight to the Installer's licence management screen.</li>
				</ol>

				<p style="font-size:13.5px;color:#6b7280;margin:18px 0 0;line-height:1.55;">
					Already have the Installer running on another site? <a href="<?php echo esc_url( admin_url( 'plugin-install.php?tab=upload' ) ); ?>" style="color:#06D6A0;font-weight:600;">Upload it here</a> and your licence will activate immediately.
				</p>
			</div>

			<div style="background:#f8fafc;border:1px solid #e5e7eb;border-radius:6px;padding:14px 18px;margin-top:14px;font-size:13.5px;color:#475569;">
				<strong style="color:#0a0a0a;">Don't have a paid licence yet?</strong> Asteris Affiliates Free runs without one — up to 25 affiliates, single-tier referrals, manual payouts. <a href="https://asterisaffiliates.com/pricing" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:600;">See paid pricing →</a>
			</div>
		</div>
		<?php
	}
}
