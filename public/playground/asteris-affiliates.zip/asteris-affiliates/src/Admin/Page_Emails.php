<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Admin;

use AsterisAffiliates\Email\Renderer;
use AsterisAffiliates\Email\Template_Registry;
use AsterisAffiliates\Email\Template_Store;

defined( 'ABSPATH' ) || exit;

/**
 * Emails admin — list + edit + preview + send + sent log.
 *
 * Routes:
 *   ?page=asteris-affiliates-emails              → list
 *   ?page=asteris-affiliates-emails&edit=SLUG    → edit + preview + send
 *
 * Ported from the licence-server's Page_Emails — same WYSIWYG + override
 * UX, affiliate-specific defaults via Template_Registry.
 */
final class Page_Emails {

	public static function register(): void {
		add_action( 'admin_post_asteris_aff_email_save',    [ self::class, 'handle_save' ] );
		add_action( 'admin_post_asteris_aff_email_restore', [ self::class, 'handle_restore' ] );
		add_action( 'admin_post_asteris_aff_email_send',    [ self::class, 'handle_send' ] );
	}

	public static function render(): void {
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$edit = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : '';
		if ( $edit !== '' ) { self::render_edit( $edit ); return; }
		self::render_list();
	}

	private static function render_list(): void {
		$flash = self::flash();
		?>
		<div class="wrap">
			<h1>Emails</h1>
			<p style="color:#666;max-width:780px;">Every transactional email Asteris Affiliates can send. Edit the copy, preview against sample data, send a test or real email to anyone. Edits override the baked-in default — <strong>Restore default</strong> reverts at any time.</p>
			<?php self::render_flash( $flash ); ?>

			<?php foreach ( [ 'affiliate' => 'Affiliate-facing', 'admin' => 'Admin notifications' ] as $group => $label ) : ?>
				<h2 style="margin-top:28px;"><?php echo esc_html( $label ); ?></h2>
				<table class="widefat striped">
					<thead><tr>
						<th style="width:280px;">Template</th>
						<th>Description</th>
						<th style="width:120px;">Status</th>
						<th style="width:90px;">Action</th>
					</tr></thead>
					<tbody>
						<?php foreach ( Template_Registry::by_group( $group ) as $slug => $tpl_label ) :
							$def       = Template_Registry::get( $slug );
							$is_custom = Template_Store::has_override( $slug );
							$edit_url  = admin_url( 'admin.php?page=asteris-affiliates-emails&edit=' . $slug );
						?>
							<tr>
								<td><strong><a href="<?php echo esc_url( $edit_url ); ?>" style="text-decoration:none;color:#06D6A0;"><?php echo esc_html( $tpl_label ); ?></a></strong>
									<div style="color:#999;font-size:11px;font-family:ui-monospace,monospace;">{{<?php echo esc_html( $slug ); ?>}}</div></td>
								<td style="color:#4b5563;font-size:13px;"><?php echo esc_html( (string) ( $def['description'] ?? '' ) ); ?></td>
								<td><?php if ( $is_custom ) : ?>
									<span style="background:#fff7ed;color:#9a3412;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;">Customised</span>
								<?php else : ?>
									<span style="background:#f3f4f6;color:#6b7280;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;">Default</span>
								<?php endif; ?></td>
								<td><a class="button button-small" href="<?php echo esc_url( $edit_url ); ?>">Edit →</a></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endforeach; ?>

			<h2 style="margin-top:28px;">Recent sends</h2>
			<?php self::render_sent_log(); ?>
		</div>
		<?php
	}

	private static function render_sent_log(): void {
		global $wpdb;
		$rows = $wpdb->get_results(
			"SELECT occurred_at, event_type, actor, payload
			 FROM {$wpdb->prefix}aff_events
			 WHERE event_type IN ('email.sent','email.failed')
			 ORDER BY id DESC LIMIT 30"
		);
		if ( ! $rows ) { echo '<p style="color:#999;">No sends yet.</p>'; return; }
		?>
		<table class="widefat striped">
			<thead><tr><th style="width:170px;">When (UTC)</th><th style="width:80px;">Result</th><th style="width:220px;">Template</th><th>To</th><th>Subject</th></tr></thead>
			<tbody><?php foreach ( $rows as $r ) :
				$p = (array) json_decode( (string) $r->payload, true );
				$ok = $r->event_type === 'email.sent';
			?>
				<tr>
					<td style="color:#666;font-family:ui-monospace,monospace;font-size:11px;"><?php echo esc_html( $r->occurred_at ); ?></td>
					<td><?php echo $ok ? '<span style="color:#059669;font-weight:700;">✓ sent</span>' : '<span style="color:#dc2626;font-weight:700;">✗ failed</span>'; ?></td>
					<td><code><?php echo esc_html( (string) ( $p['template'] ?? '?' ) ); ?></code></td>
					<td><?php echo esc_html( (string) ( $p['to'] ?? '?' ) ); ?></td>
					<td style="color:#4b5563;font-size:12px;"><?php echo esc_html( (string) ( $p['subject'] ?? '?' ) ); ?></td>
				</tr>
			<?php endforeach; ?></tbody>
		</table>
		<?php
	}

	private static function render_edit( string $slug ): void {
		$def = Template_Registry::get( $slug );
		if ( ! $def ) {
			echo '<div class="wrap"><h1>Unknown template</h1><p><a href="' . esc_url( admin_url( 'admin.php?page=asteris-affiliates-emails' ) ) . '">← Back</a></p></div>';
			return;
		}
		$eff       = Template_Store::effective( $slug );
		$preview   = Renderer::render_sample( $slug );
		$flash     = self::flash();
		$is_custom = Template_Store::has_override( $slug );
		$sample    = (array) ( $def['sample'] ?? [] );
		?>
		<div class="wrap">
			<h1><a href="<?php echo esc_url( admin_url( 'admin.php?page=asteris-affiliates-emails' ) ); ?>" style="text-decoration:none;color:#06D6A0;">← Emails</a> · <?php echo esc_html( (string) $def['label'] ); ?></h1>
			<p style="color:#666;max-width:780px;"><?php echo esc_html( (string) ( $def['description'] ?? '' ) ); ?></p>
			<?php self::render_flash( $flash ); ?>

			<div style="display:grid;grid-template-columns:1fr 380px;gap:24px;margin-top:18px;">
				<div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'asteris_aff_email_save_' . $slug ); ?>
						<input type="hidden" name="action" value="asteris_aff_email_save">
						<input type="hidden" name="slug" value="<?php echo esc_attr( $slug ); ?>">

						<h2>Subject</h2>
						<input type="text" name="subject" value="<?php echo esc_attr( $eff['subject'] ); ?>" required style="width:100%;font-size:14px;">

						<h2>Body</h2>
						<p style="color:#666;font-size:12px;margin:0 0 8px;">Visual or HTML mode — placeholders like <code>{{display_name}}</code> work in both.</p>
						<?php
						wp_editor( $eff['body'], 'aff_email_body_' . str_replace( [ '-', '.' ], '_', $slug ), [
							'textarea_name' => 'body',
							'textarea_rows' => 18,
							'media_buttons' => true,
							'teeny'         => false,
						] );
						?>

						<p style="margin-top:14px;">
							<button type="submit" class="button button-primary" style="background:#06D6A0;border-color:#06D6A0;">Save override</button>
							<?php if ( $is_custom ) : ?>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=asteris_aff_email_restore&slug=' . $slug ), 'asteris_aff_email_restore_' . $slug ) ); ?>" class="button" onclick="return confirm('Restore baked-in default? Your customisations will be lost.');">↻ Restore default</a>
							<?php endif; ?>
						</p>
					</form>

					<hr style="margin:24px 0;">

					<h2>Send (test or real)</h2>
					<p style="color:#666;font-size:13px;">Renders the EFFECTIVE template against sample data → wp_mail → logs to Recent sends.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px;align-items:end;flex-wrap:wrap;">
						<?php wp_nonce_field( 'asteris_aff_email_send_' . $slug ); ?>
						<input type="hidden" name="action" value="asteris_aff_email_send">
						<input type="hidden" name="slug" value="<?php echo esc_attr( $slug ); ?>">
						<label>To: <input type="email" name="to" required style="font-size:14px;min-width:280px;" placeholder="recipient@example.com"></label>
						<button type="submit" class="button button-primary" style="background:#059669;border-color:#059669;">Send →</button>
					</form>
				</div>

				<div>
					<h2 style="margin-top:0;">Live preview</h2>
					<div style="border:1px solid #e5e7eb;border-radius:6px;background:#fafafa;padding:12px;margin-bottom:12px;font-size:12px;">
						<div style="color:#9ca3af;font-size:11px;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:2px;">Subject</div>
						<div style="font-weight:600;color:#0a0a0a;"><?php echo esc_html( $preview['subject'] ); ?></div>
					</div>
					<div style="border:1px solid #e5e7eb;border-radius:6px;background:#fff;padding:16px;max-height:480px;overflow:auto;font-size:13px;"><?php echo wp_kses_post( $preview['body'] ); ?></div>

					<h2>Placeholders</h2>
					<p style="color:#666;font-size:12px;">Click to copy. <strong style="color:#9a3412;">★</strong> = required.</p>
					<?php $required = (array) ( $def['required'] ?? [] ); ?>
					<div style="display:flex;flex-wrap:wrap;gap:6px;">
						<?php foreach ( (array) ( $def['placeholders'] ?? [] ) as $name => $desc ) :
							$req = in_array( $name, $required, true ); ?>
							<button type="button" onclick="navigator.clipboard.writeText('{{<?php echo esc_js( $name ); ?>}}');this.innerText='copied!';setTimeout(()=>{this.innerText='{{<?php echo esc_js( $name ); ?>}}'+(<?php echo $req ? 'true' : 'false'; ?>?' ★':'');},900);"
								title="<?php echo esc_attr( $desc ); ?>"
								style="background:<?php echo $req ? '#fff7ed' : '#f3f4f6'; ?>;border:1px solid <?php echo $req ? '#fed7aa' : '#d1d5db'; ?>;border-radius:4px;padding:3px 8px;font-family:ui-monospace,monospace;font-size:11px;cursor:pointer;color:<?php echo $req ? '#9a3412' : '#374151'; ?>;">
								{{<?php echo esc_html( $name ); ?>}}<?php echo $req ? ' ★' : ''; ?>
							</button>
						<?php endforeach; ?>
					</div>

					<h2>Sample data</h2>
					<pre style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:10px;font-size:11px;overflow:auto;max-height:200px;"><?php echo esc_html( (string) wp_json_encode( $sample, JSON_PRETTY_PRINT ) ); ?></pre>
				</div>
			</div>
		</div>
		<?php
	}

	// ── Handlers ────────────────────────────────────────────────────────────

	public static function handle_save(): void {
		$slug = isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
		check_admin_referer( 'asteris_aff_email_save_' . $slug );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }

		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$body    = isset( $_POST['body'] ) ? wp_unslash( $_POST['body'] ) : '';

		$res = Template_Store::save_override( $slug, $subject, $body );
		if ( is_wp_error( $res ) ) {
			self::redirect_edit( $slug, 'save_failed', $res->get_error_message() );
		}
		self::redirect_edit( $slug, 'saved' );
	}

	public static function handle_restore(): void {
		$slug = isset( $_GET['slug'] ) ? sanitize_key( wp_unslash( $_GET['slug'] ) ) : '';
		check_admin_referer( 'asteris_aff_email_restore_' . $slug );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		Template_Store::restore_default( $slug );
		self::redirect_edit( $slug, 'restored' );
	}

	public static function handle_send(): void {
		$slug = isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
		check_admin_referer( 'asteris_aff_email_send_' . $slug );
		if ( ! current_user_can( Menu::CAP ) ) { wp_die( 'Forbidden', 403 ); }
		$to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
		if ( ! is_email( $to ) ) { self::redirect_edit( $slug, 'send_bad_email' ); }
		$def = Template_Registry::get( $slug );
		$sample = is_array( $def ) ? (array) ( $def['sample'] ?? [] ) : [];
		$ok = Renderer::send_template( $slug, $to, $sample );
		self::redirect_edit( $slug, $ok ? 'send_ok' : 'send_failed', $to );
	}

	private static function redirect_edit( string $slug, string $flash, string $extra = '' ): void {
		$args = [ 'page' => 'asteris-affiliates-emails', 'edit' => $slug, 'flash' => $flash ];
		if ( $extra !== '' ) { $args['extra'] = $extra; }
		wp_safe_redirect( admin_url( 'admin.php?' . http_build_query( $args ) ) );
		exit;
	}

	private static function flash(): array {
		return [
			'flash' => isset( $_GET['flash'] ) ? sanitize_key( wp_unslash( $_GET['flash'] ) ) : '',
			'extra' => isset( $_GET['extra'] ) ? sanitize_text_field( wp_unslash( $_GET['extra'] ) ) : '',
		];
	}

	private static function render_flash( array $f ): void {
		$msgs = [
			'saved'          => [ 'ok',   '✓ Override saved.' ],
			'save_failed'    => [ 'err',  '✗ Save failed: ' . esc_html( $f['extra'] ) ],
			'restored'       => [ 'ok',   '✓ Reverted to baked-in default.' ],
			'send_ok'        => [ 'ok',   '✓ Email sent to ' . esc_html( $f['extra'] ) . '.' ],
			'send_failed'    => [ 'err',  '✗ wp_mail returned false for ' . esc_html( $f['extra'] ) . '.' ],
			'send_bad_email' => [ 'err',  '✗ Invalid email address.' ],
		];
		if ( ! isset( $msgs[ $f['flash'] ] ) ) { return; }
		[ $kind, $html ] = $msgs[ $f['flash'] ];
		$style = $kind === 'ok'
			? 'background:#ecfdf5;border-left:4px solid #059669;color:#065f46;'
			: 'background:#fef2f2;border-left:4px solid #dc2626;color:#991b1b;';
		echo '<div class="notice is-dismissible" style="padding:12px 16px;margin:12px 0;' . esc_attr( $style ) . '"><p style="margin:0;">' . $html . '</p></div>'; // phpcs:ignore
	}
}
