<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Denormalised aggregates on the aff_affiliates row.
 *
 * Why: at 1000+ affiliates with 10k+ commissions, the per-row sum/count
 * queries in Reports + Dashboard widget + Stats API become slow. We cache
 * the totals on the affiliate row and refresh:
 *
 *   - synchronously when a commission row mutates (insert / status change)
 *   - on a daily cron sweep (full recompute, safety net for any missed hooks)
 *   - via `wp asteris-affiliates recompute-aggregates` for manual rebuild
 *
 * Columns kept fresh:
 *   - lifetime_earnings_cents     (SUM amount_cents where status in approved|paid)
 *   - lifetime_referrals          (COUNT referrals)
 *   - pending_balance_cents       (SUM where status = pending)
 *   - approved_balance_cents      (SUM where status = approved)
 *   - paid_balance_cents          (SUM where status = paid)
 *   - aggregates_updated_at
 */
final class Aggregates_Service {

	/** Recompute ALL affiliates. Used by daily cron + WP-CLI. */
	public static function recompute_all(): int {
		global $wpdb;
		$p   = $wpdb->prefix;
		$ids = $wpdb->get_col( "SELECT id FROM {$p}aff_affiliates" );
		$count = 0;
		foreach ( $ids as $id ) {
			self::recompute_for_affiliate( (int) $id );
			$count++;
		}
		return $count;
	}

	/** Recompute one affiliate. Called by commission-mutation hooks + manual. */
	public static function recompute_for_affiliate( int $affiliate_id ): void {
		global $wpdb;
		$p = $wpdb->prefix;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT
				COALESCE(SUM(CASE WHEN status = 'pending'  THEN amount_cents ELSE 0 END), 0) AS pending,
				COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_cents ELSE 0 END), 0) AS approved,
				COALESCE(SUM(CASE WHEN status = 'paid'     THEN amount_cents ELSE 0 END), 0) AS paid,
				COALESCE(SUM(CASE WHEN status IN ('approved','paid') THEN amount_cents ELSE 0 END), 0) AS lifetime
			 FROM {$p}aff_commissions
			 WHERE affiliate_id = %d",
			$affiliate_id
		), ARRAY_A );

		$referrals = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d",
			$affiliate_id
		) );

		$wpdb->update(
			$p . 'aff_affiliates',
			[
				'pending_balance_cents'  => (int) $row['pending'],
				'approved_balance_cents' => (int) $row['approved'],
				'paid_balance_cents'     => (int) $row['paid'],
				'lifetime_earnings_cents'=> (int) $row['lifetime'],
				'lifetime_referrals'     => $referrals,
				'aggregates_updated_at'  => current_time( 'mysql', true ),
			],
			[ 'id' => $affiliate_id ]
		);
	}

	/**
	 * Hook into commission mutations. Called from Engine + Refund_Hook +
	 * Approval_Scanner + Batch_Cron via do_action( 'asteris_aff_commission_changed', $affiliate_id ).
	 */
	public static function register(): void {
		add_action( 'asteris_aff_commission_changed', [ self::class, 'recompute_for_affiliate' ] );
		add_action( 'asteris_aff_recompute_daily',    [ self::class, 'recompute_all' ] );
	}
}
