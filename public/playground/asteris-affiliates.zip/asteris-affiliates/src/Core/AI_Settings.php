<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

use AsterisAffiliates\Core\Util\Crypto;
use AsterisShared\AI\Router;

defined( 'ABSPATH' ) || exit;

/**
 * Storage + retrieval for BYO AI keys + the configured default model.
 *
 * Keys are encrypted at rest via the per-plugin Crypto helper (AES-256-CBC,
 * AUTH_SALT-derived key). Plaintext never persists; never log it; never
 * surface it in REST.
 *
 * Read path: get_keys_for_router() → array passed straight into
 * Router::generate() opts so callers don't touch Crypto directly.
 */
final class AI_Settings {

	public const OPT_OPENAI_KEY    = 'asteris_aff_ai_openai_key';
	public const OPT_ANTHROPIC_KEY = 'asteris_aff_ai_anthropic_key';
	public const OPT_DEFAULT_MODEL = 'asteris_aff_ai_default_model';

	/**
	 * Models we surface in the UI dropdown. Keys are passed to
	 * Router::generate() verbatim; labels are human-readable.
	 */
	public static function model_choices(): array {
		return [
			'claude-haiku-4-5'  => 'Claude Haiku 4.5 (fast, cheap — recommended)',
			'claude-sonnet-4-6' => 'Claude Sonnet 4.6 (balanced)',
			'claude-opus-4-8'   => 'Claude Opus 4.8 (highest quality)',
			'gpt-4o-mini'       => 'GPT-4o mini (fast, cheap)',
			'gpt-4o'            => 'GPT-4o (balanced)',
		];
	}

	public static function default_model(): string {
		$m = (string) get_option( self::OPT_DEFAULT_MODEL, '' );
		return $m !== '' && isset( self::model_choices()[ $m ] ) ? $m : Router::DEFAULT_MODEL;
	}

	public static function set_default_model( string $model ): void {
		if ( isset( self::model_choices()[ $model ] ) ) {
			update_option( self::OPT_DEFAULT_MODEL, $model, false );
		}
	}

	/** True iff at least one vendor key is stored. */
	public static function has_any_key(): bool {
		return self::get_openai_key() !== '' || self::get_anthropic_key() !== '';
	}

	public static function get_openai_key(): string {
		return self::decrypt_option( self::OPT_OPENAI_KEY );
	}

	public static function get_anthropic_key(): string {
		return self::decrypt_option( self::OPT_ANTHROPIC_KEY );
	}

	public static function set_openai_key( string $plaintext ): void {
		self::store_key( self::OPT_OPENAI_KEY, $plaintext );
	}

	public static function set_anthropic_key( string $plaintext ): void {
		self::store_key( self::OPT_ANTHROPIC_KEY, $plaintext );
	}

	/**
	 * Returns a partial mask of the stored key for UI ("sk-…abc4"), or '' if
	 * none stored. Never returns the full plaintext.
	 */
	public static function masked( string $opt ): string {
		$plain = self::decrypt_option( $opt );
		if ( $plain === '' ) { return ''; }
		$len = strlen( $plain );
		if ( $len <= 8 ) { return str_repeat( '•', $len ); }
		return substr( $plain, 0, 3 ) . str_repeat( '•', 4 ) . substr( $plain, -4 );
	}

	/**
	 * Build the `opts` payload Router::generate() expects, pre-populated with
	 * any stored keys. Callers can layer extra opts (max_tokens, system, …)
	 * on top via array_merge.
	 */
	public static function get_keys_for_router(): array {
		$out = [];
		$o = self::get_openai_key();
		$a = self::get_anthropic_key();
		if ( $o !== '' ) { $out['openai_key']    = $o; }
		if ( $a !== '' ) { $out['anthropic_key'] = $a; }
		return $out;
	}

	// ── Internals ───────────────────────────────────────────────────────────

	private static function decrypt_option( string $opt ): string {
		$cipher = (string) get_option( $opt, '' );
		if ( $cipher === '' ) { return ''; }
		$plain = Crypto::decrypt( $cipher );
		return is_string( $plain ) ? $plain : '';
	}

	private static function store_key( string $opt, string $plaintext ): void {
		$plaintext = trim( $plaintext );
		if ( $plaintext === '' ) {
			delete_option( $opt );
			return;
		}
		update_option( $opt, Crypto::encrypt( $plaintext ), false );
	}
}
