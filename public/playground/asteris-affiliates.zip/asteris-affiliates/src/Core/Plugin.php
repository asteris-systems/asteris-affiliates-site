<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

use AsterisAffiliates\Adapters\EDD_Adapter;
use AsterisAffiliates\Adapters\Surecart_Adapter;
use AsterisAffiliates\Admin\Bulk_Handler;
use AsterisAffiliates\Admin\CSV_Export;
use AsterisAffiliates\Admin\Dashboard_Widget;
use AsterisAffiliates\Admin\Impersonation;
use AsterisAffiliates\Admin\Menu;
use AsterisAffiliates\Affiliates\Signup_Form;
use AsterisAffiliates\Anti_Fraud\Cloud_Assist;
use AsterisAffiliates\Commissions\Tier2_Engine;
use AsterisAffiliates\Cron\Daily_Cron;
use AsterisAffiliates\DB\Migration;
use AsterisAffiliates\Email\AB_Engine;
use AsterisAffiliates\Payouts\PayPal_API;
use AsterisAffiliates\Public_\Landing_Page_Router;
use AsterisAffiliates\Public_\Portal_Router;
use AsterisAffiliates\REST\Stats_API;
use AsterisAffiliates\Swipe_Copy\Library as Swipe_Library;
use AsterisAffiliates\Tracking\Click_Tracker;
use AsterisAffiliates\WC\Order_Hook;
use AsterisAffiliates\WC\Product_Rates;
use AsterisAffiliates\WC\Refund_Hook;
use AsterisAffiliates\WC\Subscription_Hook;

defined( 'ABSPATH' ) || exit;

/**
 * Main plugin orchestrator. Singleton so add-on modules can call
 * Plugin::instance() to get a handle.
 *
 * v1.1 additions in registration order:
 *   - Aggregates_Service hook (commission_changed)
 *   - Tier2_Engine MLM
 *   - Product_Rates per-product overrides
 *   - PayPal_API auto-batch
 *   - Cloud_Assist fraud sync
 *   - AB_Engine email variant routing + open-pixel handler
 *   - Landing_Page_Router /go/{handle}
 *   - Impersonation start/stop
 *   - Bulk_Handler + CSV_Export admin endpoints
 *   - Dashboard_Widget
 *   - EDD / Surecart order-source adapters
 *   - License Client wiring
 *   - WP-CLI commands
 *   - Onboarding_Wizard intercept (wired in Portal_Router)
 *   - Swipe_Copy seed on first activate
 *   - Mobile portal CSS enqueue
 */
final class Plugin {

	private static ?self $instance = null;

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	private function __construct() {
		Migration::maybe_upgrade();
		Swipe_Library::install_default_seeds();

		// Sprint 9C — aggregates hook (re-derives row totals on commission mutate)
		Aggregates_Service::register();

		// Admin area
		if ( is_admin() ) {
			Menu::register();
			Bulk_Handler::register();
			CSV_Export::register();
			Dashboard_Widget::register();
		}
		Impersonation::register();

		// Tracking / WC
		Click_Tracker::register();
		Signup_Form::register();
		Portal_Router::register();
		Order_Hook::register();
		Refund_Hook::register();
		Subscription_Hook::register();
		Product_Rates::register();         // 9B — per-product rates

		// ── Pro-tier gated modules ──────────────────────────────────────
		// Loaded UNCONDITIONALLY for code paths that still need the class
		// (e.g. admin pages), but each module's runtime path checks
		// Free_Tier::feature(<slug>) before doing work.
		Tier2_Engine::register();          // 10+ — MLM (Pro · gated)
		PayPal_API::register();            // 10+ — PayPal API (Pro · gated)
		Cloud_Assist::register();          // 10+ — fraud sync (Pro · gated)
		AB_Engine::register();             // 10+ — A/B emails (Pro · gated)
		Landing_Page_Router::register();   // 10+ — landing pages (Pro · gated)

		// EDD + Surecart adapters — Pro only (free tier is WC-only)
		if ( Free_Tier::is_pro() ) {
			EDD_Adapter::register();
			Surecart_Adapter::register();
		}

		// Cron + payouts (cron itself runs free; gated features inside skip)
		Daily_Cron::register();

		// REST
		add_action( 'rest_api_init', [ Stats_API::class, 'register' ] );
		add_action( 'rest_api_init', [ \AsterisAffiliates\Payouts\Stripe_Webhook::class, 'register' ] );

		// Free-tier admin banner
		if ( is_admin() && Free_Tier::is_free() ) {
			add_action( 'admin_notices', static function () {
				$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
				if ( $screen && str_contains( (string) $screen->id, 'asteris-affiliates' ) ) {
					Free_Tier::render_admin_banner();
				}
			} );
		}

		// Self-hosted updater (existing)
		if ( class_exists( '\\AsterisShared\\License\\Updater' ) ) {
			\AsterisShared\License\Updater::init( [
				'product'         => 'asteris_affiliates',
				'plugin_file'     => ASTERIS_AFFILIATES_FILE,
				'current_version' => ASTERIS_AFFILIATES_VERSION,
				'opt_key_name'    => 'asteris_aff_license_key',
			] );
		}

		// WP-CLI commands (only loaded under wp-cli)
		if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( '\\AsterisAffiliates\\CLI\\Commands' ) ) {
			\AsterisAffiliates\CLI\Commands::register();
		}

		// Mobile portal CSS — front-end enqueue
		add_action( 'wp_enqueue_scripts', [ self::class, 'enqueue_portal_css' ] );
	}

	public static function enqueue_portal_css(): void {
		$uri  = (string) ( $_SERVER['REQUEST_URI'] ?? '' );
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		// Only on /affiliate-portal/ and /go/* pages
		if ( ! str_starts_with( $path, '/affiliate-portal' ) && ! str_starts_with( $path, '/go/' ) ) { return; }
		wp_enqueue_style(
			'asteris-affiliates-portal-mobile',
			ASTERIS_AFFILIATES_URL . 'assets/css/portal-mobile.css',
			[],
			ASTERIS_AFFILIATES_VERSION
		);
	}
}
