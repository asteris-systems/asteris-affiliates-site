<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

use AsterisAffiliates\DB\Migration;

defined( 'ABSPATH' ) || exit;

/**
 * Activation + deactivation hooks. Wire from the main bootstrap via
 * register_activation_hook() / register_deactivation_hook().
 */
final class Activation {

	public static function activate(): void {
		Migration::install();

		// Stamp the install version + activation time so we can detect
		// upgrades + offer migration notices later.
		add_option( 'asteris_aff_install_version', ASTERIS_AFFILIATES_VERSION, '', false );
		update_option( 'asteris_aff_activated_at', time(), false );

		// Schedule the daily anti-fraud + payout-status crons (Sprint 5/7
		// will add the callbacks; for now just schedule the slots so they
		// exist on first activation).
		if ( ! wp_next_scheduled( 'asteris_aff_daily' ) ) {
			wp_schedule_event( time() + 60, 'daily', 'asteris_aff_daily' );
		}
	}

	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'asteris_aff_daily' );
		// We do NOT drop tables here. Data preservation = sane UX. Uninstall
		// is opt-in via the standard WP uninstall flow (see uninstall.php).
	}
}
