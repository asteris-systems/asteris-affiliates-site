<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Free-tier feature gating.
 *
 * Asteris Affiliates ships with a free version on WordPress.org. When NO
 * valid Pro licence is active, this class enforces the free-tier limits:
 *
 *   ── Free tier ─────────────────────────────────────────────────────────
 *   ✓ 1 site                                  (enforced by licence server)
 *   ✓ Up to 10 active (approved) affiliates    ← capped here
 *   ✓ WC integration                           ← always on
 *   ✓ Click + commission tracking              ← always on
 *   ✓ Magic-link affiliate portal              ← always on
 *   ✓ Manual mark-paid payouts                 ← always on
 *   ✗ EDD / Surecart adapters                  ← blocked
 *   ✗ Stripe Connect auto-payouts              ← blocked
 *   ✗ PayPal Payouts API                       ← blocked
 *   ✗ Recurring commissions (WC Subscriptions) ← blocked
 *   ✗ MLM / two-tier                           ← blocked
 *   ✗ AI swipe-copy generator                  ← blocked
 *   ✗ Vanity landing pages                     ← blocked
 *   ✗ A/B email tests                          ← blocked
 *   ✗ Cloud-assist fraud                       ← blocked
 *   ✗ Refund-rate auto-suspend                 ← blocked
 *   ✗ Premium support                          ← blocked (forum-first)
 *
 * Pro licence resolves via `AsterisShared\License\Client` — checked once per
 * load, cached in static property for the request.
 *
 * Admin UI: Pro-only features show a teal "PRO" badge + upgrade-CTA link
 * to asterisaffiliates.com/pricing when triggered without a licence.
 */
final class Free_Tier {

	private static ?bool $is_pro = null;
	public const FREE_AFFILIATE_CAP = 10;

	/** Returns true if a valid Pro licence is active. */
	public static function is_pro(): bool {
		if ( self::$is_pro !== null ) { return self::$is_pro; }
		if ( ! class_exists( '\\AsterisShared\\License\\Client' ) ) {
			self::$is_pro = false;
			return false;
		}
		// Defensive guard: AsterisShared\License\Client is vendored into every
		// Asteris plugin (WC, WP, Cart, Affiliates). When two or more are active
		// at once, whichever plugin's autoloader fires first wins — and older
		// vendored copies may not have ::for_product(). Without this guard,
		// the call below fatals during plugins_loaded if a sister plugin loaded
		// an older Client class first. v1.2.0 -> 1.2.1 hotfix (8 Jun 2026).
		if ( ! method_exists( '\\AsterisShared\\License\\Client', 'for_product' ) ) {
			self::$is_pro = false;
			return false;
		}
		$client = \AsterisShared\License\Client::for_product( 'asteris_affiliates', 'asteris_aff_license_key' );
		$state  = $client->status();
		self::$is_pro = ( $state === 'active' );
		return self::$is_pro;
	}

	/** Hard inverse — most call-sites read this. */
	public static function is_free(): bool {
		return ! self::is_pro();
	}

	/** Test-only override. */
	public static function set_pro_override( ?bool $value ): void {
		self::$is_pro = $value;
	}

	/**
	 * Returns true if a new affiliate can be approved (capped at 10 on free).
	 * Engine checks this before flipping pending → approved. Pending applications
	 * are NOT capped — only approved/active count.
	 */
	public static function can_approve_more_affiliates(): bool {
		if ( self::is_pro() ) { return true; }
		global $wpdb;
		$count = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}aff_affiliates WHERE status = 'approved'"
		);
		return $count < self::FREE_AFFILIATE_CAP;
	}

	/** Get the current approved count (for admin UI badges). */
	public static function current_approved_count(): int {
		global $wpdb;
		return (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}aff_affiliates WHERE status = 'approved'"
		);
	}

	/**
	 * Feature gate. Returns true if feature is available.
	 * Logs a "feature_blocked" event when blocked so admin can see what got
	 * gated.
	 *
	 * Features:
	 *   'stripe_connect_auto', 'paypal_api_auto', 'recurring_commissions',
	 *   'mlm', 'ai_swipe_copy', 'landing_pages', 'ab_emails',
	 *   'cloud_fraud', 'auto_suspend', 'edd_adapter', 'surecart_adapter'
	 */
	public static function feature( string $feature ): bool {
		if ( self::is_pro() ) { return true; }

		// Throttle the block-log so we don't spam events on every page load
		$throttle_key = 'asteris_aff_block_logged_' . md5( $feature );
		if ( ! get_transient( $throttle_key ) ) {
			global $wpdb;
			$wpdb->insert( $wpdb->prefix . 'aff_events', [
				'occurred_at'  => current_time( 'mysql', true ),
				'event_type'   => 'free_tier.feature_blocked',
				'affiliate_id' => null,
				'actor'        => 'system',
				'payload'      => wp_json_encode( [ 'feature' => $feature ] ),
			] );
			set_transient( $throttle_key, 1, HOUR_IN_SECONDS );
		}
		return false;
	}

	/** Render a "PRO" badge for admin UI. */
	public static function pro_badge( string $tooltip = '' ): string {
		$title = $tooltip !== '' ? $tooltip : __( 'Available on the Pro tier', 'asteris-affiliates' );
		return '<span title="' . esc_attr( $title ) . '" style="display:inline-block;background:#06D6A0;color:#fff;padding:2px 6px;border-radius:3px;font-size:9px;font-weight:800;letter-spacing:0.05em;vertical-align:middle;margin-left:6px;">PRO</span>';
	}

	/** Render the upgrade CTA link. */
	public static function upgrade_cta( string $context = '' ): string {
		$url = 'https://asterisaffiliates.com/pricing?utm_source=plugin&utm_medium=upgrade_cta&utm_campaign=' . urlencode( $context !== '' ? $context : 'feature_gate' );
		return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" style="color:#06D6A0;font-weight:700;text-decoration:none;">' . esc_html__( 'Upgrade to Pro →', 'asteris-affiliates' ) . '</a>';
	}

	/** Render the dashboard banner shown above admin pages on free tier. */
	public static function render_admin_banner(): void {
		if ( self::is_pro() ) { return; }
		$count = self::current_approved_count();
		$pct   = (int) min( 100, round( ( $count / self::FREE_AFFILIATE_CAP ) * 100 ) );
		$near  = $count >= ( self::FREE_AFFILIATE_CAP - 2 );
		$bg    = $near ? '#fff8e1' : '#ecfdf5';
		$bar   = $near ? '#b45309' : '#06D6A0';
		?>
		<div style="background:<?php echo esc_attr( $bg ); ?>;border-left:4px solid <?php echo esc_attr( $bar ); ?>;border-radius:6px;padding:14px 18px;margin:14px 0 18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
			<div>
				<strong style="color:#0a0a0a;">
					<?php
					/* translators: %1$d = current count, %2$d = cap */
					echo esc_html( sprintf( __( 'Free tier · %1$d / %2$d affiliates approved', 'asteris-affiliates' ), $count, self::FREE_AFFILIATE_CAP ) );
					?>
				</strong>
				<div style="margin-top:6px;width:200px;height:5px;background:#e5e7eb;border-radius:99px;overflow:hidden;">
					<div style="width:<?php echo (int) $pct; ?>%;height:100%;background:<?php echo esc_attr( $bar ); ?>;"></div>
				</div>
			</div>
			<div style="text-align:right;font-size:13px;color:#666;">
				<?php esc_html_e( 'Unlimited affiliates + Stripe/PayPal automation + MLM + AI swipe copy + A/B email tests on Pro.', 'asteris-affiliates' ); ?>
				<br>
				<?php echo self::upgrade_cta( 'dashboard_banner' ); // phpcs:ignore ?>
			</div>
		</div>
		<?php
	}
}
