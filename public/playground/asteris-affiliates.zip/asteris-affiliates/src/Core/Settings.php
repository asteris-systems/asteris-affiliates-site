<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin-wide settings — single-option storage keyed by `asteris_aff_settings`.
 *
 * Defaults are baked here so a fresh install works without any admin
 * configuration — the customer can run a default 20% commission program
 * out of the box and tweak later.
 */
final class Settings {

	private const OPT_KEY = 'asteris_aff_settings';

	/** @return array<string,mixed> */
	private static function defaults(): array {
		return [
			// ── Commission rates (basis points: 2000 = 20.00%) ──────────
			'commission_rate_y1_bp'     => 2000,   // 20% Year 1
			'commission_rate_y2plus_bp' => 1000,   // 10% Year 2+
			'commission_currency'       => 'USD',  // can be overridden per-store

			// ── Refund window ────────────────────────────────────────────
			'refund_window_days'        => 30,     // 0–90; commissions stay 'pending' until past this
			'self_referral_block'       => 1,      // affiliate can't earn on their own orders

			// ── Attribution ──────────────────────────────────────────────
			'cookie_days'               => 60,
			'attribution_priority'      => 'coupon_first',  // coupon_first | link_first

			// ── Payouts ──────────────────────────────────────────────────
			'payout_min_cents'          => 10000,  // $100.00
			'payout_day_of_month'       => 1,
			'payout_methods_enabled'    => [ 'stripe_connect', 'bank_transfer' ],
			'stripe_secret_key'         => '',     // sk_live_xxx — empty = try WC Stripe / wp-config fallback
			'stripe_webhook_secret'     => '',     // whsec_xxx — Stripe Dashboard → Webhooks → endpoint signing secret

			// ── Affiliate signup ─────────────────────────────────────────
			'signup_requires_approval'  => 1,
			'signup_terms_url'          => '',

			// ── Signup form appearance (overridable per shortcode) ──────
			'signup_button_color'       => '#06D6A0',
			'signup_button_label'       => 'Apply to be an affiliate →',
			'signup_heading'            => 'Become an affiliate',
			'signup_intro'              => 'Earn commission on every customer you refer. Multi-tier rates, recurring renewals, monthly Stripe payouts.',
			'signup_show_first_last'    => 1,
			'signup_show_country'       => 1,
			'signup_show_audience'      => 1,
			'signup_show_promotion'     => 1,
			'signup_require_promotion'  => 1,

			// ── Anti-fraud ───────────────────────────────────────────────
			'auto_suspend_refund_rate_pct' => 20,  // suspend if >20% refund rate over 30d
			'block_bot_user_agents'     => 1,
			'block_ip_bursts'           => 1,

			// ── Email ────────────────────────────────────────────────────
			'send_admin_notifications'  => 1,
			'admin_notification_email'  => '',     // falls back to get_option('admin_email')

			// ── Branding ─────────────────────────────────────────────────
			'brand_colour'              => '#06D6A0',  // teal — Asteris Affiliates locked colour
		];
	}

	/** @return array<string,mixed> */
	public static function all(): array {
		$stored = get_option( self::OPT_KEY, [] );
		return array_merge( self::defaults(), is_array( $stored ) ? $stored : [] );
	}

	public static function get( string $key, mixed $fallback = null ): mixed {
		$all = self::all();
		return $all[ $key ] ?? $fallback;
	}

	/** @param array<string,mixed> $changes */
	public static function update( array $changes ): void {
		$current = self::all();
		$next    = array_merge( $current, $changes );
		update_option( self::OPT_KEY, $next, false );
	}

	public static function reset_to_defaults(): void {
		delete_option( self::OPT_KEY );
	}
}
