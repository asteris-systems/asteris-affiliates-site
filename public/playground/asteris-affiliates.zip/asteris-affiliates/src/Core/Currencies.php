<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Major-currency list for the commission-currency picker.
 *
 * Per Nick's rule: NO autodetection from WC. Admin explicitly picks.
 * Default = USD. Customers who want their store currency simply pick it.
 *
 * 25 most-traded global currencies — covers ~98% of real-world stores.
 * Customers in obscure currencies can filter `asteris_aff_currencies` to
 * add their own.
 */
final class Currencies {

	/**
	 * @return array<string,string> ISO-4217 code => human label
	 */
	public static function all(): array {
		$base = [
			'USD' => 'USD · US Dollar',
			'EUR' => 'EUR · Euro',
			'GBP' => 'GBP · British Pound',
			'AUD' => 'AUD · Australian Dollar',
			'CAD' => 'CAD · Canadian Dollar',
			'NZD' => 'NZD · New Zealand Dollar',
			'JPY' => 'JPY · Japanese Yen',
			'CHF' => 'CHF · Swiss Franc',
			'SEK' => 'SEK · Swedish Krona',
			'NOK' => 'NOK · Norwegian Krone',
			'DKK' => 'DKK · Danish Krone',
			'SGD' => 'SGD · Singapore Dollar',
			'HKD' => 'HKD · Hong Kong Dollar',
			'INR' => 'INR · Indian Rupee',
			'BRL' => 'BRL · Brazilian Real',
			'MXN' => 'MXN · Mexican Peso',
			'ZAR' => 'ZAR · South African Rand',
			'AED' => 'AED · UAE Dirham',
			'SAR' => 'SAR · Saudi Riyal',
			'PLN' => 'PLN · Polish Złoty',
			'CZK' => 'CZK · Czech Koruna',
			'HUF' => 'HUF · Hungarian Forint',
			'TRY' => 'TRY · Turkish Lira',
			'KRW' => 'KRW · South Korean Won',
			'CNY' => 'CNY · Chinese Yuan',
		];
		return (array) apply_filters( 'asteris_aff_currencies', $base );
	}

	public static function is_valid( string $code ): bool {
		return array_key_exists( strtoupper( $code ), self::all() );
	}

	/** Symbol for display. Returns the ISO code as fallback if unknown. */
	public static function symbol( string $code ): string {
		static $map = [
			'USD' => '$', 'AUD' => 'A$', 'CAD' => 'C$', 'NZD' => 'NZ$', 'HKD' => 'HK$',
			'SGD' => 'S$', 'MXN' => 'MX$', 'BRL' => 'R$', 'EUR' => '€', 'GBP' => '£',
			'JPY' => '¥', 'CNY' => '¥', 'CHF' => 'CHF', 'INR' => '₹', 'KRW' => '₩',
			'TRY' => '₺', 'ZAR' => 'R', 'PLN' => 'zł', 'CZK' => 'Kč', 'HUF' => 'Ft',
			'SEK' => 'kr', 'NOK' => 'kr', 'DKK' => 'kr', 'AED' => 'د.إ', 'SAR' => 'ر.س',
		];
		$code = strtoupper( $code );
		return $map[ $code ] ?? $code;
	}
}
