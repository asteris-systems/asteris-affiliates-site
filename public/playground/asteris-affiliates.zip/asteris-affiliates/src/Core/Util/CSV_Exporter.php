<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * Streaming CSV exporter. Streams rows directly to php://output so memory
 * stays flat regardless of row count — safe for 100k+ row tables.
 *
 * Usage:
 *   CSV_Exporter::stream( 'affiliates-2026-06-08.csv',
 *     [ 'ID', 'Name', 'Email', 'Earnings' ],
 *     fn() => yield from $rows
 *   );
 */
final class CSV_Exporter {

	/**
	 * @param string                $filename       The Content-Disposition filename
	 * @param array<int,string>     $columns        Header row
	 * @param iterable<array<mixed>> $rows_generator Generator OR array of rows (each row = array of values)
	 */
	public static function stream( string $filename, array $columns, iterable $rows_generator ): void {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . self::sanitise_filename( $filename ) . '"' );
		// Excel-friendly UTF-8 BOM so accented chars render correctly
		echo "\xEF\xBB\xBF";

		$fh = fopen( 'php://output', 'w' );
		fputcsv( $fh, $columns );
		foreach ( $rows_generator as $row ) {
			fputcsv( $fh, array_map( [ self::class, 'scalarise' ], $row ) );
		}
		fclose( $fh );
		exit;
	}

	private static function scalarise( mixed $v ): string {
		if ( $v === null ) { return ''; }
		if ( is_bool( $v ) ) { return $v ? '1' : '0'; }
		if ( is_array( $v ) || is_object( $v ) ) { return wp_json_encode( $v ); }
		return (string) $v;
	}

	private static function sanitise_filename( string $f ): string {
		$f = preg_replace( '/[^a-zA-Z0-9._-]/', '-', $f );
		return $f !== '' ? $f : 'export.csv';
	}
}
