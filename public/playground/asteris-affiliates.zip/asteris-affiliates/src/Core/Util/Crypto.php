<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Core\Util;

defined( 'ABSPATH' ) || exit;

/**
 * AES-256-CBC symmetric encryption for at-rest sensitive data
 * (currently: affiliate bank details).
 *
 * Key: derived from `AUTH_SALT` + per-install option salt — survives any
 * change to wp-config.php credentials (the per-install salt persists).
 *
 * Output: base64( IV || ciphertext || sha256_hmac ) — single string,
 * safe to store in a TEXT column. ~33% bigger than the plaintext.
 *
 * NEVER log decrypted output. NEVER include in debug snapshots. NEVER
 * surface in REST API responses.
 *
 * Ported from the Asteris ecosystem's shared Util/Crypto pattern with the
 * Affiliates-specific salt option.
 */
final class Crypto {

	private const METHOD       = 'aes-256-cbc';
	private const HASH_ALGO    = 'sha256';
	private const OPT_SALT_KEY = 'asteris_aff_crypto_salt';

	public static function encrypt( string $plaintext ): string {
		if ( $plaintext === '' ) { return ''; }
		$key      = self::derive_key();
		$iv_len   = openssl_cipher_iv_length( self::METHOD );
		$iv       = random_bytes( $iv_len );
		$cipher   = openssl_encrypt( $plaintext, self::METHOD, $key, OPENSSL_RAW_DATA, $iv );
		if ( $cipher === false ) {
			throw new \RuntimeException( 'Crypto encrypt failed.' );
		}
		$blob = $iv . $cipher;
		$mac  = hash_hmac( self::HASH_ALGO, $blob, $key, true );
		return base64_encode( $blob . $mac );
	}

	/**
	 * Returns the plaintext, or null if MAC validation fails (tampered ciphertext).
	 * Callers MUST handle the null case (don't blindly trust the return).
	 */
	public static function decrypt( string $encoded ): ?string {
		if ( $encoded === '' ) { return null; }
		$blob = base64_decode( $encoded, true );
		if ( $blob === false ) { return null; }

		$mac_len = strlen( hash( self::HASH_ALGO, '', true ) );
		$iv_len  = openssl_cipher_iv_length( self::METHOD );
		if ( strlen( $blob ) < ( $iv_len + $mac_len + 1 ) ) { return null; }

		$mac        = substr( $blob, -$mac_len );
		$payload    = substr( $blob, 0, -$mac_len );
		$key        = self::derive_key();
		$expect_mac = hash_hmac( self::HASH_ALGO, $payload, $key, true );
		if ( ! hash_equals( $expect_mac, $mac ) ) {
			return null;  // tampered — refuse to decrypt
		}

		$iv     = substr( $payload, 0, $iv_len );
		$cipher = substr( $payload, $iv_len );
		$plain  = openssl_decrypt( $cipher, self::METHOD, $key, OPENSSL_RAW_DATA, $iv );
		return $plain === false ? null : $plain;
	}

	/**
	 * Derived key = SHA-256( AUTH_SALT || per-install random salt ).
	 * Per-install salt persists in options so the key survives even if
	 * AUTH_SALT is rotated (rare but possible).
	 */
	private static function derive_key(): string {
		$base   = defined( 'AUTH_SALT' ) && AUTH_SALT !== '' ? (string) AUTH_SALT : 'asteris-aff-default';
		$extra  = (string) get_option( self::OPT_SALT_KEY, '' );
		if ( $extra === '' ) {
			$extra = bin2hex( random_bytes( 32 ) );
			update_option( self::OPT_SALT_KEY, $extra, false );
		}
		return hash( self::HASH_ALGO, $base . '|' . $extra, true );
	}
}
