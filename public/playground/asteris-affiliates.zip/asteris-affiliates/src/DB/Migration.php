<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\DB;

defined( 'ABSPATH' ) || exit;

/**
 * DB schema for Asteris Affiliates.
 *
 * Two entry points:
 *   - install()         — called from register_activation_hook; fresh setup
 *   - maybe_upgrade()   — called on every load; idempotent self-healing
 *
 * Schema version stored in option `asteris_aff_db_version` so future
 * ALTER TABLEs can be detected + run once.
 *
 * Tables (all prefixed wp_aff_ — short namespace, clear separation):
 *   1. wp_aff_affiliates    — affiliate records (port of asteris_partners)
 *   2. wp_aff_referrals     — click + session tracking
 *   3. wp_aff_commissions   — one row per WC line item attributed
 *   4. wp_aff_payouts       — payout batches
 *   5. wp_aff_coupons       — vanity codes → affiliate mapping
 *   6. wp_aff_events        — activity log
 */
final class Migration {

	private const DB_VERSION = '1.1.0';
	private const OPT_KEY    = 'asteris_aff_db_version';

	public static function install(): void {
		self::run_schema();
		update_option( self::OPT_KEY, self::DB_VERSION, false );
	}

	public static function maybe_upgrade(): void {
		$installed = (string) get_option( self::OPT_KEY, '0' );
		if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) {
			return;
		}
		self::run_schema();
		update_option( self::OPT_KEY, self::DB_VERSION, false );
	}

	private static function run_schema(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$prefix  = $wpdb->prefix;
		$charset = $wpdb->get_charset_collate();

		// ── 1. Affiliates ─────────────────────────────────────────────────
		$sql_affiliates = "CREATE TABLE {$prefix}aff_affiliates (
			id                          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			public_id                   VARCHAR(48)     NOT NULL,
			status                      VARCHAR(16)     NOT NULL DEFAULT 'pending',
			first_name                  VARCHAR(80)     NULL,
			last_name                   VARCHAR(80)     NULL,
			display_name                VARCHAR(120)    NOT NULL,
			email                       VARCHAR(254)    NOT NULL,
			user_id                     BIGINT UNSIGNED NULL,
			country_code                CHAR(2)         NOT NULL DEFAULT 'US',
			payout_method               VARCHAR(16)     NOT NULL DEFAULT 'stripe_connect',
			stripe_connect_account_id   VARCHAR(64)     NULL,
			stripe_connect_status       VARCHAR(24)     NULL,
			bank_details_encrypted      TEXT            NULL,
			paypal_email                VARCHAR(254)    NULL,
			audience_size               VARCHAR(32)     NULL,
			promotion_plan              TEXT            NULL,
			commission_rate_y1_bp       SMALLINT        NOT NULL DEFAULT 2000,
			commission_rate_y2plus_bp   SMALLINT        NOT NULL DEFAULT 1000,
			custom_rate_override_bp     SMALLINT        NULL,
			parent_affiliate_id         BIGINT UNSIGNED NULL,
			tier2_rate_bp               SMALLINT        NOT NULL DEFAULT 500,
			lifetime_earnings_cents     BIGINT          NOT NULL DEFAULT 0,
			lifetime_referrals          INT             NOT NULL DEFAULT 0,
			pending_balance_cents       BIGINT          NOT NULL DEFAULT 0,
			approved_balance_cents      BIGINT          NOT NULL DEFAULT 0,
			paid_balance_cents          BIGINT          NOT NULL DEFAULT 0,
			aggregates_updated_at       DATETIME        NULL,
			onboarding_completed_at     DATETIME        NULL,
			notes_internal              TEXT            NULL,
			notes_partner_facing        TEXT            NULL,
			applied_at                  DATETIME        NOT NULL,
			approved_at                 DATETIME        NULL,
			suspended_at                DATETIME        NULL,
			terminated_at               DATETIME        NULL,
			last_login_at               DATETIME        NULL,
			updated_at                  DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY public_id (public_id),
			UNIQUE KEY email (email),
			KEY status (status),
			KEY user_id (user_id),
			KEY parent_affiliate_id (parent_affiliate_id)
		) {$charset};";

		// ── 2. Referrals (click + session tracking) ───────────────────────
		$sql_referrals = "CREATE TABLE {$prefix}aff_referrals (
			id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			affiliate_id        BIGINT UNSIGNED NOT NULL,
			session_id          VARCHAR(48)     NOT NULL,
			visitor_hash        VARCHAR(64)     NOT NULL,
			landed_url          TEXT            NOT NULL,
			landed_at           DATETIME        NOT NULL,
			utm_source          VARCHAR(64)     NULL,
			utm_medium          VARCHAR(64)     NULL,
			utm_campaign        VARCHAR(64)     NULL,
			utm_content         VARCHAR(64)     NULL,
			referrer_domain     VARCHAR(254)    NULL,
			ip_country          CHAR(2)         NULL,
			device_type         VARCHAR(16)     NULL,
			converted_at        DATETIME        NULL,
			converted_order_id  BIGINT UNSIGNED NULL,
			PRIMARY KEY  (id),
			KEY affiliate_id (affiliate_id),
			KEY session_id (session_id),
			KEY visitor_hash (visitor_hash),
			KEY landed_at (landed_at),
			KEY converted_order_id (converted_order_id)
		) {$charset};";

		// ── 3. Commissions ────────────────────────────────────────────────
		$sql_commissions = "CREATE TABLE {$prefix}aff_commissions (
			id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			affiliate_id        BIGINT UNSIGNED NOT NULL,
			order_id            BIGINT UNSIGNED NOT NULL,
			order_item_id       BIGINT UNSIGNED NULL,
			product_id          BIGINT UNSIGNED NULL,
			referral_id         BIGINT UNSIGNED NULL,
			attribution_type    VARCHAR(16)     NOT NULL,
			coupon_code         VARCHAR(64)     NULL,
			customer_email      VARCHAR(254)    NULL,
			amount_cents        INT             NOT NULL,
			currency            CHAR(3)         NOT NULL DEFAULT 'USD',
			rate_bp             SMALLINT        NOT NULL,
			rate_year           TINYINT         NOT NULL DEFAULT 1,
			tier_level          TINYINT         NOT NULL DEFAULT 1,
			parent_commission_id BIGINT UNSIGNED NULL,
			source              VARCHAR(16)     NOT NULL DEFAULT 'wc',
			status              VARCHAR(16)     NOT NULL DEFAULT 'pending',
			refund_window_ends  DATETIME        NOT NULL,
			approved_at         DATETIME        NULL,
			paid_at             DATETIME        NULL,
			payout_id           BIGINT UNSIGNED NULL,
			refunded_at         DATETIME        NULL,
			refund_reason       VARCHAR(64)     NULL,
			created_at          DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			KEY affiliate_id (affiliate_id),
			KEY order_id (order_id),
			KEY status (status),
			KEY refund_window_ends (refund_window_ends),
			KEY payout_id (payout_id),
			KEY customer_email (customer_email),
			KEY tier_level (tier_level),
			KEY parent_commission_id (parent_commission_id),
			KEY source (source)
		) {$charset};";

		// ── 4. Payouts ────────────────────────────────────────────────────
		$sql_payouts = "CREATE TABLE {$prefix}aff_payouts (
			id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			affiliate_id        BIGINT UNSIGNED NOT NULL,
			batch_id            VARCHAR(48)     NOT NULL,
			payout_method       VARCHAR(16)     NOT NULL,
			total_cents         INT             NOT NULL,
			currency            CHAR(3)         NOT NULL DEFAULT 'USD',
			commission_count    SMALLINT        NOT NULL,
			status              VARCHAR(16)     NOT NULL,
			stripe_transfer_id  VARCHAR(64)     NULL,
			bank_reference      VARCHAR(120)    NULL,
			failure_reason      TEXT            NULL,
			requested_at        DATETIME        NOT NULL,
			paid_at             DATETIME        NULL,
			PRIMARY KEY  (id),
			KEY affiliate_id (affiliate_id),
			KEY batch_id (batch_id),
			KEY status (status)
		) {$charset};";

		// ── 5. Coupons (vanity-code attribution) ──────────────────────────
		$sql_coupons = "CREATE TABLE {$prefix}aff_coupons (
			id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			affiliate_id        BIGINT UNSIGNED NOT NULL,
			wc_coupon_id        BIGINT UNSIGNED NOT NULL,
			coupon_code         VARCHAR(64)     NOT NULL,
			assigned_at         DATETIME        NOT NULL,
			active              TINYINT(1)      NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY coupon_code (coupon_code),
			KEY affiliate_id (affiliate_id),
			KEY wc_coupon_id (wc_coupon_id)
		) {$charset};";

		// ── 6. Events (activity log) ──────────────────────────────────────
		$sql_events = "CREATE TABLE {$prefix}aff_events (
			id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			occurred_at   DATETIME        NOT NULL,
			event_type    VARCHAR(64)     NOT NULL,
			affiliate_id  BIGINT UNSIGNED NULL,
			actor         VARCHAR(120)    NOT NULL,
			payload       LONGTEXT        NULL,
			PRIMARY KEY  (id),
			KEY occurred_at (occurred_at),
			KEY event_type (event_type),
			KEY affiliate_id (affiliate_id)
		) {$charset};";

		// ── 7. Email throttle ledger (v1.1 — 9B) ──────────────────────────
		// One row per (recipient, template, day) — Email\Throttle checks the
		// row's count_today before sending and increments on success.
		$sql_throttle = "CREATE TABLE {$prefix}aff_throttle (
			id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			recipient     VARCHAR(254)    NOT NULL,
			template_slug VARCHAR(64)     NOT NULL,
			day_utc       DATE            NOT NULL,
			count_today   SMALLINT        NOT NULL DEFAULT 0,
			last_sent_at  DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY recipient_template_day (recipient, template_slug, day_utc),
			KEY day_utc (day_utc)
		) {$charset};";

		// ── 8. Per-product commission rates (v1.1 — 9B) ───────────────────
		// Overrides the global Y1/Y2 rate for specific WC products.
		$sql_product_rates = "CREATE TABLE {$prefix}aff_product_rates (
			id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id      BIGINT UNSIGNED NOT NULL,
			rate_y1_bp      SMALLINT        NULL,
			rate_y2plus_bp  SMALLINT        NULL,
			eligible        TINYINT(1)      NOT NULL DEFAULT 1,
			updated_at      DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY product_id (product_id)
		) {$charset};";

		// ── 9. Swipe copy library (v1.1 — 10+) ────────────────────────────
		// Pre-written + AI-generated marketing copy snippets affiliates can
		// copy from the portal Links tab.
		$sql_swipe_copy = "CREATE TABLE {$prefix}aff_swipe_copy (
			id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			channel     VARCHAR(32)     NOT NULL,
			title       VARCHAR(120)    NOT NULL,
			body        TEXT            NOT NULL,
			ai_variant  TINYINT(1)      NOT NULL DEFAULT 0,
			sort_order  SMALLINT        NOT NULL DEFAULT 100,
			active      TINYINT(1)      NOT NULL DEFAULT 1,
			created_at  DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			KEY channel (channel),
			KEY active (active)
		) {$charset};";

		// ── 10. Vanity landing pages (v1.1 — 10+) ─────────────────────────
		// /go/{handle} mini-landing pages — per-affiliate hero + CTA.
		$sql_landing_pages = "CREATE TABLE {$prefix}aff_landing_pages (
			id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			affiliate_id    BIGINT UNSIGNED NOT NULL,
			handle          VARCHAR(48)     NOT NULL,
			headline        VARCHAR(140)    NULL,
			subhead         TEXT            NULL,
			cta_label       VARCHAR(48)     NULL,
			cta_target_url  TEXT            NULL,
			hero_image_url  TEXT            NULL,
			views           INT             NOT NULL DEFAULT 0,
			active          TINYINT(1)      NOT NULL DEFAULT 1,
			created_at      DATETIME        NOT NULL,
			updated_at      DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY handle (handle),
			KEY affiliate_id (affiliate_id)
		) {$charset};";

		// ── 11. A/B email tests (v1.1 — 10+) ──────────────────────────────
		// Variant routing + open/click tracking + sig calculation.
		$sql_ab_emails = "CREATE TABLE {$prefix}aff_ab_emails (
			id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			template_slug   VARCHAR(64)     NOT NULL,
			variant_label   VARCHAR(8)      NOT NULL,
			subject         TEXT            NOT NULL,
			body            LONGTEXT        NOT NULL,
			weight          SMALLINT        NOT NULL DEFAULT 50,
			sent_count      INT             NOT NULL DEFAULT 0,
			open_count      INT             NOT NULL DEFAULT 0,
			click_count     INT             NOT NULL DEFAULT 0,
			active          TINYINT(1)      NOT NULL DEFAULT 1,
			created_at      DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			KEY template_slug (template_slug),
			KEY active (active)
		) {$charset};";

		// ── 12. Cloud-assist fraud signals (v1.1 — 10+) ───────────────────
		// Opt-in: signals exchanged with central server (pay.asteriscommerce.com)
		// to detect cross-site fraud.
		$sql_fraud_signals = "CREATE TABLE {$prefix}aff_fraud_signals (
			id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			signal_hash     CHAR(64)        NOT NULL,
			signal_type     VARCHAR(32)     NOT NULL,
			severity        TINYINT         NOT NULL DEFAULT 1,
			occurrence_count INT            NOT NULL DEFAULT 1,
			first_seen_at   DATETIME        NOT NULL,
			last_seen_at    DATETIME        NOT NULL,
			synced_at       DATETIME        NULL,
			payload         TEXT            NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY signal_hash (signal_hash),
			KEY signal_type (signal_type),
			KEY synced_at (synced_at)
		) {$charset};";

		dbDelta( $sql_affiliates );
		dbDelta( $sql_referrals );
		dbDelta( $sql_commissions );
		dbDelta( $sql_payouts );
		dbDelta( $sql_coupons );
		dbDelta( $sql_events );
		dbDelta( $sql_throttle );
		dbDelta( $sql_product_rates );
		dbDelta( $sql_swipe_copy );
		dbDelta( $sql_landing_pages );
		dbDelta( $sql_ab_emails );
		dbDelta( $sql_fraud_signals );
	}

	/** Called from uninstall.php when the site owner has opted into data deletion. */
	public static function drop_all_tables(): void {
		global $wpdb;
		$prefix = $wpdb->prefix;
		$tables = [
			'affiliates', 'referrals', 'commissions', 'payouts', 'coupons', 'events',
			'throttle', 'product_rates', 'swipe_copy', 'landing_pages', 'ab_emails', 'fraud_signals',
		];
		foreach ( $tables as $t ) {
			$wpdb->query( "DROP TABLE IF EXISTS {$prefix}aff_{$t}" );
		}
		delete_option( self::OPT_KEY );
		delete_option( 'asteris_aff_settings' );
		delete_option( 'asteris_aff_install_version' );
		delete_option( 'asteris_aff_activated_at' );
	}
}
