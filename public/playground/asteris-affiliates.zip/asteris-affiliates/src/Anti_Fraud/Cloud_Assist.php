<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Anti_Fraud;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Optional cloud-assist fraud detection.
 *
 * Customer opts in via Settings → Cloud-assist fraud detection.
 * When enabled, we exchange ANONYMISED fraud signals with the central
 * Asteris server (pay.asteriscommerce.com). Specifically:
 *
 *   - SHA256(IP + UA + email_domain) hashes flagged as suspicious
 *   - signal_type: bot_burst | refund_burst | velocity | manual_admin
 *
 * No PII leaves the site. The hash is irreversible — used only for "have
 * we seen this exact signature elsewhere?" lookups.
 *
 * Sync runs daily via cron. Returns matches that other Asteris customers
 * have flagged, which the admin sees as warnings on the Activity page.
 *
 * Privacy:
 *   - Opt-in only — default OFF
 *   - Hashes ONLY — no raw IP / email / UA crosses the wire
 *   - Hashes use the site's ASTERIS_LS_SIGNING_SECRET as the salt so
 *     hashes are unique per site (preventing cross-site correlation
 *     beyond the explicit feature)
 */
final class Cloud_Assist {

	public const SYNC_ENDPOINT = '/wp-json/asteris/v1/fraud/sync';

	public static function register(): void {
		add_action( 'asteris_aff_cloud_fraud_sync', [ self::class, 'run_sync' ] );
		// Pro-only — no sync on free tier even if opt-in flipped on
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'cloud_fraud' ) ) { return; }
		// Ensure the cron is scheduled when enabled
		if ( (int) Settings::get( 'cloud_fraud_enabled', 0 ) && ! wp_next_scheduled( 'asteris_aff_cloud_fraud_sync' ) ) {
			wp_schedule_event( time() + 600, 'daily', 'asteris_aff_cloud_fraud_sync' );
		}
	}

	/** Hash an identity tuple. Salted with site secret. */
	public static function hash( string $ip, string $user_agent, string $email_domain ): string {
		$salt = defined( 'ASTERIS_LS_SIGNING_SECRET' ) ? (string) ASTERIS_LS_SIGNING_SECRET : 'fallback';
		return hash( 'sha256', $salt . '|' . $ip . '|' . $user_agent . '|' . strtolower( $email_domain ) );
	}

	public static function record_signal( string $signal_hash, string $signal_type, int $severity = 1, array $payload = [] ): void {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->query( $wpdb->prepare(
			"INSERT INTO {$wpdb->prefix}aff_fraud_signals
			   (signal_hash, signal_type, severity, occurrence_count, first_seen_at, last_seen_at, payload)
			 VALUES (%s, %s, %d, 1, %s, %s, %s)
			 ON DUPLICATE KEY UPDATE
			   occurrence_count = occurrence_count + 1,
			   last_seen_at     = VALUES(last_seen_at),
			   severity         = GREATEST(severity, VALUES(severity))",
			$signal_hash, $signal_type, $severity, $now, $now, wp_json_encode( $payload )
		) );
	}

	public static function run_sync(): void {
		if ( ! (int) Settings::get( 'cloud_fraud_enabled', 0 ) ) { return; }
		if ( ! defined( 'ASTERIS_LICENCE_SERVER_URL' ) ) { return; }

		global $wpdb;
		$batch = $wpdb->get_results(
			"SELECT signal_hash, signal_type, severity, occurrence_count, last_seen_at
			 FROM {$wpdb->prefix}aff_fraud_signals
			 WHERE synced_at IS NULL OR last_seen_at > synced_at
			 ORDER BY id ASC LIMIT 500"
		);
		if ( ! $batch ) { return; }

		$response = wp_remote_post(
			rtrim( (string) ASTERIS_LICENCE_SERVER_URL, '/' ) . self::SYNC_ENDPOINT,
			[
				'timeout' => 15,
				'headers' => [
					'Content-Type' => 'application/json',
					'X-Asteris-Site' => wp_parse_url( home_url(), PHP_URL_HOST ),
				],
				'body' => wp_json_encode( [
					'site_url' => home_url(),
					'signals'  => array_map( static function ( $s ): array {
						return [
							'h' => $s->signal_hash,
							't' => $s->signal_type,
							's' => (int) $s->severity,
							'n' => (int) $s->occurrence_count,
						];
					}, $batch ),
				] ),
			]
		);
		if ( is_wp_error( $response ) ) {
			self::log( 'cloud_fraud.sync_failed', $response->get_error_message() );
			return;
		}

		// Mark synced regardless of remote acknowledgement detail — central server is
		// best-effort. Failures just retry next day.
		$now = current_time( 'mysql', true );
		$ids = array_map( static fn( $s ): string => "'" . esc_sql( $s->signal_hash ) . "'", $batch );
		$wpdb->query( "UPDATE {$wpdb->prefix}aff_fraud_signals SET synced_at = '" . esc_sql( $now ) . "' WHERE signal_hash IN (" . implode( ',', $ids ) . ')' );

		// Parse remote matches (other sites have seen these too)
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( is_array( $body ) && ! empty( $body['matches'] ) ) {
			self::log( 'cloud_fraud.matches_received', wp_json_encode( $body['matches'] ) );
		}
		self::log( 'cloud_fraud.sync_ok', 'batch=' . count( $batch ) );
	}

	private static function log( string $event, string $detail ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event,
			'affiliate_id' => null,
			'actor'        => 'cron',
			'payload'      => wp_json_encode( [ 'detail' => $detail ] ),
		] );
	}
}
