<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Anti_Fraud;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Auto-suspends approved affiliates whose 30-day refund rate exceeds the
 * configured threshold (default 20%).
 *
 * Logic per approved affiliate:
 *   - Count commissions in last 30 days
 *   - Count those with status = refunded
 *   - rate = refunded / total
 *   - if rate >= threshold AND total >= MIN_SAMPLE → suspend + log event
 *
 * Skips affiliates with <MIN_SAMPLE commissions (statistical noise — one
 * refund out of one commission ≠ 100% refund rate as a meaningful signal).
 */
final class Refund_Rate_Scanner {

	/** Need at least this many commissions in the window before judging. */
	private const MIN_SAMPLE = 5;

	/** @return int affiliates suspended this run */
	public static function run(): int {
		// Pro-only — free tier shows the refund-rate heatmap on Reports but doesn't auto-suspend
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'auto_suspend' ) ) { return 0; }
		$threshold_pct = (int) Settings::get( 'auto_suspend_refund_rate_pct', 20 );
		if ( $threshold_pct <= 0 || $threshold_pct > 100 ) {
			return 0;  // misconfigured — skip
		}

		global $wpdb;
		$p = $wpdb->prefix;

		// Group commissions by affiliate, last 30 days
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT
			   c.affiliate_id,
			   COUNT(*)                                          AS total,
			   SUM(CASE WHEN c.status = 'refunded' THEN 1 ELSE 0 END) AS refunded
			 FROM {$p}aff_commissions c
			 INNER JOIN {$p}aff_affiliates a ON a.id = c.affiliate_id AND a.status = 'approved'
			 WHERE c.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
			 GROUP BY c.affiliate_id
			 HAVING total >= %d",
			self::MIN_SAMPLE
		) );

		$suspended = 0;
		$now       = current_time( 'mysql', true );

		foreach ( $rows as $r ) {
			$total    = (int) $r->total;
			$refunded = (int) $r->refunded;
			$rate_pct = (int) round( ( $refunded / $total ) * 100 );
			if ( $rate_pct < $threshold_pct ) { continue; }

			Affiliate_Repository::update( (int) $r->affiliate_id, [
				'status'       => 'suspended',
				'suspended_at' => $now,
			] );
			self::log( 'affiliate.auto_suspended.refund_rate', (int) $r->affiliate_id, [
				'rate_pct'      => $rate_pct,
				'threshold_pct' => $threshold_pct,
				'total_30d'     => $total,
				'refunded_30d'  => $refunded,
			] );
			$suspended++;
		}

		return $suspended;
	}

	private static function log( string $event, ?int $aff_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event,
			'affiliate_id' => $aff_id,
			'actor'        => 'cron',
			'payload'      => wp_json_encode( $payload ),
		] );
	}
}
