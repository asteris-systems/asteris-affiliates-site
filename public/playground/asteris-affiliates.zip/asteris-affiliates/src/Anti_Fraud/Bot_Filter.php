<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Anti_Fraud;

use AsterisAffiliates\Core\Settings;
use AsterisAffiliates\Tracking\Visitor_Hash;

defined( 'ABSPATH' ) || exit;

/**
 * UA-based bot rejection for affiliate click tracking.
 *
 * Goal: don't record clicks from Googlebot, AhrefsBot, monitoring services,
 * link-preview crawlers, etc. They inflate affiliate stats with phantom
 * traffic + can cause auto-suspend false positives (refund rate looks high
 * when click counts are 100× real).
 *
 * Approach: substring match against a known-bot UA list. Cheap, well-maintained
 * by the community, and conservative — if the UA is missing we LET IT THROUGH
 * (better to count one bot click than miss a real one).
 *
 * Settings::block_bot_user_agents must be true (default true). If admin
 * disables it for any reason, this returns false unconditionally.
 */
final class Bot_Filter {

	/**
	 * Known bot UA substrings. Lowercased before match.
	 * Curated from: Google Crawler docs, AhrefsBot docs, common monitoring
	 * service docs (Pingdom, UptimeRobot, GTmetrix), link-preview crawlers
	 * (Slackbot, Discordbot, TelegramBot, WhatsApp, Twitterbot, facebookexternalhit).
	 */
	private const BOT_SUBSTRINGS = [
		'bot', 'crawler', 'spider', 'scraper',
		'googlebot', 'bingbot', 'yandexbot', 'duckduckbot', 'baiduspider',
		'ahrefsbot', 'semrushbot', 'mj12bot', 'dotbot', 'rogerbot', 'screaming frog',
		'pingdom', 'uptimerobot', 'gtmetrix', 'pagespeed', 'lighthouse',
		'slackbot', 'discordbot', 'telegrambot', 'whatsapp', 'twitterbot',
		'facebookexternalhit', 'linkedinbot', 'embedly', 'redditbot',
		'curl/', 'wget/', 'python-requests', 'go-http-client', 'okhttp',
		'headlesschrome', 'phantomjs', 'puppeteer', 'selenium', 'playwright',
	];

	public static function is_bot( ?string $user_agent = null ): bool {
		if ( ! (int) Settings::get( 'block_bot_user_agents', 1 ) ) {
			return false;
		}
		$ua = strtolower( (string) ( $user_agent ?? Visitor_Hash::user_agent() ) );
		if ( $ua === '' ) {
			// Empty UA is suspicious — most real browsers send something.
			return true;
		}
		foreach ( self::BOT_SUBSTRINGS as $needle ) {
			if ( strpos( $ua, $needle ) !== false ) {
				return true;
			}
		}
		return false;
	}
}
