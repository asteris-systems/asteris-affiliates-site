<?php
/**
 * @package AsterisShared\AI
 */

namespace AsterisShared\AI;

defined( 'ABSPATH' ) || exit;

/**
 * Single entrypoint for AI text generation across every Asteris plugin.
 *
 * Architecture: BYO (bring-your-own) API key. We do NOT proxy through a
 * central Asteris router — customers paste their own OpenAI and/or Anthropic
 * key into plugin settings, the Router fans the right model to the right
 * vendor, and the customer pays the API bill directly. Zero billing/quota
 * complexity on our side, zero rate-limit liability.
 *
 * Why this pattern:
 *  - No metering, no entitlements, no "you've used 80% of your quota" UI
 *  - No risk of one customer's runaway loop exhausting a shared pool
 *  - Customers already have OpenAI/Anthropic accounts for their other tools
 *  - GPL-2.0 means a central proxy would just be a single-tenant bypass anyway
 *
 * Model routing:
 *   claude-*       → Anthropic Messages API
 *   gpt-*, o*      → OpenAI Chat Completions API
 *
 * Usage:
 *   $res = \AsterisShared\AI\Router::generate(
 *     'claude-haiku-4-5',
 *     'Rewrite this in a punchier tone: …',
 *     [
 *       'anthropic_key' => $plaintext_key,  // caller decrypts before passing
 *       'max_tokens'    => 800,
 *       'temperature'   => 0.7,
 *       'system'        => 'You are a marketing copywriter.',
 *     ]
 *   );
 *   if ( $res['ok'] ) { echo $res['text']; } else { echo $res['error']; }
 *
 * @phpstan-type Result array{ok:bool,text:string,error:string,model:string,vendor:string}
 */
final class Router {

	public const VENDOR_OPENAI    = 'openai';
	public const VENDOR_ANTHROPIC = 'anthropic';

	/** Sensible defaults per vendor so callers can omit common knobs. */
	private const DEFAULT_MAX_TOKENS  = 1024;
	private const DEFAULT_TEMPERATURE = 0.7;
	private const DEFAULT_TIMEOUT     = 60;

	/** Default model when caller doesn't specify — cheap, fast, capable. */
	public const DEFAULT_MODEL = 'claude-haiku-4-5';

	/**
	 * Generate text via the appropriate vendor based on $model.
	 *
	 * @param string                                     $model  e.g. 'claude-haiku-4-5', 'gpt-4o-mini'.
	 * @param string                                     $prompt User prompt.
	 * @param array{
	 *   openai_key?:string,
	 *   anthropic_key?:string,
	 *   max_tokens?:int,
	 *   temperature?:float,
	 *   system?:string,
	 *   timeout?:int
	 * } $opts
	 *
	 * @return array{ok:bool,text:string,error:string,model:string,vendor:string}
	 */
	public static function generate( string $model, string $prompt, array $opts = [] ): array {
		$model  = trim( $model );
		$prompt = trim( $prompt );
		if ( $model === '' || $prompt === '' ) {
			return self::err( $model, '', 'Model and prompt are both required.' );
		}

		$vendor = self::vendor_for_model( $model );
		if ( $vendor === '' ) {
			return self::err(
				$model,
				'',
				sprintf( 'Unrecognised model "%s". Use a claude-* or gpt-*/o* model.', $model )
			);
		}

		if ( $vendor === self::VENDOR_ANTHROPIC ) {
			$key = (string) ( $opts['anthropic_key'] ?? '' );
			if ( $key === '' ) {
				return self::err( $model, $vendor, 'No Anthropic API key. Add one in Asteris → AI Settings.' );
			}
			return self::call_anthropic( $model, $prompt, $key, $opts );
		}

		$key = (string) ( $opts['openai_key'] ?? '' );
		if ( $key === '' ) {
			return self::err( $model, $vendor, 'No OpenAI API key. Add one in Asteris → AI Settings.' );
		}
		return self::call_openai( $model, $prompt, $key, $opts );
	}

	/**
	 * Quick auth-only ping used by the "Test key" button. Sends a 1-token prompt
	 * to verify the key works without burning much spend.
	 *
	 * @return array{ok:bool,error:string}
	 */
	public static function test_key( string $vendor, string $key ): array {
		$key = trim( $key );
		if ( $key === '' ) {
			return [ 'ok' => false, 'error' => 'Key is empty.' ];
		}
		$model = $vendor === self::VENDOR_ANTHROPIC ? 'claude-haiku-4-5' : 'gpt-4o-mini';
		$opt   = $vendor === self::VENDOR_ANTHROPIC ? [ 'anthropic_key' => $key ] : [ 'openai_key' => $key ];
		$res   = self::generate( $model, 'Reply with the single word: OK', array_merge( $opt, [
			'max_tokens'  => 8,
			'temperature' => 0,
			'timeout'     => 15,
		] ) );
		return [ 'ok' => $res['ok'], 'error' => $res['error'] ];
	}

	/**
	 * Map a model name to its vendor. Returns '' for unknown models so the
	 * caller can render a clear error instead of guessing.
	 */
	public static function vendor_for_model( string $model ): string {
		$m = strtolower( $model );
		if ( str_starts_with( $m, 'claude-' ) ) {
			return self::VENDOR_ANTHROPIC;
		}
		if ( str_starts_with( $m, 'gpt-' ) || str_starts_with( $m, 'o1' ) || str_starts_with( $m, 'o3' ) || str_starts_with( $m, 'o4' ) ) {
			return self::VENDOR_OPENAI;
		}
		return '';
	}

	// ── Vendor calls ────────────────────────────────────────────────────────

	private static function call_anthropic( string $model, string $prompt, string $key, array $opts ): array {
		$body = [
			'model'      => $model,
			'max_tokens' => (int) ( $opts['max_tokens'] ?? self::DEFAULT_MAX_TOKENS ),
			'messages'   => [
				[ 'role' => 'user', 'content' => $prompt ],
			],
		];
		if ( isset( $opts['temperature'] ) ) {
			$body['temperature'] = (float) $opts['temperature'];
		}
		if ( ! empty( $opts['system'] ) ) {
			$body['system'] = (string) $opts['system'];
		}

		$res = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
			'timeout' => (int) ( $opts['timeout'] ?? self::DEFAULT_TIMEOUT ),
			'headers' => [
				'Content-Type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => '2023-06-01',
			],
			'body' => wp_json_encode( $body ),
		] );

		if ( is_wp_error( $res ) ) {
			return self::err( $model, self::VENDOR_ANTHROPIC, 'Network error: ' . $res->get_error_message() );
		}
		$code    = (int) wp_remote_retrieve_response_code( $res );
		$decoded = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $decoded ) ) {
			$msg = is_array( $decoded ) && isset( $decoded['error']['message'] )
				? (string) $decoded['error']['message']
				: sprintf( 'Anthropic API returned HTTP %d.', $code );
			return self::err( $model, self::VENDOR_ANTHROPIC, $msg );
		}
		// Anthropic returns content as array of blocks; concatenate text blocks.
		$text = '';
		foreach ( (array) ( $decoded['content'] ?? [] ) as $block ) {
			if ( is_array( $block ) && ( $block['type'] ?? '' ) === 'text' ) {
				$text .= (string) ( $block['text'] ?? '' );
			}
		}
		$text = trim( $text );
		if ( $text === '' ) {
			return self::err( $model, self::VENDOR_ANTHROPIC, 'Anthropic returned an empty response.' );
		}
		return [
			'ok'     => true,
			'text'   => $text,
			'error'  => '',
			'model'  => $model,
			'vendor' => self::VENDOR_ANTHROPIC,
		];
	}

	private static function call_openai( string $model, string $prompt, string $key, array $opts ): array {
		$messages = [];
		if ( ! empty( $opts['system'] ) ) {
			$messages[] = [ 'role' => 'system', 'content' => (string) $opts['system'] ];
		}
		$messages[] = [ 'role' => 'user', 'content' => $prompt ];

		$body = [
			'model'      => $model,
			'messages'   => $messages,
			'max_tokens' => (int) ( $opts['max_tokens'] ?? self::DEFAULT_MAX_TOKENS ),
		];
		if ( isset( $opts['temperature'] ) ) {
			$body['temperature'] = (float) $opts['temperature'];
		}

		$res = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
			'timeout' => (int) ( $opts['timeout'] ?? self::DEFAULT_TIMEOUT ),
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $key,
			],
			'body' => wp_json_encode( $body ),
		] );

		if ( is_wp_error( $res ) ) {
			return self::err( $model, self::VENDOR_OPENAI, 'Network error: ' . $res->get_error_message() );
		}
		$code    = (int) wp_remote_retrieve_response_code( $res );
		$decoded = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $decoded ) ) {
			$msg = is_array( $decoded ) && isset( $decoded['error']['message'] )
				? (string) $decoded['error']['message']
				: sprintf( 'OpenAI API returned HTTP %d.', $code );
			return self::err( $model, self::VENDOR_OPENAI, $msg );
		}
		$text = trim( (string) ( $decoded['choices'][0]['message']['content'] ?? '' ) );
		if ( $text === '' ) {
			return self::err( $model, self::VENDOR_OPENAI, 'OpenAI returned an empty response.' );
		}
		return [
			'ok'     => true,
			'text'   => $text,
			'error'  => '',
			'model'  => $model,
			'vendor' => self::VENDOR_OPENAI,
		];
	}

	private static function err( string $model, string $vendor, string $msg ): array {
		return [
			'ok'     => false,
			'text'   => '',
			'error'  => $msg,
			'model'  => $model,
			'vendor' => $vendor,
		];
	}
}
