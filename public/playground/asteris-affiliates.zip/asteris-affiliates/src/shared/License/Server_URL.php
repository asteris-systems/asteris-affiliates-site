<?php
/**
 * @package AsterisShared\License
 */

namespace AsterisShared\License;

defined( 'ABSPATH' ) || exit;

/**
 * Resolve the Asteris Licence Server URL.
 *
 * Defaults to production (pay.asteriscommerce.com). Customer wp-config.php
 * can override for staging/dev environments:
 *
 *   define( 'ASTERIS_LICENCE_SERVER_URL', 'https://asteris-licence-server.local' );
 */
final class Server_URL {

	private const DEFAULT_URL = 'https://pay.asteriscommerce.com';

	public static function resolve(): string {
		if ( defined( 'ASTERIS_LICENCE_SERVER_URL' ) && ASTERIS_LICENCE_SERVER_URL !== '' ) {
			return rtrim( (string) ASTERIS_LICENCE_SERVER_URL, '/' );
		}
		return self::DEFAULT_URL;
	}
}
