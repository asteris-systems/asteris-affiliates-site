<?php
/**
 * @package AsterisShared
 */

namespace AsterisShared\License;

defined( 'ABSPATH' ) || exit;

if ( class_exists( __NAMESPACE__ . '\\Client', false ) ) {
	return;
}

/**
 * Licence Client — activate / validate / deactivate flow against the
 * Asteris Licence Server (pay.asteriscommerce.com).
 *
 * Used by ALL paid Asteris plugins (WC, WP, Cart, Affiliates). Vendored
 * verbatim into each plugin's src/shared/License/ directory per dual-plugin
 * architecture (Path B).
 *
 * Usage:
 *   $client = Client::for_product( 'asteris_affiliates', 'asteris_aff_license_key' );
 *   $client->activate( 'A1B2-C3D4-…' );      // user enters key → activate
 *   $client->validate();                      // periodic check (daily cron)
 *   $client->deactivate();                    // user removes key
 *   $client->status();                        // active|expired|invalid|unset
 *
 * Storage:
 *   - License key:  wp_options[$opt_key_name]
 *   - Last check:   wp_options[asteris_lic_{product}_state]
 *     { status, instance_name, last_checked_at, expires_at, plan }
 *
 * HMAC: every request signed with ASTERIS_LS_SIGNING_SECRET so server can
 * verify it's a legit Asteris-built plugin and not a stranger pinging the API.
 */
final class Client {

	private string $product;
	private string $opt_key_name;
	private string $api_base;
	private string $state_opt;

	/** @var array<string,self> */
	private static array $instances = [];

	private function __construct( string $product, string $opt_key_name ) {
		$this->product      = $product;
		$this->opt_key_name = $opt_key_name;
		$this->state_opt    = 'asteris_lic_' . $product . '_state';
		$this->api_base     = rtrim(
			defined( 'ASTERIS_LICENCE_SERVER_URL' )
				? (string) ASTERIS_LICENCE_SERVER_URL
				: 'https://pay.asteriscommerce.com',
			'/'
		);
	}

	public static function for_product( string $product, string $opt_key_name ): self {
		$key = $product . '|' . $opt_key_name;
		return self::$instances[ $key ] ??= new self( $product, $opt_key_name );
	}

	// ── Public API ──────────────────────────────────────────────────────────

	/**
	 * Save + activate a fresh licence key.
	 * @return array{ok:bool, message:string, status?:string, plan?:string, expires_at?:string}
	 */
	public function activate( string $key ): array {
		$key = self::normalise_key( $key );
		if ( ! self::looks_like_key( $key ) ) {
			return [ 'ok' => false, 'message' => 'Licence key format looks wrong.' ];
		}

		$resp = $this->post( '/wp-json/asteris/v1/license/activate', [
			'product'       => $this->product,
			'license_key'   => $key,
			'instance_name' => $this->instance_name(),
		] );
		if ( is_wp_error( $resp ) ) {
			return [ 'ok' => false, 'message' => $resp->get_error_message() ];
		}

		if ( empty( $resp['ok'] ) ) {
			return [ 'ok' => false, 'message' => $resp['error'] ?? 'Activation declined.' ];
		}

		update_option( $this->opt_key_name, $key, false );
		$this->store_state( [
			'status'          => 'active',
			'instance_name'   => $this->instance_name(),
			'last_checked_at' => current_time( 'mysql', true ),
			'expires_at'      => $resp['expires_at']     ?? null,
			'plan'            => $resp['plan']           ?? null,
		] );

		return [
			'ok'         => true,
			'message'    => 'Licence activated.',
			'status'     => 'active',
			'plan'       => $resp['plan']       ?? null,
			'expires_at' => $resp['expires_at'] ?? null,
		];
	}

	/**
	 * Periodic check — daily cron. Updates state. Returns current status.
	 * Cheap no-op when key isn't set.
	 */
	public function validate(): array {
		$key = (string) get_option( $this->opt_key_name, '' );
		if ( $key === '' ) {
			$this->store_state( [ 'status' => 'unset', 'last_checked_at' => current_time( 'mysql', true ) ] );
			return [ 'status' => 'unset' ];
		}
		$resp = $this->post( '/wp-json/asteris/v1/license/validate', [
			'product'       => $this->product,
			'license_key'   => $key,
			'instance_name' => $this->instance_name(),
		] );
		if ( is_wp_error( $resp ) ) {
			// Transient network failure — leave existing state alone, return stale
			$state = $this->get_state();
			return [ 'status' => $state['status'] ?? 'unknown', 'network_error' => $resp->get_error_message() ];
		}

		$status = $resp['status'] ?? 'invalid';
		$this->store_state( [
			'status'          => $status,
			'instance_name'   => $this->instance_name(),
			'last_checked_at' => current_time( 'mysql', true ),
			'expires_at'      => $resp['expires_at'] ?? null,
			'plan'            => $resp['plan']       ?? null,
		] );
		return [ 'status' => $status, 'expires_at' => $resp['expires_at'] ?? null ];
	}

	/** Remove the key locally + tell server. */
	public function deactivate(): array {
		$key = (string) get_option( $this->opt_key_name, '' );
		if ( $key !== '' ) {
			$this->post( '/wp-json/asteris/v1/license/deactivate', [
				'product'       => $this->product,
				'license_key'   => $key,
				'instance_name' => $this->instance_name(),
			] );
		}
		delete_option( $this->opt_key_name );
		delete_option( $this->state_opt );
		return [ 'ok' => true ];
	}

	public function status(): string {
		$state = $this->get_state();
		return (string) ( $state['status'] ?? 'unset' );
	}

	public function key(): string {
		return (string) get_option( $this->opt_key_name, '' );
	}

	/** @return array{status:string,instance_name?:string,last_checked_at?:string,expires_at?:string,plan?:string} */
	public function get_state(): array {
		$state = get_option( $this->state_opt, [] );
		return is_array( $state ) ? $state : [];
	}

	// ── Internals ───────────────────────────────────────────────────────────

	private function store_state( array $state ): void {
		update_option( $this->state_opt, $state, false );
	}

	private function instance_name(): string {
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		return strtolower( $host !== '' ? $host : 'unknown-host' );
	}

	/** HMAC-signed POST. Returns decoded body OR WP_Error. */
	private function post( string $path, array $payload ): array|\WP_Error {
		$payload['timestamp'] = time();
		$json     = wp_json_encode( $payload );
		$sig      = self::sign( $json );
		$response = wp_remote_post(
			$this->api_base . $path,
			[
				'timeout' => 15,
				'headers' => [
					'Content-Type'      => 'application/json',
					'X-Asteris-Sig'     => $sig,
					'X-Asteris-Product' => $this->product,
				],
				'body' => $json,
			]
		);
		if ( is_wp_error( $response ) ) { return $response; }
		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $body ) && isset( $body['error'] ) ? $body['error'] : 'HTTP ' . $code;
			return new \WP_Error( 'asteris_lic_http', (string) $msg );
		}
		return is_array( $body ) ? $body : [ 'ok' => true ];
	}

	private static function sign( string $json ): string {
		$secret = defined( 'ASTERIS_LS_SIGNING_SECRET' ) ? (string) ASTERIS_LS_SIGNING_SECRET : '';
		return hash_hmac( 'sha256', $json, $secret );
	}

	private static function normalise_key( string $k ): string {
		return strtoupper( trim( preg_replace( '/\s+/', '', $k ) ?? '' ) );
	}

	private static function looks_like_key( string $k ): bool {
		// 4-block hyphenated alnum, allow vendor prefix
		return (bool) preg_match( '/^[A-Z0-9-]{12,80}$/', $k );
	}
}
