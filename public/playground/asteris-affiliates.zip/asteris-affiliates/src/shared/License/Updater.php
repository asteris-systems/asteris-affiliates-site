<?php
/**
 * @package AsterisShared
 */

namespace AsterisShared\License;

defined( 'ABSPATH' ) || exit;

if ( class_exists( __NAMESPACE__ . '\\Updater', false ) ) {
	return;
}

/**
 * Self-hosted plugin updates.
 *
 * Each Asteris plugin (WC, WP, Cart) calls Updater::init() once during boot
 * with its product slug + plugin file + current version + licence-key option.
 * From there the updater hooks WP's standard update machinery and customers
 * see "Update available" banners in their Plugins screen — same UX as WP.org
 * plugins, served from pay.asteriscommerce.com instead.
 *
 * Flow:
 *   1. WP's twice-daily update check fires pre_set_site_transient_update_plugins
 *   2. We read the licence key from wp_options
 *   3. We GET /wp-json/asteris/v1/license/check-update on the licence server
 *   4. If a newer version exists, we inject our entry into the transient with
 *      a download URL that hits /wp-json/asteris/v1/license/download (auth'd
 *      by the licence key in the URL).
 *   5. WP shows the update banner. Customer clicks. WP downloads our ZIP from
 *      our authenticated endpoint. Unpacks. Replaces files. Activates.
 *
 * Response caching: we cache the server response for 6 hours in a transient
 * so we don't hammer pay.asteriscommerce.com on every admin page load.
 * "Check for updates" from the Updates screen clears the cache.
 *
 * Failure modes are silent — if the server's down or the licence key isn't set,
 * the update check is just a no-op. We don't surface errors in admin (the
 * customer's existing install keeps working; this is purely a "should you
 * upgrade?" optional check).
 */
final class Updater {

	private string $product;
	private string $plugin_file;        // absolute path to main plugin file
	private string $plugin_basename;    // dirname/file.php — WP's plugin identifier
	private string $current_version;
	private string $opt_key_name;
	private string $api_base;

	/** Cache TTL — 6h. Bumped to instant when WP's update force-check fires. */
	private const CACHE_TTL = 6 * HOUR_IN_SECONDS;

	public static function init( array $config ): void {
		$required = [ 'product', 'plugin_file', 'current_version', 'opt_key_name' ];
		foreach ( $required as $k ) {
			if ( empty( $config[ $k ] ) ) {
				return; // Misconfig — fail silent
			}
		}

		$instance = new self( $config );
		add_filter( 'pre_set_site_transient_update_plugins', [ $instance, 'inject_update' ] );
		add_filter( 'plugins_api', [ $instance, 'plugins_api_filter' ], 10, 3 );

		// When admin clicks "Check again" in Updates, blow the cache
		add_action( 'upgrader_process_complete', [ $instance, 'clear_cache' ], 10, 0 );
		add_action( 'load-update-core.php',      [ $instance, 'clear_cache' ] );
	}

	private function __construct( array $config ) {
		$this->product         = (string) $config['product'];
		$this->plugin_file     = (string) $config['plugin_file'];
		$this->plugin_basename = plugin_basename( $this->plugin_file );
		$this->current_version = (string) $config['current_version'];
		$this->opt_key_name    = (string) $config['opt_key_name'];
		// Server_URL::resolve() returns host root (e.g. https://pay.asteriscommerce.com)
		// — we append the REST namespace ourselves so all paths under this->api_base
		// can be concatenated with just /license/check-update etc.
		$this->api_base        = rtrim( Server_URL::resolve(), '/' ) . '/wp-json/asteris/v1';
	}

	/**
	 * Hook: pre_set_site_transient_update_plugins
	 */
	public function inject_update( $transient ) {
		// WP may pass a non-object on first run; defend
		if ( ! is_object( $transient ) ) {
			$transient = new \stdClass();
		}
		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = [];
		}
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = [];
		}

		$info = $this->get_update_info();
		if ( ! $info ) {
			return $transient;
		}

		$entry = $this->build_plugin_object( $info );

		if ( ! empty( $info['update_available'] ) && ! empty( $info['version'] ) ) {
			$transient->response[ $this->plugin_basename ] = $entry;
			unset( $transient->no_update[ $this->plugin_basename ] );
		} else {
			$transient->no_update[ $this->plugin_basename ] = $entry;
			unset( $transient->response[ $this->plugin_basename ] );
		}

		return $transient;
	}

	/**
	 * Hook: plugins_api — feeds the "View details" popup in the Plugins screen.
	 */
	public function plugins_api_filter( $result, $action, $args ) {
		if ( $action !== 'plugin_information' ) {
			return $result;
		}
		if ( ! is_object( $args ) || empty( $args->slug ) ) {
			return $result;
		}
		// Slug = dirname of the plugin file (e.g. asteris-for-woocommerce)
		$our_slug = dirname( $this->plugin_basename );
		if ( $args->slug !== $our_slug ) {
			return $result;
		}

		$info = $this->get_update_info();
		if ( ! $info ) {
			return $result;
		}

		$obj = new \stdClass();
		$obj->name          = ucwords( str_replace( '-', ' ', $our_slug ) );
		$obj->slug          = $our_slug;
		$obj->version       = (string) ( $info['version'] ?? $this->current_version );
		$obj->author        = '<a href="https://asteriscommerce.com">Asteris Commerce</a>';
		$obj->homepage      = 'https://asteriscommerce.com';
		$obj->requires      = (string) ( $info['requires_wp']  ?? '6.4' );
		$obj->tested        = (string) ( $info['tested']       ?? '6.8' );
		$obj->requires_php  = (string) ( $info['requires_php'] ?? '8.1' );
		$obj->download_link = (string) ( $info['download_url'] ?? '' );
		$obj->sections      = [
			'description' => '<p>The lightweight, all-in-one toolkit. Updates via your Asteris licence.</p>',
			'changelog'   => '<p>See <a href="' . esc_url( (string) ( $info['changelog_url'] ?? '' ) ) . '">full changelog</a>.</p>',
		];
		return $obj;
	}

	public function clear_cache(): void {
		delete_transient( $this->cache_key() );
	}

	private function cache_key(): string {
		return 'asteris_updater_' . md5( $this->product . '|' . $this->current_version );
	}

	/**
	 * Fetch update info from the licence server, with 6h caching.
	 * Returns associative array on success, null on failure / no licence.
	 */
	private function get_update_info(): ?array {
		$key = (string) get_option( $this->opt_key_name, '' );
		if ( $key === '' ) {
			return null;
		}

		$cached = get_transient( $this->cache_key() );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$url = add_query_arg( [
			'product'           => $this->product,
			'installed_version' => $this->current_version,
			'licence_key'       => $key,
			'site'              => parse_url( home_url(), PHP_URL_HOST ),
		], $this->api_base . '/license/check-update' );

		$res = wp_remote_get( $url, [
			'timeout' => 8,
			'headers' => [ 'Accept' => 'application/json' ],
		] );

		if ( is_wp_error( $res ) ) {
			return null;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code !== 200 ) {
			// 401/403/400 — cache a "no update" stub for 30 min so we don't spam
			set_transient( $this->cache_key(), [ 'update_available' => false ], 30 * MINUTE_IN_SECONDS );
			return [ 'update_available' => false ];
		}

		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $body ) ) {
			return null;
		}

		set_transient( $this->cache_key(), $body, self::CACHE_TTL );
		return $body;
	}

	/**
	 * Build the object WP expects in $transient->response / no_update.
	 */
	private function build_plugin_object( array $info ): \stdClass {
		$obj = new \stdClass();
		$obj->id            = $this->plugin_basename;
		$obj->slug          = dirname( $this->plugin_basename );
		$obj->plugin        = $this->plugin_basename;
		$obj->new_version   = (string) ( $info['version'] ?? $this->current_version );
		$obj->url           = 'https://asteriscommerce.com';
		$obj->package       = (string) ( $info['download_url'] ?? '' );
		$obj->tested        = (string) ( $info['tested']       ?? '6.8' );
		$obj->requires_php  = (string) ( $info['requires_php'] ?? '8.1' );
		$obj->requires      = (string) ( $info['requires_wp']  ?? '6.4' );
		$obj->icons         = [ '1x' => (string) ( $info['icon_url']   ?? '' ) ];
		$obj->banners       = [ 'low' => (string) ( $info['banner_url'] ?? '' ) ];
		return $obj;
	}
}
