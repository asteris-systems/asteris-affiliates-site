<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\CLI;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Commissions\Approval_Scanner;
use AsterisAffiliates\Core\Aggregates_Service;
use AsterisAffiliates\Email\Throttle;
use AsterisAffiliates\Payouts\Batch_Cron;

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return; // Only loaded under WP-CLI
}

/**
 * WP-CLI commands for Asteris Affiliates.
 *
 * Examples:
 *   wp asteris-affiliates list --status=approved
 *   wp asteris-affiliates approve 42
 *   wp asteris-affiliates recompute-aggregates
 *   wp asteris-affiliates run-approvals
 *   wp asteris-affiliates run-payouts
 *   wp asteris-affiliates throttle-cleanup
 *   wp asteris-affiliates stats 42
 */
final class Commands {

	public static function register(): void {
		\WP_CLI::add_command( 'asteris-affiliates list',                  [ self::class, 'list_affiliates' ] );
		\WP_CLI::add_command( 'asteris-affiliates approve',               [ self::class, 'approve_affiliate' ] );
		\WP_CLI::add_command( 'asteris-affiliates reject',                [ self::class, 'reject_affiliate' ] );
		\WP_CLI::add_command( 'asteris-affiliates recompute-aggregates',  [ self::class, 'recompute' ] );
		\WP_CLI::add_command( 'asteris-affiliates run-approvals',         [ self::class, 'run_approvals' ] );
		\WP_CLI::add_command( 'asteris-affiliates run-payouts',           [ self::class, 'run_payouts' ] );
		\WP_CLI::add_command( 'asteris-affiliates throttle-cleanup',      [ self::class, 'throttle_cleanup' ] );
		\WP_CLI::add_command( 'asteris-affiliates stats',                 [ self::class, 'stats' ] );
	}

	/**
	 * List affiliates.
	 *
	 * ## OPTIONS
	 * [--status=<status>]
	 * : Filter by status (pending|approved|suspended|rejected)
	 *
	 * [--limit=<n>]
	 * : Max rows (default 50, max 500)
	 *
	 * [--format=<format>]
	 * : Output format (table|csv|json|yaml). Default: table
	 */
	public static function list_affiliates( array $args, array $assoc ): void {
		$rows = Affiliate_Repository::list( [
			'status' => $assoc['status'] ?? null,
			'limit'  => isset( $assoc['limit'] ) ? (int) $assoc['limit'] : 50,
		] );
		$out = [];
		foreach ( $rows as $r ) {
			$out[] = [
				'id'           => $r->id,
				'public_id'    => $r->public_id,
				'display_name' => $r->display_name,
				'email'        => $r->email,
				'status'       => $r->status,
				'earnings_usd' => number_format( ( (int) ( $r->lifetime_earnings_cents ?? 0 ) ) / 100, 2 ),
			];
		}
		\WP_CLI\Utils\format_items(
			$assoc['format'] ?? 'table',
			$out,
			[ 'id', 'public_id', 'display_name', 'email', 'status', 'earnings_usd' ]
		);
	}

	/** Approve an affiliate by ID. */
	public static function approve_affiliate( array $args ): void {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) { \WP_CLI::error( 'Affiliate not found.' ); }
		Affiliate_Repository::update( $id, [ 'status' => 'approved', 'approved_at' => current_time( 'mysql', true ) ] );
		\WP_CLI::success( "Approved affiliate #{$id} ({$aff->email})." );
	}

	/** Reject an affiliate by ID. */
	public static function reject_affiliate( array $args ): void {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) { \WP_CLI::error( 'Affiliate not found.' ); }
		Affiliate_Repository::update( $id, [ 'status' => 'rejected' ] );
		\WP_CLI::success( "Rejected affiliate #{$id}." );
	}

	/** Recompute denormalised aggregates on all affiliate rows. */
	public static function recompute(): void {
		\WP_CLI::log( 'Recomputing aggregates on all affiliates…' );
		$n = Aggregates_Service::recompute_all();
		\WP_CLI::success( "Recomputed aggregates for {$n} affiliates." );
	}

	/** Run the approval scanner — flip eligible pending → approved now. */
	public static function run_approvals(): void {
		if ( ! class_exists( Approval_Scanner::class ) ) {
			\WP_CLI::error( 'Approval_Scanner class missing.' );
		}
		$count = Approval_Scanner::run();
		\WP_CLI::success( "Flipped {$count} commissions to approved." );
	}

	/** Run the payout batch cron now. */
	public static function run_payouts(): void {
		if ( ! class_exists( Batch_Cron::class ) ) {
			\WP_CLI::error( 'Batch_Cron class missing.' );
		}
		$count = Batch_Cron::run_batch();
		\WP_CLI::success( "Payout batch completed — created {$count} payouts." );
	}

	/** Drop old throttle rows. */
	public static function throttle_cleanup(): void {
		$n = Throttle::cleanup_old();
		\WP_CLI::success( "Cleaned {$n} throttle rows older than 90d." );
	}

	/** Show stats for one affiliate. */
	public static function stats( array $args ): void {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		$aff = Affiliate_Repository::find( $id );
		if ( ! $aff ) { \WP_CLI::error( 'Affiliate not found.' ); }
		global $wpdb;
		$p = $wpdb->prefix;
		$clicks_total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_referrals WHERE affiliate_id = %d", $id ) );
		$conversions  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}aff_commissions WHERE affiliate_id = %d", $id ) );
		\WP_CLI\Utils\format_items( 'table', [ [
			'affiliate_id'    => $id,
			'display_name'    => $aff->display_name,
			'lifetime_usd'    => number_format( ( (int) ( $aff->lifetime_earnings_cents ?? 0 ) ) / 100, 2 ),
			'pending_usd'     => number_format( ( (int) ( $aff->pending_balance_cents ?? 0 ) ) / 100, 2 ),
			'approved_usd'    => number_format( ( (int) ( $aff->approved_balance_cents ?? 0 ) ) / 100, 2 ),
			'paid_usd'        => number_format( ( (int) ( $aff->paid_balance_cents ?? 0 ) ) / 100, 2 ),
			'clicks_total'    => $clicks_total,
			'conversions'     => $conversions,
		] ], [ 'affiliate_id', 'display_name', 'lifetime_usd', 'pending_usd', 'approved_usd', 'paid_usd', 'clicks_total', 'conversions' ] );
	}
}
