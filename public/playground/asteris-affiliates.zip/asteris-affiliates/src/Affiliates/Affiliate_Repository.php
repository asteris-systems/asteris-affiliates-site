<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Affiliates;

defined( 'ABSPATH' ) || exit;

/**
 * CRUD + queries for the wp_aff_affiliates table.
 *
 * Centralises all reads/writes so admin pages, signup form, portal, and
 * future Sprint 4+ code don't sprinkle raw $wpdb calls everywhere.
 */
final class Affiliate_Repository {

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'aff_affiliates';
	}

	public static function find( int $id ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
		return $row ?: null;
	}

	public static function find_by_email( string $email ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE email = %s LIMIT 1', strtolower( $email ) ) );
		return $row ?: null;
	}

	public static function find_by_public_id( string $public_id ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE public_id = %s LIMIT 1', $public_id ) );
		return $row ?: null;
	}

	/**
	 * @param array{status?:string,search?:string,limit?:int,offset?:int,orderby?:string,order?:string} $args
	 * @return object[]
	 */
	public static function list( array $args = [] ): array {
		global $wpdb;
		$where = [ '1=1' ];
		$prepare_args = [];

		if ( ! empty( $args['status'] ) ) {
			$where[] = 'status = %s';
			$prepare_args[] = $args['status'];
		}
		if ( ! empty( $args['search'] ) ) {
			$where[] = '(display_name LIKE %s OR email LIKE %s)';
			$like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$prepare_args[] = $like;
			$prepare_args[] = $like;
		}
		// Safe ORDER BY — already whitelisted by Sort_Helper before reaching here.
		// Defensive belt + braces: only accept alnum/underscore.
		$orderby = isset( $args['orderby'] ) ? preg_replace( '/[^a-zA-Z0-9_]/', '', (string) $args['orderby'] ) : 'id';
		if ( $orderby === '' ) { $orderby = 'id'; }
		$order   = strtoupper( (string) ( $args['order'] ?? 'DESC' ) ) === 'ASC' ? 'ASC' : 'DESC';

		$limit  = max( 1, min( 500, (int) ( $args['limit']  ?? 50 ) ) );
		$offset = max( 0, (int) ( $args['offset'] ?? 0 ) );
		$sql = 'SELECT * FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where )
		       . " ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$prepare_args[] = $limit;
		$prepare_args[] = $offset;
		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $prepare_args ) );
	}

	/** @return array<string,int> status => count */
	public static function counts_by_status(): array {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS n FROM ' . self::table() . ' GROUP BY status' );
		$out = [ 'pending' => 0, 'approved' => 0, 'suspended' => 0, 'rejected' => 0, 'terminated' => 0 ];
		foreach ( $rows as $r ) {
			$out[ (string) $r->status ] = (int) $r->n;
		}
		return $out;
	}

	/**
	 * Insert a new affiliate. Returns the new ID or null on failure.
	 * Caller is responsible for setting the `status` (pending for public
	 * signup; approved for manual admin add).
	 *
	 * @param array<string,mixed> $fields
	 */
	public static function insert( array $fields ): ?int {
		global $wpdb;
		$now = current_time( 'mysql', true );

		// Auto-generate public_id if not provided.
		if ( empty( $fields['public_id'] ) ) {
			$fields['public_id'] = self::generate_public_id();
		}

		$row = array_merge( [
			'status'                    => 'pending',
			'country_code'              => 'US',
			'payout_method'             => 'stripe_connect',
			'commission_rate_y1_bp'     => 2000,
			'commission_rate_y2plus_bp' => 1000,
			'applied_at'                => $now,
			'updated_at'                => $now,
		], $fields );

		$row['email'] = strtolower( (string) ( $row['email'] ?? '' ) );

		$ok = $wpdb->insert( self::table(), $row );
		return $ok ? (int) $wpdb->insert_id : null;
	}

	public static function update( int $id, array $fields ): bool {
		global $wpdb;
		$fields['updated_at'] = current_time( 'mysql', true );
		$ok = $wpdb->update( self::table(), $fields, [ 'id' => $id ] );
		return $ok !== false;
	}

	/**
	 * Sanitise + validate a customer-supplied public_id.
	 *
	 *   - Lowercased
	 *   - Allowed chars: a-z 0-9 hyphen
	 *   - 3–48 chars
	 *   - Must NOT start or end with a hyphen
	 *
	 * @return string|null Normalised public_id, or null if invalid format
	 */
	public static function sanitise_public_id( string $input ): ?string {
		$slug = strtolower( trim( $input ) );
		$slug = preg_replace( '/[^a-z0-9-]/', '', $slug );
		if ( $slug === null || $slug === '' ) { return null; }
		if ( strlen( $slug ) < 3 || strlen( $slug ) > 48 ) { return null; }
		if ( str_starts_with( $slug, '-' ) || str_ends_with( $slug, '-' ) ) { return null; }
		return $slug;
	}

	/**
	 * Check uniqueness — true if NO other affiliate uses this public_id.
	 * Pass $exclude_id when editing an existing affiliate (so their own
	 * current value doesn't trigger a false "in use" error).
	 */
	public static function is_public_id_available( string $public_id, ?int $exclude_id = null ): bool {
		global $wpdb;
		if ( $exclude_id !== null ) {
			$found = $wpdb->get_var( $wpdb->prepare(
				'SELECT id FROM ' . self::table() . ' WHERE public_id = %s AND id != %d LIMIT 1',
				$public_id, $exclude_id
			) );
		} else {
			$found = $wpdb->get_var( $wpdb->prepare(
				'SELECT id FROM ' . self::table() . ' WHERE public_id = %s LIMIT 1',
				$public_id
			) );
		}
		return $found === null;
	}

	/**
	 * Cheap, URL-friendly public ID. Used in `?ref=…` links.
	 * Lower-case alphanumeric, 10 chars — collision risk negligible at
	 * the scale of affiliates per store.
	 */
	private static function generate_public_id(): string {
		for ( $attempt = 0; $attempt < 5; $attempt++ ) {
			$id = strtolower( wp_generate_password( 10, false, false ) );
			if ( ! self::find_by_public_id( $id ) ) {
				return $id;
			}
		}
		// Extremely unlikely fallback — append uniqid suffix.
		return strtolower( wp_generate_password( 6, false, false ) ) . substr( uniqid(), -4 );
	}
}
