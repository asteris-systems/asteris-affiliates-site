<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Affiliates;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Public affiliate-signup form.
 *
 * Two integration points:
 *   - Shortcode: [aff_signup]  (drop on any page)
 *   - Form POST: handled via admin-post.php  (action: asteris_aff_signup)
 *
 * Flow:
 *   1. Visitor fills form on customer's site
 *   2. Form posts here → validate → INSERT with status = pending (or
 *      approved if `signup_requires_approval` setting is off)
 *   3. Fire welcome / pending email
 *   4. Fire admin notification email
 *   5. Redirect to a thank-you state on the same page
 *
 * Errors are returned via redirect query params so the form can render the
 * appropriate message. No session storage — clean GET-after-POST pattern.
 */
final class Signup_Form {

	public static function register(): void {
		add_shortcode( 'aff_signup', [ self::class, 'shortcode' ] );
		add_action( 'admin_post_nopriv_asteris_aff_signup', [ self::class, 'handle_submit' ] );
		add_action( 'admin_post_asteris_aff_signup',        [ self::class, 'handle_submit' ] );
	}

	// ── Shortcode renderer ──────────────────────────────────────────────────

	public static function shortcode( array $atts = [] ): string {
		$flash = isset( $_GET['aff_signup'] ) ? sanitize_key( wp_unslash( $_GET['aff_signup'] ) ) : '';

		// Defaults come from Settings; shortcode attributes override per-page.
		// Examples:
		//   [aff_signup]
		//   [aff_signup button_color="#FF5B3F" button_label="Join now"]
		//   [aff_signup heading="Become a partner" intro="Earn 30% recurring."]
		//   [aff_signup show_country="0" show_audience="0"]
		$atts = shortcode_atts( [
			'button_color'    => (string) Settings::get( 'signup_button_color',    '#06D6A0' ),
			'button_label'    => (string) Settings::get( 'signup_button_label',    'Apply to be an affiliate →' ),
			'heading'         => (string) Settings::get( 'signup_heading',         'Become an affiliate' ),
			'intro'           => (string) Settings::get( 'signup_intro',           'Earn commission on every customer you refer.' ),
			'show_first_last' => (string) (int) Settings::get( 'signup_show_first_last',   1 ),
			'show_country'    => (string) (int) Settings::get( 'signup_show_country',      1 ),
			'show_audience'   => (string) (int) Settings::get( 'signup_show_audience',     1 ),
			'show_promotion'  => (string) (int) Settings::get( 'signup_show_promotion',    1 ),
			'require_promotion' => (string) (int) Settings::get( 'signup_require_promotion', 1 ),
		], $atts, 'aff_signup' );

		// Sanitise the colour — accept #RGB / #RRGGBB only
		$btn_color = preg_match( '/^#[0-9a-f]{3}([0-9a-f]{3})?$/i', $atts['button_color'] )
			? $atts['button_color']
			: '#06D6A0';
		$btn_label   = sanitize_text_field( $atts['button_label'] );
		$heading     = sanitize_text_field( $atts['heading'] );
		$intro       = sanitize_text_field( $atts['intro'] );
		$show_first_last = (int) $atts['show_first_last'] === 1;
		$show_country    = (int) $atts['show_country']    === 1;
		$show_audience   = (int) $atts['show_audience']   === 1;
		$show_promotion  = (int) $atts['show_promotion']  === 1;
		$require_promotion = (int) $atts['require_promotion'] === 1;

		$terms_url = (string) Settings::get( 'signup_terms_url', '' );

		ob_start();
		?>
		<div class="aff-signup" style="max-width:560px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;">
			<?php if ( $flash === 'ok_pending' ) : ?>
				<div style="background:#ecfdf5;border:1px solid #a7f3d0;border-left:4px solid #059669;border-radius:8px;padding:18px 22px;">
					<h2 style="margin:0 0 6px;color:#065f46;">✓ Application received</h2>
					<p style="margin:0;color:#065f46;">Thanks for applying. We review applications within a few business days and will email you the outcome.</p>
				</div>
			<?php elseif ( $flash === 'ok_approved' ) : ?>
				<div style="background:#ecfdf5;border:1px solid #a7f3d0;border-left:4px solid #06D6A0;border-radius:8px;padding:18px 22px;">
					<h2 style="margin:0 0 6px;color:#065f46;">🎉 You're in</h2>
					<p style="margin:0 0 12px;color:#065f46;">Your affiliate account is active. Sign in to grab your tracking links and start earning.</p>
					<a href="<?php echo esc_url( home_url( '/affiliate-portal/' ) ); ?>" style="display:inline-block;background:#06D6A0;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:600;">Sign in to portal →</a>
				</div>
			<?php elseif ( $flash === 'duplicate' ) : ?>
				<div style="background:#fff8e1;border:1px solid #f0d878;border-left:4px solid #b45309;border-radius:8px;padding:16px 20px;">
					<p style="margin:0;color:#92400e;">An application with that email already exists. <a href="<?php echo esc_url( home_url( '/affiliate-portal/' ) ); ?>" style="color:#92400e;text-decoration:underline;">Sign in here</a> if you're already approved.</p>
				</div>
			<?php elseif ( $flash === 'invalid' ) : ?>
				<div style="background:#fef2f2;border:1px solid #fca5a5;border-left:4px solid #dc2626;border-radius:8px;padding:16px 20px;">
					<p style="margin:0;color:#991b1b;">✗ Please fill in display name + a valid email.</p>
				</div>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:28px;">
					<?php wp_nonce_field( 'asteris_aff_signup', '_aff_nonce' ); ?>
					<input type="hidden" name="action" value="asteris_aff_signup">
					<input type="hidden" name="redirect_to" value="<?php echo esc_attr( self::current_url() ); ?>">
					<input type="hidden" name="aff_render_time" value="<?php echo (int) time(); ?>">
					<?php // Honeypot — real users leave this blank; bots fill every visible-looking field. CSS hides it. ?>
					<div style="position:absolute;left:-9999px;top:-9999px;opacity:0;pointer-events:none;height:0;overflow:hidden;" aria-hidden="true">
						<label>Website (leave blank): <input type="text" name="aff_website_hp" value="" autocomplete="off" tabindex="-1"></label>
					</div>

					<h2 style="margin:0 0 6px;font-size:22px;"><?php echo esc_html( $heading ); ?></h2>
					<p style="margin:0 0 22px;color:#666;font-size:14px;"><?php echo esc_html( $intro ); ?></p>

					<?php if ( $show_first_last ) : ?>
						<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
							<label style="display:block;">
								<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">First name</span>
								<input type="text" name="first_name" maxlength="80" style="width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
							</label>
							<label style="display:block;">
								<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Last name</span>
								<input type="text" name="last_name" maxlength="80" style="width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
							</label>
						</div>
					<?php endif; ?>
					<label style="display:block;margin-bottom:14px;">
						<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Display name *</span>
						<input type="text" name="display_name" maxlength="120" required placeholder="How you'd like to appear publicly" style="width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
					</label>
					<label style="display:block;margin-bottom:14px;">
						<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Email *</span>
						<input type="email" name="email" maxlength="254" required style="width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
					</label>
					<?php if ( $show_country ) : ?>
						<label style="display:block;margin-bottom:14px;">
							<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Country (ISO-2)</span>
							<input type="text" name="country_code" maxlength="2" value="US" style="width:100px;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;text-transform:uppercase;">
						</label>
					<?php endif; ?>
					<?php if ( $show_audience ) : ?>
						<label style="display:block;margin-bottom:14px;">
							<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">Audience size</span>
							<select name="audience_size" style="width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;">
								<option value="">(unspecified)</option>
								<option value="&lt;1k">&lt;1,000</option>
								<option value="1k-10k">1,000–10,000</option>
								<option value="10k-50k">10,000–50,000</option>
								<option value="50k-200k">50,000–200,000</option>
								<option value="&gt;200k">&gt;200,000</option>
							</select>
						</label>
					<?php endif; ?>
					<?php if ( $show_promotion ) : ?>
						<label style="display:block;margin-bottom:18px;">
							<span style="display:block;font-size:13px;font-weight:600;margin-bottom:4px;">How will you promote? <?php echo $require_promotion ? '*' : ''; ?></span>
							<textarea name="promotion_plan" rows="4" <?php echo $require_promotion ? 'required' : ''; ?> placeholder="Newsletter, YouTube channel, podcast, blog, social — anything that gives us a sense of your audience." style="width:100%;padding:8px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;"></textarea>
						</label>
					<?php endif; ?>

					<?php if ( $terms_url !== '' ) : ?>
						<label style="display:block;margin-bottom:18px;font-size:13px;color:#666;">
							<input type="checkbox" name="terms_accepted" value="1" required> I agree to the <a href="<?php echo esc_url( $terms_url ); ?>" target="_blank" rel="noopener" style="color:<?php echo esc_attr( $btn_color ); ?>;"><?php esc_html_e( 'affiliate terms', 'asteris-affiliates' ); ?></a>.
						</label>
					<?php endif; ?>

					<button type="submit" style="background:<?php echo esc_attr( $btn_color ); ?>;color:#fff;border:0;padding:12px 24px;border-radius:6px;font-size:15px;font-weight:700;cursor:pointer;width:100%;"><?php echo esc_html( $btn_label ); ?></button>
				</form>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	// ── Submit handler ──────────────────────────────────────────────────────

	public static function handle_submit(): void {
		check_admin_referer( 'asteris_aff_signup', '_aff_nonce' );

		// Anti-spam layer 1: honeypot field. Real users leave it blank.
		if ( ! empty( $_POST['aff_website_hp'] ) ) {
			self::log_spam( 'honeypot_filled' );
			self::redirect( 'ok_pending' );  // pretend success; never write to DB
		}
		// Anti-spam layer 2: form-render-time floor. Real users take >2s to fill;
		// scripted bots submit in milliseconds.
		$render_time = isset( $_POST['aff_render_time'] ) ? (int) $_POST['aff_render_time'] : 0;
		if ( $render_time > 0 && ( time() - $render_time ) < 2 ) {
			self::log_spam( 'too_fast' );
			self::redirect( 'ok_pending' );
		}
		// Anti-spam layer 3: per-IP rate limit. Max 3 signups/hour from same IP.
		$ip  = (string) ( $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' );
		$ip  = trim( explode( ',', $ip )[0] );
		$key = 'aff_signup_rl_' . md5( $ip );
		$hits = (int) get_transient( $key );
		if ( $hits >= 3 ) {
			self::log_spam( 'rate_limited', [ 'ip_hash' => substr( hash( 'sha256', $ip ), 0, 16 ) ] );
			self::redirect( 'ok_pending' );
		}
		set_transient( $key, $hits + 1, HOUR_IN_SECONDS );

		$display_name = isset( $_POST['display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['display_name'] ) ) : '';
		$email        = isset( $_POST['email'] )        ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

		if ( $display_name === '' || ! is_email( $email ) ) {
			self::redirect( 'invalid' );
		}

		if ( Affiliate_Repository::find_by_email( $email ) ) {
			self::redirect( 'duplicate' );
		}

		$requires_approval = (bool) Settings::get( 'signup_requires_approval', 1 );
		$now    = current_time( 'mysql', true );
		$status = $requires_approval ? 'pending' : 'approved';

		$id = Affiliate_Repository::insert( [
			'first_name'                => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : null,
			'last_name'                 => isset( $_POST['last_name'] )  ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) )  : null,
			'display_name'              => $display_name,
			'email'                     => $email,
			'country_code'              => isset( $_POST['country_code'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['country_code'] ) ) ) : 'US',
			'audience_size'             => isset( $_POST['audience_size'] )   ? sanitize_text_field( wp_unslash( $_POST['audience_size'] ) ) : null,
			'promotion_plan'            => isset( $_POST['promotion_plan'] )  ? sanitize_textarea_field( wp_unslash( $_POST['promotion_plan'] ) ) : null,
			'status'                    => $status,
			'commission_rate_y1_bp'     => (int) Settings::get( 'commission_rate_y1_bp', 2000 ),
			'commission_rate_y2plus_bp' => (int) Settings::get( 'commission_rate_y2plus_bp', 1000 ),
			'approved_at'               => $status === 'approved' ? $now : null,
		] );

		self::log( $status === 'approved' ? 'affiliate.signup_auto_approved' : 'affiliate.applied', $id, [
			'email'        => $email,
			'display_name' => $display_name,
		] );

		// Notify admin (raw wp_mail — Sprint 5 ports to the Email engine)
		if ( (int) Settings::get( 'send_admin_notifications', 1 ) ) {
			$admin_to = (string) Settings::get( 'admin_notification_email', '' ) ?: (string) get_option( 'admin_email' );
			wp_mail(
				$admin_to,
				'[Affiliates] New application: ' . $display_name,
				sprintf( "New affiliate %s\nEmail: %s\nStatus: %s\nReview: %s",
					$display_name, $email, $status,
					admin_url( 'admin.php?page=asteris-affiliates&id=' . (int) $id )
				)
			);
		}

		// Welcome / pending email to applicant — routed through Email engine
		// so admin's WYSIWYG overrides are honoured.
		if ( $status === 'approved' ) {
			\AsterisAffiliates\Email\Renderer::send_template( 'approved', $email, [
				'display_name' => $display_name,
				'portal_url'   => home_url( '/affiliate-portal/' ),
				'tracking_url' => add_query_arg( 'ref', '', home_url( '/' ) ),  // public_id filled by repo's auto-gen on next render
				'y1_rate'      => (string) (int) round( (int) \AsterisAffiliates\Core\Settings::get( 'commission_rate_y1_bp', 2000 ) / 100 ),
				'y2_rate'      => (string) (int) round( (int) \AsterisAffiliates\Core\Settings::get( 'commission_rate_y2plus_bp', 1000 ) / 100 ),
				'cookie_days'  => (string) (int) \AsterisAffiliates\Core\Settings::get( 'cookie_days', 60 ),
			] );
		} else {
			\AsterisAffiliates\Email\Renderer::send_template( 'application_received', $email, [
				'display_name' => $display_name,
			] );
		}

		self::redirect( $status === 'approved' ? 'ok_approved' : 'ok_pending' );
	}

	// ── Internals ───────────────────────────────────────────────────────────

	private static function redirect( string $flash ): void {
		$to = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : home_url( '/' );
		wp_safe_redirect( add_query_arg( 'aff_signup', $flash, $to ) );
		exit;
	}

	private static function current_url(): string {
		$scheme = is_ssl() ? 'https' : 'http';
		return esc_url_raw( $scheme . '://' . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '/' ) );
	}

	private static function log( string $event, ?int $affiliate_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event,
			'affiliate_id' => $affiliate_id,
			'actor'        => 'visitor',
			'payload'      => wp_json_encode( $payload ),
		] );
	}

	private static function log_spam( string $reason, array $extra = [] ): void {
		self::log( 'affiliate.signup_spam_blocked', null, array_merge( [ 'reason' => $reason ], $extra ) );
	}
}
