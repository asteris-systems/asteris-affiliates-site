<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Swipe_Copy;

use AsterisAffiliates\Core\AI_Settings;
use AsterisAffiliates\Core\Settings;
use AsterisShared\AI\Router;

defined( 'ABSPATH' ) || exit;

/**
 * Pre-written + AI-generated marketing copy library for affiliates.
 *
 * Channels: email_subject, email_body, twitter, instagram_caption,
 *           linkedin, facebook, blog_intro, sms.
 *
 * Storage: wp_aff_swipe_copy table.
 *
 * Seeding: install_default_seeds() runs once on activation — gives every new
 * install a starter pack of 16 snippets so affiliates aren't staring at an
 * empty library on day one.
 *
 * AI integration: ai_generate_variant() hooks the optional Asteris AI module
 * (in WP plugin) via a filter. If unavailable, returns null and admin sees a
 * "Connect Asteris AI to generate variants" notice.
 */
final class Library {

	public const SEED_DONE_OPT = 'asteris_aff_swipe_seed_done';

	public static function install_default_seeds(): void {
		if ( get_option( self::SEED_DONE_OPT ) ) { return; }
		$site = get_bloginfo( 'name' );
		$seeds = [
			[ 'email_subject', 'Save 20% — my code inside', 'Subject + 20% feels like a deal.' ],
			[ 'email_subject', "I use {$site} every day — here's why" ],
			[ 'email_subject', "{$site} just made my life easier" ],
			[ 'email_body',    'Quick recommendation', "I've been using {$site} for a while now and it's genuinely changed how I work. Thought you'd want to know about it. Here's my link: {{tracking_url}}" ],
			[ 'twitter',       "Just discovered {$site}. Game changer. {{tracking_url}}" ],
			[ 'twitter',       "If you're not using {$site} yet, you're leaving money on the table. {{tracking_url}}" ],
			[ 'twitter',       "{$site} → the tool I wish I'd had 6 months ago. Try it: {{tracking_url}}" ],
			[ 'instagram_caption', "Real talk: {$site} is the tool I'm telling everyone about right now. Link in bio." ],
			[ 'linkedin',      "I rarely post about tools, but {$site} earned the post. Here's what stood out…" ],
			[ 'facebook',      "Hey friends — wanted to share something that's been working really well for me lately. {{tracking_url}}" ],
			[ 'blog_intro',    "Last month I started using {$site} and the results have been hard to ignore. In this post I'll cover the 3 things that surprised me, what I'd do differently if starting over, and whether it's worth your time." ],
			[ 'sms',           "Hey! Found this — thought of you: {{tracking_url}}" ],
			[ 'email_subject', '24h only — my pick of the year' ],
			[ 'email_body',    'My honest review', "I tested {$site} for 30 days. Here's the unfiltered take. Spoiler: I'm still using it. Try it yourself: {{tracking_url}}" ],
			[ 'twitter',       "3 things {$site} does better than anything else I've tried. Thread 🧵" ],
			[ 'linkedin',      "Recommendation worth your time: {$site}. Why I think it deserves more attention." ],
		];

		global $wpdb;
		$now = current_time( 'mysql', true );
		foreach ( $seeds as $i => $s ) {
			$channel = $s[0];
			$title   = $s[1];
			$body    = $s[2] ?? $s[1];
			$wpdb->insert( $wpdb->prefix . 'aff_swipe_copy', [
				'channel'    => $channel,
				'title'      => substr( $title, 0, 120 ),
				'body'       => $body,
				'ai_variant' => 0,
				'sort_order' => ( $i + 1 ) * 10,
				'active'     => 1,
				'created_at' => $now,
			] );
		}
		update_option( self::SEED_DONE_OPT, 1, false );
	}

	/** Return active snippets, optionally filtered by channel. */
	public static function list( ?string $channel = null ): array {
		global $wpdb;
		if ( $channel ) {
			return (array) $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}aff_swipe_copy WHERE active = 1 AND channel = %s ORDER BY sort_order ASC, id DESC",
				$channel
			) );
		}
		return (array) $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}aff_swipe_copy WHERE active = 1 ORDER BY channel ASC, sort_order ASC, id DESC"
		);
	}

	public static function add( string $channel, string $title, string $body, bool $ai_variant = false ): int {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_swipe_copy', [
			'channel'    => $channel,
			'title'      => substr( $title, 0, 120 ),
			'body'       => $body,
			'ai_variant' => $ai_variant ? 1 : 0,
			'sort_order' => 100,
			'active'     => 1,
			'created_at' => current_time( 'mysql', true ),
		] );
		return (int) $wpdb->insert_id;
	}

	public static function delete( int $id ): void {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'aff_swipe_copy', [ 'id' => $id ] );
	}

	/**
	 * Edit an existing snippet's channel, title, and body. Other fields
	 * (ai_variant flag, active state, sort_order) are preserved — toggle the
	 * Active state via handle_toggle, not here.
	 */
	public static function update( int $id, string $channel, string $title, string $body ): bool {
		global $wpdb;
		$res = $wpdb->update(
			$wpdb->prefix . 'aff_swipe_copy',
			[
				'channel' => $channel,
				'title'   => substr( $title, 0, 120 ),
				'body'    => $body,
			],
			[ 'id' => $id ]
		);
		return $res !== false;
	}

	public static function get( int $id ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_swipe_copy WHERE id = %d",
			$id
		) );
		return $row ?: null;
	}

	/**
	 * Generate an AI variant via the BYO-key Router.
	 *
	 * v1.2.5: replaced the apply_filters('asteris_ai_generate_text') WP-plugin
	 * dependency with a direct AsterisShared\AI\Router call. Customers paste
	 * their own OpenAI or Anthropic key in AI Settings — no central proxy, no
	 * dependency on having the Asteris WP plugin installed.
	 *
	 * Returns:
	 *   string  → the generated variant text
	 *   array   → ['error' => string] when something went wrong, so the
	 *             admin handler can surface the actual reason (missing key vs
	 *             vendor error vs Pro-gate) instead of a generic "unavailable".
	 */
	public static function ai_generate_variant( string $base_snippet, string $channel, string $product_name ) {
		// Pro-only — free tier sees library + can add manually, but no AI variant generation
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'ai_swipe_copy' ) ) {
			return [ 'error' => 'pro_only' ];
		}

		$keys = AI_Settings::get_keys_for_router();
		if ( $keys === [] ) {
			return [ 'error' => 'no_key' ];
		}

		$model = AI_Settings::default_model();
		// If the configured default's vendor key isn't set, fall back to whichever
		// vendor IS configured so the customer doesn't get stuck.
		$vendor_for_default = Router::vendor_for_model( $model );
		if ( $vendor_for_default === Router::VENDOR_ANTHROPIC && empty( $keys['anthropic_key'] ) ) {
			$model = 'gpt-4o-mini';
		} elseif ( $vendor_for_default === Router::VENDOR_OPENAI && empty( $keys['openai_key'] ) ) {
			$model = Router::DEFAULT_MODEL;
		}

		$system = 'You are a marketing copywriter writing promotional content for an affiliate to share. Output ONLY the rewritten text, no preamble, no commentary, no quotes around it.';
		$prompt = sprintf(
			"Rewrite this promotional %s for the product '%s' in a fresh, conversion-focused tone. Keep it under 280 characters if Twitter, under 80 chars if a subject line. Keep any {{tracking_url}} placeholders intact verbatim. Original:\n\n%s",
			$channel, $product_name, $base_snippet
		);

		$res = Router::generate( $model, $prompt, array_merge( $keys, [
			'system'      => $system,
			'max_tokens'  => 400,
			'temperature' => 0.85,
		] ) );

		if ( ! $res['ok'] ) {
			return [ 'error' => 'vendor_error', 'message' => $res['error'] ];
		}
		$text = trim( $res['text'] );
		return $text !== '' ? $text : [ 'error' => 'empty' ];
	}
}
