<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Email;

defined( 'ABSPATH' ) || exit;

/**
 * Central catalogue of every transactional email Asteris Affiliates fires.
 *
 * Ported from the licence-server's Email/Template_Registry pattern — same
 * shape, affiliate-specific copy. Each template registers:
 *
 *   - slug          stable identifier (option key `asteris_aff_email_tpl_{slug}`)
 *   - group         'affiliate' | 'admin'
 *   - label         human label shown in admin list
 *   - description   when this fires
 *   - default_subject + default_body — used unless overridden
 *   - placeholders  {{tag}} list with descriptions
 *   - required      placeholders that MUST appear in any saved override
 *   - sample        example data used for live preview + Send Test
 */
final class Template_Registry {

	/** @return array<string,array<string,mixed>> */
	public static function all(): array {
		return [
			// ── AFFILIATE-FACING (12) ────────────────────────────────────────

			'signin_link' => [
				'group' => 'affiliate', 'label' => 'Portal sign-in link',
				'description' => 'Sent when affiliate requests sign-in via /affiliate-portal/. Single-use 15-min link.',
				'default_subject' => 'Your affiliate portal sign-in link',
				'default_body' => '<h1 style="color:#0a0a0a;margin:0 0 16px;">Sign in</h1>'
					. '<p>Hi {{display_name}},</p>'
					. '<p>Click below to access your affiliate portal. Link expires in 15 minutes.</p>'
					. '<div style="text-align:center;margin:28px 0;"><a href="{{magic_link}}" style="display:inline-block;padding:14px 28px;background:#06D6A0;color:#fff;text-decoration:none;border-radius:6px;font-weight:700;">Sign in →</a></div>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'magic_link' => 'Tokenised /affiliate-portal/ URL' ],
				'required' => [ 'magic_link' ],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'magic_link' => 'https://yoursite.com/affiliate-portal/?aff_action=verify&token=demo' ],
			],

			'application_received' => [
				'group' => 'affiliate', 'label' => 'Application received',
				'description' => 'Sent immediately after public-form signup. Sets expectation for review timeline.',
				'default_subject' => 'We received your affiliate application',
				'default_body' => '<h1 style="color:#0a0a0a;margin:0 0 16px;">Application received</h1>'
					. '<p>Hi {{display_name}},</p>'
					. '<p>Thanks for applying to our affiliate program. We review applications within a few business days and will email you the outcome.</p>'
					. '<p style="color:#666;font-size:13px;">Questions? Reply to this email.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate' ],
			],

			'approved' => [
				'group' => 'affiliate', 'label' => 'Approved',
				'description' => 'Welcome email when admin approves an affiliate. Includes portal sign-in link.',
				'default_subject' => "You're in — welcome to our affiliate program",
				'default_body' => '<h1 style="color:#0a0a0a;margin:0 0 16px;">🎉 You\'re in</h1>'
					. '<p>Hi {{display_name}},</p>'
					. '<p>Your affiliate account is active. Sign in to grab your tracking links, swipe copy, and dashboard.</p>'
					. '<div style="text-align:center;margin:24px 0;"><a href="{{portal_url}}" style="display:inline-block;padding:14px 28px;background:#06D6A0;color:#fff;text-decoration:none;border-radius:6px;font-weight:700;">Open portal →</a></div>'
					. '<p><strong>Your terms:</strong> {{y1_rate}}% Year 1, {{y2_rate}}% Year 2+ (recurring on every renewal). {{cookie_days}}-day cookie window.</p>'
					. '<p>Your unique tracking link:<br><code style="background:#f9fafb;padding:6px 10px;border-radius:4px;font-size:13px;">{{tracking_url}}</code></p>',
				'placeholders' => [
					'display_name' => 'Affiliate name', 'portal_url' => 'Portal magic-link URL',
					'tracking_url' => 'Their ?ref= URL', 'y1_rate' => 'Year-1 commission %', 'y2_rate' => 'Year-2+ %',
					'cookie_days' => 'Attribution window days',
				],
				'required' => [ 'portal_url', 'tracking_url' ],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'portal_url' => 'https://yoursite.com/affiliate-portal/?token=demo', 'tracking_url' => 'https://yoursite.com/?ref=alex', 'y1_rate' => '20', 'y2_rate' => '10', 'cookie_days' => '60' ],
			],

			'rejected' => [
				'group' => 'affiliate', 'label' => 'Application rejected',
				'description' => 'Polite rejection email. Includes optional reason note.',
				'default_subject' => 'Re: your affiliate application',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>Thanks for applying. After reviewing your application, we\'ve decided not to move forward at this time.</p>'
					. '{{reason_block}}'
					. '<p>You\'re welcome to re-apply in 6 months as your audience grows.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'reason_block' => 'Optional reason paragraph or empty' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'reason_block' => '<p style="background:#f5f5f5;padding:12px;border-radius:6px;">Our note: We\'re looking for partners with established audiences.</p>' ],
			],

			'first_conversion' => [
				'group' => 'affiliate', 'label' => 'First conversion 🎉',
				'description' => 'Celebratory — fires on the affiliate\'s very first commission row.',
				'default_subject' => '🎉 Your first commission!',
				'default_body' => '<h1 style="color:#0a0a0a;margin:0 0 16px;">First sale 🎉</h1>'
					. '<p>Hi {{display_name}},</p>'
					. '<p>Someone you referred just bought. You\'ve earned your first commission: <strong>${{amount}} {{currency}}</strong>.</p>'
					. '<p>It\'s in your dashboard now as <strong>pending</strong>. After the {{refund_window_days}}-day refund window clears, it moves to <strong>approved</strong> and will be in your next payout.</p>'
					. '<div style="text-align:center;margin:24px 0;"><a href="{{portal_url}}" style="display:inline-block;padding:12px 24px;background:#06D6A0;color:#fff;text-decoration:none;border-radius:6px;font-weight:700;">See in dashboard →</a></div>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'amount' => 'Formatted commission amount', 'currency' => 'Currency', 'refund_window_days' => 'Days until approved', 'portal_url' => 'Portal URL' ],
				'required' => [ 'amount' ],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'amount' => '47.50', 'currency' => 'USD', 'refund_window_days' => '30', 'portal_url' => 'https://yoursite.com/affiliate-portal/' ],
			],

			'commission_refunded' => [
				'group' => 'affiliate', 'label' => 'Commission clawed back',
				'description' => 'Fires when a referred order is refunded — commission removed or reduced.',
				'default_subject' => 'A commission was reversed',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>Heads-up: order #{{order_id}} was refunded by the customer. Per our terms, the commission ({{amount}}) has been {{action}}.</p>'
					. '<p style="color:#666;font-size:13px;">This is normal — happens to every affiliate program. If your overall refund rate stays low, no further action needed.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'order_id' => 'WC order ID', 'amount' => 'Original commission amount', 'action' => '"reversed" or "reduced"' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'order_id' => '1234', 'amount' => '$47.50', 'action' => 'reversed' ],
			],

			'payout_sent' => [
				'group' => 'affiliate', 'label' => 'Payout sent',
				'description' => 'Confirmation when a monthly payout has been sent (Sprint 5B will fire this from the payout batch).',
				'default_subject' => 'Your affiliate payout: ${{amount}} {{currency}}',
				'default_body' => '<h1 style="color:#0a0a0a;margin:0 0 16px;">💰 Payout sent</h1>'
					. '<p>Hi {{display_name}},</p>'
					. '<p>We just sent <strong>${{amount}} {{currency}}</strong> to your {{payout_method}}, covering {{commission_count}} commission(s).</p>'
					. '<p>Bank credit usually takes 1–3 business days.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'amount' => 'Formatted amount', 'currency' => 'Currency', 'payout_method' => 'e.g. "Stripe Connect"', 'commission_count' => 'Count' ],
				'required' => [ 'amount' ],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'amount' => '247.50', 'currency' => 'USD', 'payout_method' => 'Stripe Connect', 'commission_count' => '5' ],
			],

			'auto_suspended' => [
				'group' => 'affiliate', 'label' => 'Auto-suspended (refund rate)',
				'description' => 'Fires when refund-rate cron auto-suspends an affiliate. Affiliate gets notified + can appeal.',
				'default_subject' => 'Your affiliate account has been paused',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>Your affiliate account has been temporarily paused — your 30-day refund rate ({{rate_pct}}%) exceeded our threshold ({{threshold_pct}}%).</p>'
					. '<p>This is automatic. Reply to this email if you\'d like to discuss — we re-instate accounts when the underlying issue is resolved (e.g. a campaign that targeted the wrong audience).</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'rate_pct' => 'Their 30d refund rate', 'threshold_pct' => 'Configured threshold' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'rate_pct' => '32', 'threshold_pct' => '20' ],
			],

			'drip_day7' => [
				'group' => 'affiliate', 'label' => 'Drip · day 7',
				'description' => 'Nudge sent 7 days after approval if no clicks yet. (Manual fire from admin in Sprint 5A; cron in Sprint 5B+.)',
				'default_subject' => 'Quick start: your affiliate link',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>You\'ve been an affiliate for a week. Easiest first move: pin your tracking link in your social bios.</p>'
					. '<p><code style="background:#f9fafb;padding:4px 8px;border-radius:4px;">{{tracking_url}}</code></p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'tracking_url' => 'Their ?ref= URL' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'tracking_url' => 'https://yoursite.com/?ref=alex' ],
			],

			'drip_day30' => [
				'group' => 'affiliate', 'label' => 'Drip · day 30',
				'description' => '30-day check-in with click + conversion summary.',
				'default_subject' => 'Your first 30 days as an affiliate',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>30-day stats: <strong>{{clicks_30d}}</strong> clicks, <strong>{{conversions_30d}}</strong> conversions. Reply if you want help amplifying.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'clicks_30d' => 'Click count', 'conversions_30d' => 'Conversion count' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'clicks_30d' => '142', 'conversions_30d' => '3' ],
			],

			'coupon_assigned' => [
				'group' => 'affiliate', 'label' => 'Coupon code assigned',
				'description' => 'Fires when admin assigns a coupon to the affiliate.',
				'default_subject' => 'Your custom coupon code is live: {{coupon_code}}',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>We\'ve assigned coupon <code style="background:#f9fafb;padding:3px 8px;border-radius:4px;">{{coupon_code}}</code> to your affiliate account.</p>'
					. '<p>Anyone who uses this code at checkout converts on your link — no click required. Great for podcast / YouTube / in-person promotion.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name', 'coupon_code' => 'Code string' ],
				'required' => [ 'coupon_code' ],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'coupon_code' => 'ALEX25' ],
			],

			'bank_changed' => [
				'group' => 'affiliate', 'label' => 'Bank details changed',
				'description' => 'Security notice when affiliate updates Stripe Connect / bank-transfer details.',
				'default_subject' => 'Your payout method was updated',
				'default_body' => '<p>Hi {{display_name}},</p>'
					. '<p>Heads-up: your payout method was just updated. If this wasn\'t you, reply immediately.</p>',
				'placeholders' => [ 'display_name' => 'Affiliate name' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate' ],
			],

			// ── ADMIN-FACING (3) ──────────────────────────────────────────────

			'admin_new_application' => [
				'group' => 'admin', 'label' => 'New application (admin alert)',
				'description' => 'Fires to admin email when a new public-form application arrives.',
				'default_subject' => 'New affiliate application: {{display_name}}',
				'default_body' => '<p>New affiliate application:</p>'
					. '<ul>'
					. '<li><strong>Name:</strong> {{display_name}}</li>'
					. '<li><strong>Email:</strong> {{email}}</li>'
					. '<li><strong>Audience:</strong> {{audience_size}}</li>'
					. '</ul>'
					. '<p><a href="{{admin_url}}">Review in admin →</a></p>',
				'placeholders' => [ 'display_name' => 'Name', 'email' => 'Email', 'audience_size' => 'Audience tier', 'admin_url' => 'Direct admin link' ],
				'required' => [],
				'sample' => [ 'display_name' => 'Alex Affiliate', 'email' => 'alex@example.com', 'audience_size' => '10k-50k', 'admin_url' => 'https://yoursite.com/wp-admin/admin.php?page=asteris-affiliates&id=42' ],
			],

			'admin_auto_suspended_digest' => [
				'group' => 'admin', 'label' => 'Auto-suspends (admin digest)',
				'description' => 'Daily digest if any affiliates were auto-suspended by the refund-rate scanner.',
				'default_subject' => '{{count}} affiliate(s) auto-suspended today',
				'default_body' => '<p>{{count}} affiliate(s) auto-suspended for elevated refund rate today:</p><pre>{{names}}</pre>',
				'placeholders' => [ 'count' => 'Number', 'names' => 'Newline-joined names' ],
				'required' => [],
				'sample' => [ 'count' => '2', 'names' => "Alex Affiliate\nBeth Affiliate" ],
			],

			'admin_payout_batch_summary' => [
				'group' => 'admin', 'label' => 'Payout batch summary (admin)',
				'description' => 'Sent after a monthly payout batch runs (Sprint 5B).',
				'default_subject' => 'Payout batch {{batch_id}}: {{paid}} paid / {{failed}} failed',
				'default_body' => '<p>Batch <code>{{batch_id}}</code>:</p><ul><li>Attempted: {{attempted}}</li><li>Paid: {{paid}}</li><li>Failed: {{failed}}</li></ul>',
				'placeholders' => [ 'batch_id' => 'Batch ID', 'attempted' => 'Count', 'paid' => 'Count', 'failed' => 'Count' ],
				'required' => [],
				'sample' => [ 'batch_id' => 'b_2026_06_01', 'attempted' => '12', 'paid' => '11', 'failed' => '1' ],
			],
		];
	}

	public static function get( string $slug ): ?array {
		return self::all()[ $slug ] ?? null;
	}

	/** @return array<string,string> slug => label */
	public static function by_group( string $group ): array {
		$out = [];
		foreach ( self::all() as $slug => $def ) {
			if ( ( $def['group'] ?? '' ) === $group ) {
				$out[ $slug ] = (string) $def['label'];
			}
		}
		asort( $out );
		return $out;
	}
}
