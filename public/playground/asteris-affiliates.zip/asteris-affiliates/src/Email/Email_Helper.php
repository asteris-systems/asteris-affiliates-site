<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Email;

defined( 'ABSPATH' ) || exit;

/**
 * Shared HTML chrome + headers for all Asteris Affiliates transactional
 * emails. Branded with the locked teal #06D6A0 + store name.
 *
 * Wraps the body content in a mobile-friendly inline-CSS shell — every
 * email shares the same outer layout so customers can edit just the
 * inner content without touching the chrome.
 */
final class Email_Helper {

	public static function wrap_html( string $inner ): string {
		$site_name = wp_specialchars_decode( (string) get_bloginfo( 'name' ) );
		$site_url  = home_url( '/' );
		return '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>'
		. '<body style="margin:0;padding:0;background:#fafafa;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,system-ui,sans-serif;color:#0a0a0a;line-height:1.55;">'
		. '<div style="max-width:600px;margin:0 auto;padding:32px 24px;">'
		. '<div style="text-align:center;margin-bottom:24px;">'
		.   '<a href="' . esc_url( $site_url ) . '" style="text-decoration:none;color:#06D6A0;font-size:24px;font-weight:700;">★ ' . esc_html( $site_name ) . '</a>'
		.   '<div style="font-size:11px;color:#9ca3af;letter-spacing:0.06em;text-transform:uppercase;margin-top:2px;">Affiliate program</div>'
		. '</div>'
		. '<div style="background:#fff;border:1px solid #eee;border-radius:8px;padding:32px;">'
		. $inner
		. '</div>'
		. '<p style="text-align:center;margin:24px 0 0;color:#9ca3af;font-size:11px;">'
		.   esc_html( $site_name ) . ' · powered by Asteris Affiliates'
		. '</p>'
		. '</div></body></html>';
	}

	public static function headers(): array {
		$site_name = wp_specialchars_decode( (string) get_bloginfo( 'name' ) );
		$from      = (string) ( get_option( 'admin_email' ) ?: 'no-reply@' . wp_parse_url( home_url(), PHP_URL_HOST ) );
		return [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $site_name . ' Affiliates <' . $from . '>',
			'Reply-To: ' . $site_name . ' Affiliates <' . $from . '>',
		];
	}
}
