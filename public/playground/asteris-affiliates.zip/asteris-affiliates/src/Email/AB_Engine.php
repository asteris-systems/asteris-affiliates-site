<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Email;

defined( 'ABSPATH' ) || exit;

/**
 * A/B test engine for transactional emails.
 *
 * Storage: wp_aff_ab_emails — one row per (template_slug, variant_label).
 * Weight = relative share (0–100). If 2 variants both weight 50, traffic
 * splits 50/50. If 3 variants 50/30/20, that's the distribution.
 *
 * Tracking:
 *   - sent_count incremented on every render that picked this variant
 *   - open_count via tracking pixel /asteris-aff-pixel.gif?v=<id>
 *   - click_count via outbound link wrapping (future v1.2)
 *
 * Significance: not auto-computed — admin sees raw counts + open rate.
 * Page_AB_Tests admin view (placeholder for v1.2) will surface a stat-sig
 * chi-square calculation.
 */
final class AB_Engine {

	public static function register(): void {
		add_action( 'init', [ self::class, 'maybe_handle_pixel' ], 1 );
	}

	/**
	 * Pick a variant for this template (or null if no active variants exist).
	 * Deterministic per-render — random pick weighted by `weight` column.
	 */
	public static function pick_variant( string $template_slug ): ?array {
		// Pro-only — free tier sends template-only (no variants)
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'ab_emails' ) ) { return null; }
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_ab_emails
			 WHERE template_slug = %s AND active = 1",
			$template_slug
		), ARRAY_A );
		if ( ! $rows ) { return null; }

		$total = 0;
		foreach ( $rows as $r ) { $total += max( 1, (int) $r['weight'] ); }
		if ( $total <= 0 ) { return null; }

		$pick = wp_rand( 1, $total );
		$accum = 0;
		foreach ( $rows as $r ) {
			$accum += max( 1, (int) $r['weight'] );
			if ( $pick <= $accum ) { return $r; }
		}
		return $rows[0];
	}

	public static function increment_sent( int $variant_id ): void {
		if ( $variant_id <= 0 ) { return; }
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_ab_emails SET sent_count = sent_count + 1 WHERE id = %d",
			$variant_id
		) );
	}

	public static function increment_open( int $variant_id ): void {
		if ( $variant_id <= 0 ) { return; }
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_ab_emails SET open_count = open_count + 1 WHERE id = %d",
			$variant_id
		) );
	}

	/**
	 * Inject a 1×1 transparent tracking pixel before </body>. If $variant_id
	 * is 0 (no A/B for this template), still inject so we track baseline opens
	 * — pixel URL with v=0 is silently dropped by handler.
	 */
	public static function inject_open_pixel( string $body_html, int $variant_id, string $template_slug ): string {
		if ( $variant_id <= 0 ) { return $body_html; }
		$pixel_url = add_query_arg( [
			'asteris_aff_pixel' => '1',
			'v' => $variant_id,
			't' => substr( hash( 'sha256', $variant_id . '|' . $template_slug . '|' . wp_salt() ), 0, 16 ),
		], home_url( '/' ) );
		$pixel = '<img src="' . esc_url( $pixel_url ) . '" width="1" height="1" alt="" style="display:none;border:0;">';
		if ( stripos( $body_html, '</body>' ) !== false ) {
			return str_ireplace( '</body>', $pixel . '</body>', $body_html );
		}
		return $body_html . $pixel;
	}

	public static function maybe_handle_pixel(): void {
		if ( empty( $_GET['asteris_aff_pixel'] ) ) { return; }
		$vid = isset( $_GET['v'] ) ? (int) $_GET['v'] : 0;
		if ( $vid > 0 ) {
			self::increment_open( $vid );
		}
		// 1x1 transparent GIF
		header( 'Content-Type: image/gif' );
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		echo base64_decode( 'R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==' );
		exit;
	}

	public static function add_variant( string $template_slug, string $label, string $subject, string $body, int $weight = 50 ): int {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_ab_emails', [
			'template_slug' => $template_slug,
			'variant_label' => substr( $label, 0, 8 ),
			'subject'       => $subject,
			'body'          => $body,
			'weight'        => max( 1, min( 100, $weight ) ),
			'active'        => 1,
			'created_at'    => current_time( 'mysql', true ),
		] );
		return (int) $wpdb->insert_id;
	}
}
