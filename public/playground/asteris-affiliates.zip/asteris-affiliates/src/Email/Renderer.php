<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Email;

defined( 'ABSPATH' ) || exit;

/**
 * Render + send templates from the registry/store.
 *
 *   Renderer::render($slug, $data)
 *     → array{subject,body,is_override}  (substituted, NOT wrapped)
 *
 *   Renderer::render_sample($slug)
 *     → render with the registry's sample data (preview + Send-test)
 *
 *   Renderer::send_template($slug, $to, $data)
 *     → render + wrap_html + wp_mail + log to aff_events
 */
final class Renderer {

	/** Substitute {{placeholder}} tokens — unknowns left as-is so missing data is visible. */
	private static function substitute( string $template, array $data ): string {
		return preg_replace_callback( '/\{\{\s*([a-z_][a-z0-9_]*)\s*\}\}/i', static function ( $m ) use ( $data ) {
			return array_key_exists( $m[1], $data ) ? (string) $data[ $m[1] ] : $m[0];
		}, $template );
	}

	/** @return array{subject:string,body:string,is_override:bool} */
	public static function render( string $slug, array $data ): array {
		$eff = Template_Store::effective( $slug );
		return [
			'subject'     => self::substitute( $eff['subject'], $data ),
			'body'        => self::substitute( $eff['body'],    $data ),
			'is_override' => $eff['is_override'],
		];
	}

	public static function render_sample( string $slug ): array {
		$def    = Template_Registry::get( $slug );
		$sample = is_array( $def ) ? (array) ( $def['sample'] ?? [] ) : [];
		return self::render( $slug, $sample );
	}

	public static function send_template( string $slug, string $to, array $data ): bool {
		// Per-recipient per-template per-day throttle (Sprint 9B — Email\Throttle).
		// Returns false silently when throttled — caller's "did it send" check
		// stays accurate and the event log captures the skip.
		if ( ! Throttle::should_send( $slug, $to ) ) {
			return false;
		}

		// A/B test routing (Sprint 10+ — AB_Engine). If active variants exist
		// for this template, swap subject/body before send + log which variant.
		$ab = AB_Engine::pick_variant( $slug );
		$rendered = self::render( $slug, $data );
		if ( $ab ) {
			$rendered['subject'] = self::substitute( $ab['subject'], $data );
			$rendered['body']    = self::substitute( $ab['body'],    $data );
			AB_Engine::increment_sent( (int) $ab['id'] );
		}
		$body     = Email_Helper::wrap_html( $rendered['body'] );
		$body     = AB_Engine::inject_open_pixel( $body, (int) ( $ab['id'] ?? 0 ), $slug );
		$ok       = wp_mail( $to, $rendered['subject'], $body, Email_Helper::headers() );

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $ok ? 'email.sent' : 'email.failed',
			'affiliate_id' => null,
			'actor'        => is_user_logged_in() ? 'admin:' . ( wp_get_current_user()->user_login ?: 'unknown' ) : 'system',
			'payload'      => wp_json_encode( [
				'template'    => $slug,
				'to'          => $to,
				'subject'     => $rendered['subject'],
				'is_override' => $rendered['is_override'],
				'ab_variant'  => $ab['variant_label'] ?? null,
			] ),
		] );
		return $ok;
	}
}
