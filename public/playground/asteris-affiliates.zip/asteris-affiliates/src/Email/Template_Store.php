<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Email;

defined( 'ABSPATH' ) || exit;

/**
 * Per-template override storage backed by wp_options.
 *
 *   Option key: asteris_aff_email_tpl_{slug}
 *   Shape:      [ subject, body, updated_at, updated_by ]
 *   Missing    = use registry default (zero-config baseline)
 *
 * Restore default = delete_option() — registry default always available.
 */
final class Template_Store {

	private static function opt_key( string $slug ): string {
		return 'asteris_aff_email_tpl_' . sanitize_key( $slug );
	}

	/** @return array{subject:string,body:string,updated_at:int,updated_by:string}|null */
	public static function get_override( string $slug ): ?array {
		$row = get_option( self::opt_key( $slug ), null );
		return is_array( $row ) ? $row : null;
	}

	public static function has_override( string $slug ): bool {
		return self::get_override( $slug ) !== null;
	}

	/**
	 * Effective template = override if saved, else registry default.
	 * @return array{subject:string,body:string,is_override:bool}
	 */
	public static function effective( string $slug ): array {
		$def = Template_Registry::get( $slug );
		$ov  = self::get_override( $slug );
		if ( $ov !== null ) {
			return [
				'subject'     => (string) ( $ov['subject'] ?? $def['default_subject'] ?? '' ),
				'body'        => (string) ( $ov['body']    ?? $def['default_body']    ?? '' ),
				'is_override' => true,
			];
		}
		return [
			'subject'     => (string) ( $def['default_subject'] ?? '' ),
			'body'        => (string) ( $def['default_body']    ?? '' ),
			'is_override' => false,
		];
	}

	/**
	 * Save override, validating required placeholders are still present.
	 *
	 * @return true|\WP_Error
	 */
	public static function save_override( string $slug, string $subject, string $body ) {
		$def = Template_Registry::get( $slug );
		if ( ! $def ) {
			return new \WP_Error( 'unknown_template', 'No such template: ' . $slug );
		}
		$required = (array) ( $def['required'] ?? [] );
		$missing  = [];
		foreach ( $required as $ph ) {
			if ( strpos( $body, '{{' . $ph . '}}' ) === false && strpos( $subject, '{{' . $ph . '}}' ) === false ) {
				$missing[] = $ph;
			}
		}
		if ( $missing !== [] ) {
			return new \WP_Error( 'missing_required', sprintf(
				'You removed %d required placeholder(s): %s. Add them back before saving — without them the email would break.',
				count( $missing ), '{{' . implode( '}}, {{', $missing ) . '}}'
			) );
		}
		update_option( self::opt_key( $slug ), [
			'subject'    => $subject,
			'body'       => $body,
			'updated_at' => time(),
			'updated_by' => wp_get_current_user()->user_login ?: 'system',
		], false );
		return true;
	}

	public static function restore_default( string $slug ): void {
		delete_option( self::opt_key( $slug ) );
	}
}
