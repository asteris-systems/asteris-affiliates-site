<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Email;

defined( 'ABSPATH' ) || exit;

/**
 * Per-recipient per-template per-day rate limit on transactional emails.
 *
 * Prevents accidental spam — e.g. a buggy webhook firing 50 commission
 * notifications to the same affiliate in 5 minutes.
 *
 * Limits (admin-overrideable via filter):
 *   - Default cap: 10 emails of the same template per recipient per UTC day
 *   - Hard cap:    50 (absolute ceiling regardless of filter)
 *
 * Renderer::send_template() calls Throttle::should_send() BEFORE wp_mail.
 * If throttled, the send is skipped + logged as email.throttled.
 */
final class Throttle {

	public const DEFAULT_DAILY_CAP = 10;
	public const HARD_CAP          = 50;

	/** Templates that are SAFE-CRITICAL — never throttled. */
	private const ALLOWLIST = [
		'magic_link',          // sign-in link must always go through
		'bank_changed',        // security alert
		'stripe_dispute',
		'payout_failed',
	];

	/**
	 * Returns true if THIS send is allowed. Atomically increments the counter
	 * via INSERT … ON DUPLICATE KEY UPDATE so concurrent processes don't
	 * over-shoot the cap.
	 */
	public static function should_send( string $template_slug, string $recipient ): bool {
		if ( in_array( $template_slug, self::ALLOWLIST, true ) ) { return true; }
		if ( $recipient === '' ) { return false; }

		$cap = (int) apply_filters( 'asteris_aff_email_daily_cap', self::DEFAULT_DAILY_CAP, $template_slug, $recipient );
		$cap = max( 1, min( self::HARD_CAP, $cap ) );

		global $wpdb;
		$table = $wpdb->prefix . 'aff_throttle';
		$day   = gmdate( 'Y-m-d' );
		$now   = current_time( 'mysql', true );

		// Atomic upsert + increment
		$wpdb->query( $wpdb->prepare(
			"INSERT INTO {$table} (recipient, template_slug, day_utc, count_today, last_sent_at)
			 VALUES (%s, %s, %s, 1, %s)
			 ON DUPLICATE KEY UPDATE count_today = count_today + 1, last_sent_at = VALUES(last_sent_at)",
			strtolower( $recipient ), $template_slug, $day, $now
		) );

		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT count_today FROM {$table} WHERE recipient = %s AND template_slug = %s AND day_utc = %s LIMIT 1",
			strtolower( $recipient ), $template_slug, $day
		) );

		if ( $count > $cap ) {
			// Mark as throttled — we've already incremented, but cap means "no more"
			$wpdb->insert( $wpdb->prefix . 'aff_events', [
				'occurred_at'  => $now,
				'event_type'   => 'email.throttled',
				'affiliate_id' => null,
				'actor'        => 'system',
				'payload'      => wp_json_encode( [
					'template'  => $template_slug,
					'recipient' => $recipient,
					'count'     => $count,
					'cap'       => $cap,
				] ),
			] );
			return false;
		}
		return true;
	}

	/** Daily cleanup — drop rows older than 90 days. Hooked to daily cron. */
	public static function cleanup_old(): int {
		global $wpdb;
		$cut = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
		return (int) $wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->prefix}aff_throttle WHERE day_utc < %s",
			$cut
		) );
	}
}
