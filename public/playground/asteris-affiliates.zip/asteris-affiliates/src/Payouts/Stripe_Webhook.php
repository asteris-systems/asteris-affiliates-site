<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Payouts;

use AsterisAffiliates\Core\Settings;
use AsterisAffiliates\Core\Util\Secret_Writer;

defined( 'ABSPATH' ) || exit;

/**
 * Stripe webhook listener.
 *
 *   POST /wp-json/asteris-affiliates/v1/stripe-webhook
 *
 * Customer points their Stripe Dashboard webhook to this URL, supplies the
 * signing secret in Settings (stored via Secret_Writer → mu-plugin, not DB).
 *
 * Events handled:
 *   - transfer.failed       — Stripe sent back the funds; mark our payout as failed
 *   - transfer.reversed     — full reversal; mark payout as failed
 *   - account.updated       — connected account changed status (verified/restricted/disabled)
 *
 * Other events are accepted (200 OK) but ignored — keeps Stripe from
 * retrying things we don't care about + leaves room for future expansion.
 *
 * Without this listener, a post-success transfer failure (Stripe Connect
 * account closed, frozen, insufficient platform balance) would never
 * propagate back to our payout row — affiliate would think they got
 * paid when they didn't.
 *
 * Signature verification: required. Stripe signs every event with
 * HMAC-SHA256 over the body; we recompute + compare in constant time.
 * Without it, anyone can POST fake events to mark payouts as paid/failed.
 */
final class Stripe_Webhook {

	private const NAMESPACE = 'asteris-affiliates/v1';
	private const ROUTE     = '/stripe-webhook';

	/** Tolerance for signature timestamp drift (Stripe default = 5min). */
	private const SIGNATURE_TOLERANCE = 300;

	public static function register(): void {
		register_rest_route( self::NAMESPACE, self::ROUTE, [
			'methods'             => 'POST',
			'callback'            => [ self::class, 'handle' ],
			'permission_callback' => '__return_true',  // signature is the auth
		] );
	}

	public static function handle( \WP_REST_Request $request ): \WP_REST_Response {
		$body      = $request->get_body();
		$signature = (string) ( $request->get_header( 'stripe_signature' ) ?? '' );

		$secret = self::resolve_signing_secret();
		if ( $secret === '' ) {
			self::log( 'webhook.no_secret_configured', [], 'error' );
			return new \WP_REST_Response( [ 'error' => 'webhook_secret_not_configured' ], 500 );
		}
		if ( ! self::verify_signature( $body, $signature, $secret ) ) {
			self::log( 'webhook.signature_invalid', [ 'sig_header' => substr( $signature, 0, 40 ) . '…' ], 'warning' );
			return new \WP_REST_Response( [ 'error' => 'invalid_signature' ], 400 );
		}

		$event = json_decode( $body, true );
		if ( ! is_array( $event ) || empty( $event['type'] ) || empty( $event['id'] ) ) {
			return new \WP_REST_Response( [ 'error' => 'malformed_event' ], 400 );
		}

		// Idempotency — Stripe retries; we must not double-process
		$id_key = 'aff_sw_seen_' . sanitize_key( (string) $event['id'] );
		if ( get_transient( $id_key ) ) {
			return new \WP_REST_Response( [ 'ok' => true, 'duplicate' => true ], 200 );
		}
		set_transient( $id_key, 1, 7 * DAY_IN_SECONDS );

		$type = (string) $event['type'];
		$data = (array) ( $event['data']['object'] ?? [] );

		switch ( $type ) {
			case 'transfer.failed':
			case 'transfer.reversed':
				self::handle_transfer_failure( $data, $type );
				break;
			case 'account.updated':
				self::handle_account_updated( $data );
				break;
			default:
				// Acknowledged but not actioned — keeps Stripe from retrying
				break;
		}

		self::log( 'webhook.received', [ 'type' => $type, 'event_id' => $event['id'] ] );
		return new \WP_REST_Response( [ 'ok' => true ], 200 );
	}

	// ── Event handlers ──────────────────────────────────────────────────────

	/**
	 * Stripe transfer failed AFTER our sync API call returned success.
	 * Find the matching payout row + flip to failed + unlock commissions
	 * so they're available for the next batch.
	 */
	private static function handle_transfer_failure( array $data, string $event_type ): void {
		$transfer_id = (string) ( $data['id'] ?? '' );
		if ( $transfer_id === '' ) { return; }

		global $wpdb;
		$payout = $wpdb->get_row( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}aff_payouts WHERE stripe_transfer_id = %s LIMIT 1",
			$transfer_id
		) );
		if ( ! $payout ) {
			self::log( 'webhook.transfer.no_matching_payout', [
				'transfer_id' => $transfer_id, 'event' => $event_type,
			], 'warning' );
			return;
		}

		$reason = $event_type === 'transfer.reversed' ? 'Reversed by Stripe' : 'Failed at Stripe (post-success)';
		if ( ! empty( $data['failure_message'] ) ) {
			$reason .= ': ' . substr( (string) $data['failure_message'], 0, 200 );
		}

		Payout_Repository::mark_failed( (int) $payout->id, $reason );
		self::log( 'webhook.payout.marked_failed', [
			'payout_id'   => (int) $payout->id,
			'transfer_id' => $transfer_id,
			'event'       => $event_type,
			'reason'      => $reason,
		] );
	}

	/**
	 * Stripe Connect account changed status. Update the affiliate's cached
	 * stripe_connect_status so admin sees real-time onboarding state without
	 * having to re-check Stripe Dashboard.
	 */
	private static function handle_account_updated( array $data ): void {
		$account_id = (string) ( $data['id'] ?? '' );
		if ( $account_id === '' || ! str_starts_with( $account_id, 'acct_' ) ) { return; }

		// Derive a simple status: 'verified' / 'restricted' / 'disabled' / 'incomplete'
		$disabled         = (bool) ( $data['requirements']['disabled_reason'] ?? false );
		$charges_enabled  = (bool) ( $data['charges_enabled']  ?? false );
		$payouts_enabled  = (bool) ( $data['payouts_enabled']  ?? false );

		$status = match ( true ) {
			$disabled                                 => 'disabled',
			! $charges_enabled || ! $payouts_enabled  => 'restricted',
			default                                   => 'verified',
		};

		global $wpdb;
		$updated = $wpdb->update(
			$wpdb->prefix . 'aff_affiliates',
			[ 'stripe_connect_status' => $status ],
			[ 'stripe_connect_account_id' => $account_id ]
		);
		if ( $updated ) {
			self::log( 'webhook.account.status_updated', [
				'account_id' => $account_id, 'new_status' => $status,
			] );
		}
	}

	// ── Signature verification ──────────────────────────────────────────────

	/**
	 * Stripe signature header format: `t=<ts>,v1=<hex>,v1=<hex>,…`
	 * Verify HMAC-SHA256 over `t.body` matches at least one v1 in the header.
	 */
	private static function verify_signature( string $body, string $header, string $secret ): bool {
		if ( $header === '' ) { return false; }
		$parts = [];
		foreach ( explode( ',', $header ) as $chunk ) {
			[ $k, $v ] = array_pad( explode( '=', $chunk, 2 ), 2, '' );
			$parts[ trim( $k ) ][] = trim( $v );
		}
		$timestamp = isset( $parts['t'][0] ) ? (int) $parts['t'][0] : 0;
		$sigs      = (array) ( $parts['v1'] ?? [] );
		if ( $timestamp <= 0 || $sigs === [] ) { return false; }
		if ( abs( time() - $timestamp ) > self::SIGNATURE_TOLERANCE ) {
			return false;  // replay protection
		}

		$expected = hash_hmac( 'sha256', $timestamp . '.' . $body, $secret );
		foreach ( $sigs as $sig ) {
			if ( hash_equals( $expected, $sig ) ) { return true; }
		}
		return false;
	}

	/**
	 * Webhook signing secret. Resolved in same priority as Stripe key:
	 *   1. ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET constant (mu-plugin OR wp-config)
	 *   2. Setting `stripe_webhook_secret`
	 */
	private static function resolve_signing_secret(): string {
		if ( defined( 'ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET' ) && ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET !== '' ) {
			return (string) ASTERIS_AFFILIATES_STRIPE_WEBHOOK_SECRET;
		}
		return (string) Settings::get( 'stripe_webhook_secret', '' );
	}

	private static function log( string $event_type, array $payload, string $level = 'info' ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => 'stripe_' . $event_type,
			'affiliate_id' => null,
			'actor'        => 'stripe',
			'payload'      => wp_json_encode( array_merge( $payload, [ 'level' => $level ] ) ),
		] );
	}
}
