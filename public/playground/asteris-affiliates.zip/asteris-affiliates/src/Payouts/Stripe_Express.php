<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Payouts;

defined( 'ABSPATH' ) || exit;

/**
 * Stripe Connect Express account creation + onboarding link generation.
 *
 * v1.0 uses Express accounts (NOT Standard or Custom):
 *   - Stripe hosts the entire onboarding UI (we don't build forms)
 *   - Stripe manages tax forms (W-9, W-8BEN), bank verification, identity
 *   - Customer (store owner) keeps platform-level control + branding
 *   - Affiliate logs into Stripe Express dashboard to see THEIR payouts
 *
 * Flow:
 *   1. Affiliate clicks "Connect with Stripe" in portal Profile
 *   2. We call POST /v1/accounts to create an Express account
 *      → returns acct_xxx
 *   3. We save acct_xxx to the affiliate's row
 *   4. We call POST /v1/account_links to generate hosted-onboarding URL
 *      → returns 5-min-expiring URL
 *   5. We redirect affiliate to that URL
 *   6. Affiliate completes Stripe-hosted form
 *   7. Stripe redirects to our return_url
 *   8. We query GET /v1/accounts/{id} to confirm status
 *   9. Save status (verified/restricted/incomplete) — webhook keeps it fresh
 *
 * Customer setup required ONCE:
 *   dashboard.stripe.com/connect/accounts → enable Express platform
 *   No separate API key — uses the same sk_live_xxx as regular charges.
 *
 * Errors surfaced clearly:
 *   "Your Stripe account doesn't have Connect Express enabled" → links
 *   to the dashboard URL so the admin can fix it in 30 seconds.
 */
final class Stripe_Express {

	private const STRIPE_API = 'https://api.stripe.com/v1';
	private const API_VERSION = '2024-10-28.acacia';

	/**
	 * Create a new Express account for the affiliate.
	 * Returns acct_xxx on success, WP_Error on failure.
	 *
	 * @return string|\WP_Error
	 */
	public static function create_account( object $affiliate ) {
		$secret = Stripe_Connect::resolve_secret_key();
		if ( $secret === '' ) {
			return new \WP_Error( 'no_stripe_key',
				'Store owner hasn\'t configured Stripe yet. Tell them to add it in Affiliates Settings → Stripe Connect.' );
		}

		// Stripe Express account creation. Country defaults to affiliate's
		// stored country_code (Stripe Express supports 47+ countries).
		// type=express puts Stripe in charge of all the onboarding UI.
		$body = http_build_query( [
			'type'                                  => 'express',
			'country'                               => strtoupper( (string) $affiliate->country_code ),
			'email'                                 => (string) $affiliate->email,
			'capabilities[transfers][requested]'    => 'true',
			'business_type'                         => 'individual',  // affiliate can change in onboarding
			'business_profile[url]'                 => home_url( '/' ),
			'business_profile[name]'                => (string) $affiliate->display_name,
			'metadata[aff_plugin_id]'               => (string) $affiliate->id,
			'metadata[aff_public_id]'               => (string) $affiliate->public_id,
			'metadata[aff_site]'                    => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
		] );

		$response = wp_remote_post( self::STRIPE_API . '/accounts', [
			'timeout' => 20,
			'headers' => [
				'Authorization'   => 'Bearer ' . $secret,
				'Content-Type'    => 'application/x-www-form-urlencoded',
				'Stripe-Version'  => self::API_VERSION,
				// Idempotency: same affiliate clicking Connect twice should
				// NOT create two Stripe accounts. Key = aff ID + day.
				'Idempotency-Key' => 'aff-create-' . (int) $affiliate->id . '-' . gmdate( 'Y-m-d' ),
			],
			'body' => $body,
		] );

		return self::parse_response( $response, 'id', 'create_account' );
	}

	/**
	 * Generate a hosted-onboarding URL for an existing connected account.
	 * Used for INITIAL onboarding (type=account_onboarding) AND for fixing
	 * incomplete accounts later (type=account_onboarding still — Stripe
	 * detects what's missing and asks for it).
	 *
	 * @return string|\WP_Error
	 */
	public static function create_onboarding_link( string $account_id, string $return_url, string $refresh_url ) {
		$secret = Stripe_Connect::resolve_secret_key();
		if ( $secret === '' ) {
			return new \WP_Error( 'no_stripe_key', 'Stripe key missing.' );
		}

		$body = http_build_query( [
			'account'     => $account_id,
			'refresh_url' => $refresh_url,  // sent here if link expires or onboarding restarted
			'return_url'  => $return_url,   // sent here when affiliate completes / abandons
			'type'        => 'account_onboarding',
		] );

		$response = wp_remote_post( self::STRIPE_API . '/account_links', [
			'timeout' => 20,
			'headers' => [
				'Authorization'  => 'Bearer ' . $secret,
				'Content-Type'   => 'application/x-www-form-urlencoded',
				'Stripe-Version' => self::API_VERSION,
			],
			'body' => $body,
		] );

		return self::parse_response( $response, 'url', 'create_link' );
	}

	/**
	 * Fetch account status from Stripe. Returns:
	 *   [ 'status' => 'verified|restricted|incomplete|disabled',
	 *     'charges_enabled' => bool,
	 *     'payouts_enabled' => bool,
	 *     'details_submitted' => bool,
	 *     'requirements_due' => string[] ]
	 *
	 * @return array|\WP_Error
	 */
	public static function retrieve_account( string $account_id ) {
		$secret = Stripe_Connect::resolve_secret_key();
		if ( $secret === '' ) {
			return new \WP_Error( 'no_stripe_key', 'Stripe key missing.' );
		}

		$response = wp_remote_get( self::STRIPE_API . '/accounts/' . $account_id, [
			'timeout' => 15,
			'headers' => [
				'Authorization'  => 'Bearer ' . $secret,
				'Stripe-Version' => self::API_VERSION,
			],
		] );
		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'network', 'Stripe network error: ' . $response->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( $code !== 200 || ! is_array( $data ) ) {
			$msg = $data['error']['message'] ?? 'Stripe returned HTTP ' . $code;
			return new \WP_Error( 'stripe_' . $code, $msg );
		}

		$charges_enabled   = (bool) ( $data['charges_enabled']   ?? false );
		$payouts_enabled   = (bool) ( $data['payouts_enabled']   ?? false );
		$details_submitted = (bool) ( $data['details_submitted'] ?? false );
		$requirements_due  = (array) ( $data['requirements']['currently_due'] ?? [] );
		$disabled_reason   = (string) ( $data['requirements']['disabled_reason'] ?? '' );

		$status = match ( true ) {
			$disabled_reason !== ''                       => 'disabled',
			! $details_submitted                           => 'incomplete',
			! $charges_enabled || ! $payouts_enabled       => 'restricted',
			default                                        => 'verified',
		};

		return [
			'status'            => $status,
			'charges_enabled'   => $charges_enabled,
			'payouts_enabled'   => $payouts_enabled,
			'details_submitted' => $details_submitted,
			'requirements_due'  => $requirements_due,
			'disabled_reason'   => $disabled_reason,
		];
	}

	/**
	 * Generate an Express login link — for affiliates who want to view
	 * their Stripe dashboard (see payouts, update bank, view tax docs).
	 * Single-use, expires in seconds.
	 *
	 * @return string|\WP_Error
	 */
	public static function create_login_link( string $account_id ) {
		$secret = Stripe_Connect::resolve_secret_key();
		if ( $secret === '' ) {
			return new \WP_Error( 'no_stripe_key', 'Stripe key missing.' );
		}
		$response = wp_remote_post( self::STRIPE_API . '/accounts/' . $account_id . '/login_links', [
			'timeout' => 15,
			'headers' => [
				'Authorization'  => 'Bearer ' . $secret,
				'Stripe-Version' => self::API_VERSION,
			],
		] );
		return self::parse_response( $response, 'url', 'login_link' );
	}

	// ── Helpers ─────────────────────────────────────────────────────────────

	/**
	 * Shared response parser. Returns the requested field on success, or
	 * a WP_Error with a human-readable message that maps the common
	 * Stripe failure modes to actionable text.
	 */
	private static function parse_response( $response, string $field, string $context ) {
		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'network', 'Stripe network error: ' . $response->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( $code >= 200 && $code < 300 && isset( $data[ $field ] ) ) {
			return (string) $data[ $field ];
		}

		$msg  = $data['error']['message'] ?? 'Stripe returned HTTP ' . $code;
		$type = $data['error']['code']    ?? 'unknown';

		// Map common errors to actionable text
		if ( $type === 'platform_not_active' || strpos( $msg, 'Connect' ) !== false ) {
			$msg = 'Stripe Connect Express isn\'t enabled on this Stripe account yet. Store owner: visit dashboard.stripe.com/connect/accounts and enable Express platform (takes 30 seconds, no application needed).';
		}
		return new \WP_Error( 'stripe_' . $type, $msg );
	}
}
