<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Payouts;

defined( 'ABSPATH' ) || exit;

/**
 * CRUD for wp_aff_payouts + commission linking.
 *
 * Lifecycle of a single payout row:
 *   1. Batch_Cron creates rows with status='pending' for every affiliate
 *      whose approved balance > min_threshold
 *   2. Approved commissions are atomically linked to the payout via
 *      payout_id (locks them so a second batch can't double-count)
 *   3. Admin reviews on Page_Payouts
 *   4. Admin clicks Pay (Stripe API call) OR Mark Paid (manual PayPal/bank
 *      with reference) → status='paid', linked commissions → status='paid'
 *   5. If Stripe transfer fails → status='failed', commissions un-linked
 *      so the next batch retries them
 */
final class Payout_Repository {

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'aff_payouts';
	}

	public static function find( int $id ): ?object {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
		return $row ?: null;
	}

	/**
	 * @return object[]
	 */
	public static function list( ?string $status = null, int $limit = 100 ): array {
		global $wpdb;
		$p = $wpdb->prefix;
		if ( $status ) {
			return (array) $wpdb->get_results( $wpdb->prepare(
				"SELECT p.*, a.display_name AS aff_name, a.email AS aff_email
				 FROM {$p}aff_payouts p LEFT JOIN {$p}aff_affiliates a ON a.id = p.affiliate_id
				 WHERE p.status = %s ORDER BY p.id DESC LIMIT %d",
				$status, $limit
			) );
		}
		return (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT p.*, a.display_name AS aff_name, a.email AS aff_email
			 FROM {$p}aff_payouts p LEFT JOIN {$p}aff_affiliates a ON a.id = p.affiliate_id
			 ORDER BY p.id DESC LIMIT %d",
			$limit
		) );
	}

	/** @return array<string,int> status => count */
	public static function counts_by_status(): array {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS n FROM ' . self::table() . ' GROUP BY status' );
		$out = [ 'pending' => 0, 'processing' => 0, 'paid' => 0, 'failed' => 0 ];
		foreach ( $rows as $r ) { $out[ (string) $r->status ] = (int) $r->n; }
		return $out;
	}

	/**
	 * Atomic: create the payout row + LOCK every commission attached to it
	 * by setting commission.payout_id. Prevents race-condition double-counting.
	 *
	 * @return int|null  payout ID or null on failure
	 */
	public static function create_for_affiliate(
		int $affiliate_id,
		string $batch_id,
		string $payout_method,
		array $commission_ids,
		int $total_cents,
		string $currency
	): ?int {
		if ( ! $commission_ids ) { return null; }
		global $wpdb;
		$now = current_time( 'mysql', true );

		$ok = $wpdb->insert( self::table(), [
			'affiliate_id'     => $affiliate_id,
			'batch_id'         => $batch_id,
			'payout_method'    => $payout_method,
			'total_cents'      => $total_cents,
			'currency'         => $currency,
			'commission_count' => count( $commission_ids ),
			'status'           => 'pending',
			'requested_at'     => $now,
		] );
		if ( ! $ok ) { return null; }
		$payout_id = (int) $wpdb->insert_id;

		// Link commissions atomically
		$placeholders = implode( ',', array_fill( 0, count( $commission_ids ), '%d' ) );
		$params = array_merge( [ $payout_id ], $commission_ids );
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_commissions
			 SET payout_id = %d
			 WHERE id IN ($placeholders) AND status = 'approved' AND payout_id IS NULL",
			$params
		) );
		return $payout_id;
	}

	/**
	 * Mark a payout paid. Atomically flips the payout + all its linked
	 * commissions to 'paid' status. Records the reference (Stripe transfer
	 * ID, PayPal txn ID, bank wire reference).
	 */
	public static function mark_paid( int $payout_id, string $reference, string $reference_field = 'bank_reference' ): bool {
		global $wpdb;
		$now = current_time( 'mysql', true );

		$update = [
			'status'  => 'paid',
			'paid_at' => $now,
		];
		if ( $reference_field === 'stripe_transfer_id' ) {
			$update['stripe_transfer_id'] = substr( $reference, 0, 64 );
		} else {
			$update['bank_reference'] = substr( $reference, 0, 120 );
		}
		$ok = $wpdb->update( self::table(), $update, [ 'id' => $payout_id ] );
		if ( $ok === false ) { return false; }

		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_commissions
			 SET status = 'paid', paid_at = %s
			 WHERE payout_id = %d AND status = 'approved'",
			$now, $payout_id
		) );
		return true;
	}

	/**
	 * Mark a payout failed. Un-links the commissions so the next batch
	 * picks them up again. Records the reason for admin debugging.
	 */
	public static function mark_failed( int $payout_id, string $reason ): void {
		global $wpdb;
		$wpdb->update( self::table(),
			[ 'status' => 'failed', 'failure_reason' => substr( $reason, 0, 500 ) ],
			[ 'id' => $payout_id ]
		);
		// Release the commissions
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}aff_commissions SET payout_id = NULL WHERE payout_id = %d",
			$payout_id
		) );
	}
}
