<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Payouts;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Monthly payout batch generator.
 *
 * Triggered by Daily_Cron — checks if today is the configured
 * `payout_day_of_month` (default 1). If yes, creates a batch:
 *
 *   For each approved affiliate:
 *     1. Sum their approved-and-unpaid commission balance
 *     2. If balance < payout_min_cents, skip
 *     3. If their payout_method is unset or method-specific fields missing
 *        (e.g. stripe_connect_account_id null for stripe method), skip
 *        + log warning
 *     4. Create payout row + LOCK linked commissions atomically
 *     5. For Stripe payouts WHERE Stripe key is configured: auto-attempt
 *        the transfer now. Success → mark paid. Failure → mark failed +
 *        log so admin can manually retry.
 *     6. For PayPal + bank-transfer: leave as 'pending' for admin to
 *        manually mark-paid on Page_Payouts.
 *
 * Returns count of batches created.
 */
final class Batch_Cron {

	/** Called from Daily_Cron::run() */
	public static function maybe_run_today(): int {
		$today_day = (int) gmdate( 'j' );
		$target    = (int) Settings::get( 'payout_day_of_month', 1 );
		if ( $today_day !== $target ) { return 0; }
		return self::run_batch();
	}

	/** Force-run from admin button or wp-cli (no day check). */
	public static function run_batch(): int {
		global $wpdb;
		$p = $wpdb->prefix;

		$min_cents = (int) Settings::get( 'payout_min_cents', 10000 );
		$batch_id  = 'b_' . gmdate( 'Ymd_His' ) . '_' . substr( md5( wp_generate_password( 8, false ) ), 0, 6 );

		// Find affiliates with approved + unpaid balance >= min
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT
			   a.id AS affiliate_id, a.payout_method, a.stripe_connect_account_id,
			   a.paypal_email, a.bank_details_encrypted, a.email,
			   COALESCE(SUM(c.amount_cents), 0) AS balance_cents,
			   c.currency
			 FROM {$p}aff_affiliates a
			 INNER JOIN {$p}aff_commissions c
			   ON c.affiliate_id = a.id
			   AND c.status = 'approved'
			   AND c.payout_id IS NULL
			 WHERE a.status = 'approved'
			 GROUP BY a.id
			 HAVING balance_cents >= %d",
			$min_cents
		) );

		$created = 0;
		$attempted_stripe = 0;
		$auto_paid_stripe = 0;
		$failed_stripe    = 0;

		foreach ( $rows as $row ) {
			$method   = (string) $row->payout_method;
			$total    = (int) $row->balance_cents;
			$currency = (string) ( $row->currency ?? 'USD' );

			// Method-readiness gate
			$ready = self::check_method_ready( $method, $row );
			if ( ! $ready['ok'] ) {
				self::log( 'payout.batch.skipped_method_unready', (int) $row->affiliate_id, [
					'batch_id' => $batch_id, 'method' => $method, 'reason' => $ready['reason'],
				] );
				continue;
			}

			// Find all approved+unpaid commission IDs for this affiliate
			$commission_ids = $wpdb->get_col( $wpdb->prepare(
				"SELECT id FROM {$p}aff_commissions
				 WHERE affiliate_id = %d AND status = 'approved' AND payout_id IS NULL",
				(int) $row->affiliate_id
			) );
			if ( ! $commission_ids ) { continue; }

			$payout_id = Payout_Repository::create_for_affiliate(
				(int) $row->affiliate_id,
				$batch_id,
				$method,
				array_map( 'intval', $commission_ids ),
				$total,
				$currency
			);
			if ( ! $payout_id ) { continue; }
			$created++;

			// For Stripe with a configured key, auto-attempt the transfer NOW
			// Pro-only — free tier defers all payouts to manual mark-paid
			$stripe_auto = $method === 'stripe_connect'
				&& Stripe_Connect::is_configured()
				&& \AsterisAffiliates\Core\Free_Tier::feature( 'stripe_connect_auto' );
			if ( $stripe_auto ) {
				$attempted_stripe++;
				$result = Stripe_Connect::transfer(
					(string) $row->stripe_connect_account_id,
					$total,
					$currency,
					'Affiliate payout · batch ' . $batch_id
				);
				if ( is_wp_error( $result ) ) {
					Payout_Repository::mark_failed( $payout_id, $result->get_error_message() );
					$failed_stripe++;
					self::log( 'payout.stripe.failed', (int) $row->affiliate_id, [
						'payout_id' => $payout_id, 'error' => $result->get_error_message(),
					] );
				} else {
					Payout_Repository::mark_paid( $payout_id, (string) $result, 'stripe_transfer_id' );
					$auto_paid_stripe++;
					self::log( 'payout.stripe.paid', (int) $row->affiliate_id, [
						'payout_id' => $payout_id, 'transfer_id' => $result, 'amount_cents' => $total,
					] );
				}
			}
		}

		self::log( 'payout.batch.created', null, [
			'batch_id'          => $batch_id,
			'rows_created'      => $created,
			'stripe_attempted'  => $attempted_stripe,
			'stripe_paid'       => $auto_paid_stripe,
			'stripe_failed'     => $failed_stripe,
		] );

		return $created;
	}

	/**
	 * Per-method readiness check. Returns ['ok' => bool, 'reason' => string].
	 */
	private static function check_method_ready( string $method, object $row ): array {
		switch ( $method ) {
			case 'stripe_connect':
				if ( empty( $row->stripe_connect_account_id ) ) {
					return [ 'ok' => false, 'reason' => 'No Stripe Connect account ID on affiliate.' ];
				}
				return [ 'ok' => true, 'reason' => '' ];
			case 'paypal':
				if ( empty( $row->paypal_email ) || ! is_email( $row->paypal_email ) ) {
					return [ 'ok' => false, 'reason' => 'No PayPal email on affiliate.' ];
				}
				return [ 'ok' => true, 'reason' => '' ];
			case 'bank_transfer':
				if ( empty( $row->bank_details_encrypted ) ) {
					return [ 'ok' => false, 'reason' => 'No bank details on affiliate.' ];
				}
				return [ 'ok' => true, 'reason' => '' ];
			case 'manual':
				return [ 'ok' => true, 'reason' => '' ];
			default:
				return [ 'ok' => false, 'reason' => 'Unknown payout method: ' . $method ];
		}
	}

	private static function log( string $event, ?int $aff_id, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event,
			'affiliate_id' => $aff_id,
			'actor'        => 'cron',
			'payload'      => wp_json_encode( $payload ),
		] );
	}
}
