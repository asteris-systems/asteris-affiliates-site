<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Payouts;

use AsterisAffiliates\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * PayPal Payouts API integration — replaces manual mark-paid for the
 * paypal payout method.
 *
 * Auth: PayPal REST API OAuth2 client credentials grant.
 *   Settings::get('paypal_client_id')
 *   Settings::get('paypal_secret')
 *   Settings::get('paypal_mode')        // 'sandbox' | 'live'
 *
 * Flow per batch:
 *   1. Get OAuth2 access_token (cached 8h)
 *   2. POST /v1/payments/payouts with sender_batch_header + items
 *   3. Read payout_batch_id from response — store on payout row
 *   4. Mark each payout row as 'queued' (PayPal processes async)
 *   5. Webhook PAYMENT.PAYOUTS-ITEM.SUCCEEDED / FAILED flips to paid/failed
 *      (webhook in Stripe_Webhook.php sister class — would extend or create
 *       PayPal_Webhook in v1.2)
 *
 * This v1.1 implementation does the OUTGOING POST and stores the batch ID.
 * The webhook handler for inbound status updates is scaffolded but disabled
 * pending Settings::get('paypal_webhook_id'). Full async flow lands v1.2.
 */
final class PayPal_API {

	private const TOKEN_OPT = 'asteris_aff_paypal_token';

	public static function is_configured(): bool {
		return Settings::get( 'paypal_client_id' ) && Settings::get( 'paypal_secret' );
	}

	private static function base_url(): string {
		return Settings::get( 'paypal_mode', 'sandbox' ) === 'live'
			? 'https://api-m.paypal.com'
			: 'https://api-m.sandbox.paypal.com';
	}

	/** Returns cached or freshly-fetched OAuth2 access token. */
	private static function token(): ?string {
		$cached = get_transient( self::TOKEN_OPT );
		if ( is_string( $cached ) && $cached !== '' ) { return $cached; }

		$client = (string) Settings::get( 'paypal_client_id' );
		$secret = (string) Settings::get( 'paypal_secret' );
		if ( $client === '' || $secret === '' ) { return null; }

		$response = wp_remote_post(
			self::base_url() . '/v1/oauth2/token',
			[
				'timeout' => 12,
				'headers' => [
					'Authorization' => 'Basic ' . base64_encode( $client . ':' . $secret ),
					'Content-Type'  => 'application/x-www-form-urlencoded',
				],
				'body' => 'grant_type=client_credentials',
			]
		);
		if ( is_wp_error( $response ) ) { return null; }
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['access_token'] ) ) { return null; }
		set_transient( self::TOKEN_OPT, $body['access_token'], 8 * HOUR_IN_SECONDS );
		return (string) $body['access_token'];
	}

	/**
	 * POST a single payout to PayPal. Returns the payout_batch_id (string)
	 * on success, WP_Error on failure.
	 *
	 * @return string|\WP_Error
	 */
	public static function send_payout( string $recipient_email, int $amount_cents, string $currency, string $note = '' ) {
		if ( ! self::is_configured() ) {
			return new \WP_Error( 'paypal_not_configured', 'PayPal API credentials not set in Settings.' );
		}
		if ( $amount_cents <= 0 ) {
			return new \WP_Error( 'bad_amount', 'Payout amount must be > 0.' );
		}
		if ( ! is_email( $recipient_email ) ) {
			return new \WP_Error( 'bad_email', 'Recipient must be a valid email.' );
		}

		$token = self::token();
		if ( ! $token ) {
			return new \WP_Error( 'paypal_no_token', 'Could not get PayPal access token. Check credentials.' );
		}

		$batch_header_id = 'aff_' . substr( hash( 'sha256', wp_generate_password( 12, false ) ), 0, 24 );
		$amount = number_format( $amount_cents / 100, 2, '.', '' );

		$response = wp_remote_post(
			self::base_url() . '/v1/payments/payouts',
			[
				'timeout' => 30,
				'headers' => [
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				],
				'body' => wp_json_encode( [
					'sender_batch_header' => [
						'sender_batch_id' => $batch_header_id,
						'email_subject'   => 'You have a payout from ' . get_bloginfo( 'name' ),
						'email_message'   => $note ?: 'Affiliate commission payout.',
					],
					'items' => [ [
						'recipient_type'  => 'EMAIL',
						'amount'          => [ 'value' => $amount, 'currency' => strtoupper( $currency ) ],
						'note'            => $note ?: 'Affiliate commission',
						'sender_item_id'  => $batch_header_id . '_1',
						'receiver'        => $recipient_email,
					] ],
				] ),
			]
		);
		if ( is_wp_error( $response ) ) { return $response; }
		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = $body['message'] ?? ( $body['name'] ?? 'PayPal API error' );
			return new \WP_Error( 'paypal_api_error', (string) $msg . ' (HTTP ' . $code . ')' );
		}
		$pb_id = $body['batch_header']['payout_batch_id'] ?? null;
		if ( ! $pb_id ) {
			return new \WP_Error( 'paypal_no_batch_id', 'PayPal returned no payout_batch_id.' );
		}
		return (string) $pb_id;
	}

	/** Hook into Batch_Cron — auto-attempt PayPal payouts when configured. */
	public static function register(): void {
		add_action( 'asteris_aff_payout_created', [ self::class, 'maybe_auto_send' ], 10, 3 );
	}

	public static function maybe_auto_send( int $payout_id, object $affiliate, int $total_cents ): void {
		if ( $affiliate->payout_method !== 'paypal' ) { return; }
		// Pro-only — free tier uses manual mark-paid for PayPal
		if ( ! \AsterisAffiliates\Core\Free_Tier::feature( 'paypal_api_auto' ) ) { return; }
		if ( ! self::is_configured() ) { return; }
		if ( empty( $affiliate->paypal_email ) ) { return; }

		$result = self::send_payout(
			(string) $affiliate->paypal_email,
			$total_cents,
			'USD',
			'Affiliate commission · payout #' . $payout_id
		);
		if ( is_wp_error( $result ) ) {
			Payout_Repository::mark_failed( $payout_id, $result->get_error_message() );
			return;
		}
		// Mark as 'queued' — PayPal processes async, webhook will mark paid.
		// For v1.1 we mark paid optimistically since webhooks are scaffolded but disabled.
		Payout_Repository::mark_paid( $payout_id, $result, 'paypal_batch_id' );
	}
}
