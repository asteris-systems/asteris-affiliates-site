<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Payouts;

defined( 'ABSPATH' ) || exit;

/**
 * Thin Stripe Connect helper — fires `transfers.create` against Stripe's
 * REST API using `wp_remote_post`. No Stripe SDK vendored (saves ~2MB and
 * keeps with Asteris's zero-Composer philosophy).
 *
 * Auth: customer's STRIPE SECRET KEY. Resolved in this order:
 *   1. ASTERIS_AFFILIATES_STRIPE_SECRET constant in wp-config.php
 *   2. Asteris Affiliates plugin Setting `stripe_secret_key`
 *   3. WC Stripe Gateway's saved secret key (auto-detected if WC Stripe
 *      gateway is installed) — saves the customer from typing it twice
 *
 * Affiliate's Stripe Connect account ID is stored on their row
 * (`stripe_connect_account_id`) — pasted by admin on the affiliate
 * detail page, OR entered by the affiliate in portal Profile.
 *
 * v1.0: manual paste. v1.1 will add Express onboarding link generation
 * (`account_links.create` API) so the affiliate gets one-click onboarding.
 */
final class Stripe_Connect {

	/**
	 * Send funds. Returns Stripe transfer ID on success, WP_Error on failure.
	 *
	 * @param string $destination_account_id  acct_xxx
	 * @param int    $amount_cents            commission total
	 * @param string $currency                ISO-4217 (e.g. "usd")
	 * @param string $description             shown on Stripe dashboard
	 * @return string|\WP_Error
	 */
	public static function transfer(
		string $destination_account_id,
		int $amount_cents,
		string $currency,
		string $description = ''
	) {
		$secret = self::resolve_secret_key();
		if ( $secret === '' ) {
			return new \WP_Error( 'no_stripe_key',
				'No Stripe secret key configured. Add ASTERIS_AFFILIATES_STRIPE_SECRET to wp-config.php, save it in Affiliates Settings, OR install the WC Stripe Gateway with credentials configured.' );
		}
		if ( $amount_cents <= 0 ) {
			return new \WP_Error( 'bad_amount', 'Transfer amount must be > 0.' );
		}
		if ( ! preg_match( '/^acct_[A-Za-z0-9]+$/', $destination_account_id ) ) {
			return new \WP_Error( 'bad_account', 'Stripe destination account must look like acct_xxx.' );
		}

		$body = http_build_query( [
			'amount'      => $amount_cents,
			'currency'    => strtolower( $currency ),
			'destination' => $destination_account_id,
			'description' => substr( $description, 0, 200 ),
		] );

		$response = wp_remote_post( 'https://api.stripe.com/v1/transfers', [
			'timeout' => 20,
			'headers' => [
				'Authorization'    => 'Bearer ' . $secret,
				'Content-Type'     => 'application/x-www-form-urlencoded',
				// Stripe's idempotency key — same key = same outcome even on retry.
				// Hash of inputs so the same payout never double-sends.
				'Idempotency-Key'  => 'aff-' . hash( 'sha256', $destination_account_id . '|' . $amount_cents . '|' . $currency . '|' . wp_date( 'Y-m-d' ) ),
				'Stripe-Version'   => '2024-10-28.acacia',
			],
			'body' => $body,
		] );

		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'network', 'Stripe request failed: ' . $response->get_error_message() );
		}

		$code    = (int) wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( $code >= 200 && $code < 300 && ! empty( $decoded['id'] ) ) {
			return (string) $decoded['id'];
		}

		$msg = $decoded['error']['message'] ?? 'Stripe returned HTTP ' . $code;
		$code_str = $decoded['error']['code'] ?? 'unknown';
		return new \WP_Error( 'stripe_' . $code_str, $msg );
	}

	/**
	 * Returns secret key from constant, plugin setting, or WC Stripe gateway —
	 * in that order. Empty string if none configured.
	 */
	public static function resolve_secret_key(): string {
		if ( defined( 'ASTERIS_AFFILIATES_STRIPE_SECRET' ) && ASTERIS_AFFILIATES_STRIPE_SECRET !== '' ) {
			return (string) ASTERIS_AFFILIATES_STRIPE_SECRET;
		}
		$opt = (string) \AsterisAffiliates\Core\Settings::get( 'stripe_secret_key', '' );
		if ( $opt !== '' ) { return $opt; }

		// Try WC Stripe Gateway's saved key (option key matches both
		// the official woocommerce-gateway-stripe + most popular forks)
		$wc_stripe = (array) get_option( 'woocommerce_stripe_settings', [] );
		if ( ! empty( $wc_stripe['secret_key'] ) ) {
			return (string) $wc_stripe['secret_key'];
		}
		if ( ! empty( $wc_stripe['test_secret_key'] ) && ( $wc_stripe['testmode'] ?? 'no' ) === 'yes' ) {
			return (string) $wc_stripe['test_secret_key'];
		}
		return '';
	}

	public static function is_configured(): bool {
		return self::resolve_secret_key() !== '';
	}

	/**
	 * Verify a secret key by hitting Stripe's /balance endpoint.
	 * Returns true if Stripe accepts the key, WP_Error otherwise.
	 *
	 * Use BEFORE saving the key — catches typos + revoked keys so the
	 * admin gets immediate feedback instead of "why isn't anything paying out?"
	 * three days later when the cron fires.
	 *
	 * @return true|\WP_Error
	 */
	public static function validate_key( string $secret ) {
		if ( ! preg_match( '/^sk_(live|test)_[A-Za-z0-9]+$/', $secret ) ) {
			return new \WP_Error( 'bad_format', 'Must start with sk_live_ or sk_test_ followed by alphanumeric chars.' );
		}
		$res = wp_remote_get( 'https://api.stripe.com/v1/balance', [
			'timeout' => 10,
			'headers' => [
				'Authorization'  => 'Bearer ' . $secret,
				'Stripe-Version' => '2024-10-28.acacia',
			],
		] );
		if ( is_wp_error( $res ) ) {
			return new \WP_Error( 'network', 'Could not reach Stripe: ' . $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( $code === 200 ) { return true; }
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$msg  = is_array( $body ) ? ( $body['error']['message'] ?? '' ) : '';
		if ( $code === 401 ) {
			return new \WP_Error( 'unauthorized', 'Stripe rejected the key as invalid or revoked.' . ( $msg ? ' (' . $msg . ')' : '' ) );
		}
		return new \WP_Error( 'stripe_' . $code, 'Stripe returned HTTP ' . $code . ( $msg ? ': ' . $msg : '' ) );
	}
}
