<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Cron;

use AsterisAffiliates\Anti_Fraud\Refund_Rate_Scanner;
use AsterisAffiliates\Commissions\Approval_Scanner;
use AsterisAffiliates\Payouts\Batch_Cron;

defined( 'ABSPATH' ) || exit;

/**
 * Central daily cron. Activation schedules `asteris_aff_daily` once;
 * this class hooks the callback and dispatches to each scanner.
 *
 * Crons run in order:
 *   1. Approval_Scanner   — flip pending → approved after refund window
 *   2. Refund_Rate_Scanner — auto-suspend affiliates over 20% refund rate
 *
 * Single hook keeps cron output predictable + easy to debug. If a scanner
 * throws, subsequent scanners still run (try/catch each).
 */
final class Daily_Cron {

	public static function register(): void {
		add_action( 'asteris_aff_daily', [ self::class, 'run' ] );
	}

	public static function run(): void {
		$started = time();

		try {
			$approved = Approval_Scanner::run();
			self::log( 'cron.approval.ok', [ 'approved_count' => $approved ] );
		} catch ( \Throwable $e ) {
			self::log( 'cron.approval.error', [ 'message' => $e->getMessage() ] );
		}

		try {
			$suspended = Refund_Rate_Scanner::run();
			self::log( 'cron.refund_rate.ok', [ 'suspended_count' => $suspended ] );
		} catch ( \Throwable $e ) {
			self::log( 'cron.refund_rate.error', [ 'message' => $e->getMessage() ] );
		}

		// Payout batch — only runs if today's day-of-month matches the
		// configured payout day. Internal check, so cheap to invoke daily.
		try {
			$payouts = Batch_Cron::maybe_run_today();
			if ( $payouts > 0 ) {
				self::log( 'cron.payout.ok', [ 'payouts_created' => $payouts ] );
			}
		} catch ( \Throwable $e ) {
			self::log( 'cron.payout.error', [ 'message' => $e->getMessage() ] );
		}

		self::log( 'cron.daily.complete', [ 'duration_seconds' => time() - $started ] );
	}

	private static function log( string $event, array $payload ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => current_time( 'mysql', true ),
			'event_type'   => $event,
			'affiliate_id' => null,
			'actor'        => 'cron',
			'payload'      => wp_json_encode( $payload ),
		] );
	}
}
