<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Adapters;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Settings;
use AsterisAffiliates\Tracking\Cookie_Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Surecart adapter. Bridges the `surecart/order_paid` action to a commission
 * row, source='surecart'. Same lifecycle as EDD adapter.
 *
 * Surecart fires the action with a SureCart\Models\Order object. We grab
 * the subtotal + customer email + ID + currency.
 */
final class Surecart_Adapter implements Order_Source {

	public static function source_slug(): string { return 'surecart'; }
	public static function is_available(): bool { return class_exists( '\\SureCart\\Models\\Order' ); }

	public static function register(): void {
		if ( ! self::is_available() ) { return; }
		add_action( 'surecart/order_paid',     [ self::class, 'on_complete' ], 20, 1 );
		add_action( 'surecart/order_refunded', [ self::class, 'on_refund' ],   20, 1 );
	}

	public static function on_complete( object $order ): void {
		$order_id = (string) ( $order->id ?? '' );
		if ( $order_id === '' ) { return; }
		if ( self::commission_exists( $order_id ) ) { return; }

		$session_id = Cookie_Manager::current();
		if ( ! $session_id ) { return; }

		global $wpdb;
		$ref = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_referrals WHERE session_id = %s AND converted_at IS NULL ORDER BY id DESC LIMIT 1",
			$session_id
		) );
		if ( ! $ref ) { return; }
		$aff = Affiliate_Repository::find( (int) $ref->affiliate_id );
		if ( ! $aff || $aff->status !== 'approved' ) { return; }

		$subtotal_cents = (int) ( $order->subtotal_amount ?? ( ( (float) ( $order->subtotal ?? 0 ) ) * 100 ) );
		if ( $subtotal_cents <= 0 ) { return; }

		$rate_bp      = (int) ( $aff->custom_rate_override_bp ?? $aff->commission_rate_y1_bp );
		$amount_cents = (int) round( $subtotal_cents * ( $rate_bp / 10000 ) );
		if ( $amount_cents <= 0 ) { return; }

		$refund_days = max( 0, min( 90, (int) Settings::get( 'refund_window_days', 30 ) ) );
		$refund_ends = gmdate( 'Y-m-d H:i:s', time() + ( $refund_days * DAY_IN_SECONDS ) );
		$now = current_time( 'mysql', true );

		// Surecart IDs are strings — we store the hash in the order_id field
		// (BIGINT) by crc32-ing it. Compromise: collisions are negligible at
		// scale for one site, and source='surecart' is the disambiguator.
		$order_id_int = (int) sprintf( '%u', crc32( $order_id ) );

		$wpdb->insert( $wpdb->prefix . 'aff_commissions', [
			'affiliate_id'       => (int) $aff->id,
			'order_id'           => $order_id_int,
			'referral_id'        => (int) $ref->id,
			'attribution_type'   => 'link',
			'customer_email'     => strtolower( (string) ( $order->email ?? '' ) ),
			'amount_cents'       => $amount_cents,
			'currency'           => strtoupper( (string) ( $order->currency ?? 'USD' ) ),
			'rate_bp'            => $rate_bp,
			'rate_year'          => 1,
			'tier_level'         => 1,
			'source'             => 'surecart',
			'status'             => $refund_days === 0 ? 'approved' : 'pending',
			'refund_window_ends' => $refund_ends,
			'approved_at'        => $refund_days === 0 ? $now : null,
			'created_at'         => $now,
		] );
		$cid = (int) $wpdb->insert_id;

		$wpdb->update( $wpdb->prefix . 'aff_referrals',
			[ 'converted_at' => $now, 'converted_order_id' => $order_id_int ],
			[ 'id' => (int) $ref->id ]
		);

		do_action( 'asteris_aff_commission_changed', (int) $aff->id );

		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'commission.created',
			'affiliate_id' => (int) $aff->id,
			'actor'        => 'system',
			'payload'      => wp_json_encode( [
				'commission_id'   => $cid,
				'surecart_id'     => $order_id,
				'source'          => 'surecart',
			] ),
		] );
	}

	public static function on_refund( object $order ): void {
		$id = (string) ( $order->id ?? '' );
		if ( $id === '' ) { return; }
		$order_id_int = (int) sprintf( '%u', crc32( $id ) );
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_commissions WHERE order_id = %d AND source = 'surecart' LIMIT 1",
			$order_id_int
		) );
		if ( ! $row || (string) $row->status === 'refunded' ) { return; }
		$wpdb->update( $wpdb->prefix . 'aff_commissions',
			[ 'status' => 'refunded', 'refunded_at' => current_time( 'mysql', true ), 'amount_cents' => 0, 'refund_reason' => 'surecart_refund' ],
			[ 'id' => (int) $row->id ]
		);
		do_action( 'asteris_aff_commission_changed', (int) $row->affiliate_id );
	}

	private static function commission_exists( string $surecart_id ): bool {
		$order_id_int = (int) sprintf( '%u', crc32( $surecart_id ) );
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT 1 FROM {$wpdb->prefix}aff_commissions WHERE order_id = %d AND source = 'surecart' LIMIT 1",
			$order_id_int
		) );
	}
}
