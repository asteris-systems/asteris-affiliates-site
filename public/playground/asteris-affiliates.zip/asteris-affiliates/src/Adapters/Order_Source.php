<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Adapters;

defined( 'ABSPATH' ) || exit;

/**
 * Pluggable order-source contract. Lets non-WC platforms (EDD, Surecart,
 * future custom) feed commissions into the same Engine.
 *
 * Each adapter:
 *   - register()           — hook into the source platform's order events
 *   - bridge_to_engine()   — fabricate a WC_Order-compatible shape OR
 *                            call Engine helpers directly
 *
 * v1.1 ships EDD + Surecart implementations. Both are no-ops unless their
 * source plugin is detected.
 */
interface Order_Source {
	public static function source_slug(): string;
	public static function is_available(): bool;
	public static function register(): void;
}
