<?php
/**
 * @package AsterisAffiliates
 */

namespace AsterisAffiliates\Adapters;

use AsterisAffiliates\Affiliates\Affiliate_Repository;
use AsterisAffiliates\Core\Settings;
use AsterisAffiliates\Tracking\Cookie_Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Easy Digital Downloads adapter. Detects EDD presence and bridges its
 * `edd_complete_purchase` event to a commission row in our wp_aff_commissions
 * table — same lifecycle as a WC order commission, just source='edd'.
 */
final class EDD_Adapter implements Order_Source {

	public static function source_slug(): string { return 'edd'; }
	public static function is_available(): bool { return function_exists( 'edd_get_payment' ); }

	public static function register(): void {
		if ( ! self::is_available() ) { return; }
		add_action( 'edd_complete_purchase', [ self::class, 'on_complete' ], 20, 1 );
		add_action( 'edd_post_refund_payment', [ self::class, 'on_refund' ], 20, 1 );
	}

	public static function on_complete( int $payment_id ): void {
		if ( self::commission_exists( $payment_id ) ) { return; }
		$payment = edd_get_payment( $payment_id );
		if ( ! $payment ) { return; }

		$session_id = Cookie_Manager::current();
		if ( ! $session_id ) { return; }

		global $wpdb;
		$ref = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_referrals WHERE session_id = %s AND converted_at IS NULL ORDER BY id DESC LIMIT 1",
			$session_id
		) );
		if ( ! $ref ) { return; }

		$aff = Affiliate_Repository::find( (int) $ref->affiliate_id );
		if ( ! $aff || $aff->status !== 'approved' ) { return; }

		$subtotal_cents = (int) round( ( (float) $payment->subtotal ) * 100 );
		if ( $subtotal_cents <= 0 ) { return; }

		$rate_bp = (int) ( $aff->custom_rate_override_bp ?? $aff->commission_rate_y1_bp );
		$amount_cents = (int) round( $subtotal_cents * ( $rate_bp / 10000 ) );
		if ( $amount_cents <= 0 ) { return; }

		$refund_days = max( 0, min( 90, (int) Settings::get( 'refund_window_days', 30 ) ) );
		$refund_ends = gmdate( 'Y-m-d H:i:s', time() + ( $refund_days * DAY_IN_SECONDS ) );
		$now = current_time( 'mysql', true );

		$wpdb->insert( $wpdb->prefix . 'aff_commissions', [
			'affiliate_id'       => (int) $aff->id,
			'order_id'           => $payment_id,
			'referral_id'        => (int) $ref->id,
			'attribution_type'   => 'link',
			'customer_email'     => strtolower( (string) $payment->email ),
			'amount_cents'       => $amount_cents,
			'currency'           => strtoupper( (string) ( $payment->currency ?? 'USD' ) ),
			'rate_bp'            => $rate_bp,
			'rate_year'          => 1,
			'tier_level'         => 1,
			'source'             => 'edd',
			'status'             => $refund_days === 0 ? 'approved' : 'pending',
			'refund_window_ends' => $refund_ends,
			'approved_at'        => $refund_days === 0 ? $now : null,
			'created_at'         => $now,
		] );
		$cid = (int) $wpdb->insert_id;

		$wpdb->update( $wpdb->prefix . 'aff_referrals',
			[ 'converted_at' => $now, 'converted_order_id' => $payment_id ],
			[ 'id' => (int) $ref->id ]
		);

		do_action( 'asteris_aff_commission_changed', (int) $aff->id );

		$wpdb->insert( $wpdb->prefix . 'aff_events', [
			'occurred_at'  => $now,
			'event_type'   => 'commission.created',
			'affiliate_id' => (int) $aff->id,
			'actor'        => 'system',
			'payload'      => wp_json_encode( [ 'commission_id' => $cid, 'edd_payment_id' => $payment_id, 'source' => 'edd' ] ),
		] );
	}

	public static function on_refund( int $payment_id ): void {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}aff_commissions WHERE order_id = %d AND source = 'edd' LIMIT 1",
			$payment_id
		) );
		if ( ! $row || (string) $row->status === 'refunded' ) { return; }
		$wpdb->update( $wpdb->prefix . 'aff_commissions',
			[ 'status' => 'refunded', 'refunded_at' => current_time( 'mysql', true ), 'amount_cents' => 0, 'refund_reason' => 'edd_refund' ],
			[ 'id' => (int) $row->id ]
		);
		do_action( 'asteris_aff_commission_changed', (int) $row->affiliate_id );
	}

	private static function commission_exists( int $payment_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT 1 FROM {$wpdb->prefix}aff_commissions WHERE order_id = %d AND source = 'edd' LIMIT 1",
			$payment_id
		) );
	}
}
