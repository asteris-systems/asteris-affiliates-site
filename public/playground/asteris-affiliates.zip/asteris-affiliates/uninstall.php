<?php
/**
 * Uninstall handler — fires when site owner clicks "Delete" on the plugin
 * AFTER it's been deactivated.
 *
 * Defaults to data preservation. The site owner can opt into full data
 * deletion via:
 *   define( 'ASTERIS_AFFILIATES_DROP_TABLES_ON_UNINSTALL', true );
 * in wp-config.php BEFORE clicking Delete.
 *
 * This prevents the "I deleted the plugin and lost a year of commission
 * data" support nightmare.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( ! defined( 'ASTERIS_AFFILIATES_DROP_TABLES_ON_UNINSTALL' )
  || ! ASTERIS_AFFILIATES_DROP_TABLES_ON_UNINSTALL ) {
	return;
}

require_once __DIR__ . '/src/DB/Migration.php';
\AsterisAffiliates\DB\Migration::drop_all_tables();
